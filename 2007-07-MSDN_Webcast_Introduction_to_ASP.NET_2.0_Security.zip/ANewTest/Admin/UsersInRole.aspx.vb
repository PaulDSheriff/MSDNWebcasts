
Partial Class UsersInRole_aspx

    Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            RolesLoad()
        End If
    End Sub

    Private Sub RolesLoad()
        ddlRoles.DataSource = Roles.GetAllRoles()
        ddlRoles.DataBind()
    End Sub

    Sub ddlRoles_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        grdUsers.DataSource = Roles.GetUsersInRole(ddlRoles.SelectedItem.Text)
        grdUsers.DataBind()
    End Sub
End Class
