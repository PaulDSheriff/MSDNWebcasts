Partial Class AdminRoles_aspx
    Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        RolesLoad()
    End Sub

    Private Sub RolesLoad()
        grdRoles.DataSource = Roles.GetAllRoles()
        grdRoles.DataBind()
    End Sub

    Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            If Roles.RoleExists(txtRoleName.Text) Then
                lblMsg.Text = String.Format( _
                 "Role {0} already exists", txtRoleName.Text)
            Else
                Roles.CreateRole(txtRoleName.Text)
                txtRoleName.Text = String.Empty
            End If

            RolesLoad()

        Catch ex As Exception
            lblMsg.Text = ex.Message

        End Try
    End Sub
End Class
