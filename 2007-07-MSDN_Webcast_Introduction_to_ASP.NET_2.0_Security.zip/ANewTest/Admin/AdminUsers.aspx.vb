
Partial Class AdminUsers_aspx

    Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            RolesLoad()
            UserLoad()
        End If
    End Sub

    Private Sub RolesLoad()
        ddlRoles.DataSource = Roles.GetAllRoles()
        ddlRoles.DataBind()
    End Sub

    Private Sub UserLoad()
        grdUsers.DataSource = Membership.GetAllUsers()
        grdUsers.DataBind()
    End Sub

    Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim mcs As New MembershipCreateStatus
        Dim mu As MembershipUser

        Try
            mu = Membership.CreateUser(txtUserName.Text, txtPassword.Text, _
              txtEmail.Text, Nothing, Nothing, True, mcs)

            If mcs.Success = MembershipCreateStatus.DuplicateUserName Then
                lblMsg.Text = String.Format( _
                 "A user name of {0} already exists, please reenter", _
                 txtUserName.Text)

            ElseIf mcs.Success <> MembershipCreateStatus.Success Then
                lblMsg.Text = mcs.ToString()

            ElseIf mcs.Success = MembershipCreateStatus.Success Then
                ' Add User to Role
                Roles.AddUserToRole(txtUserName.Text, ddlRoles.SelectedItem.Text)

                txtUserName.Text = String.Empty
                txtEmail.Text = String.Empty
                txtPassword.Text = String.Empty

                UserLoad()
            End If

        Catch ex As MembershipCreateUserException
            For Each de As DictionaryEntry In ex.Data
                lblMsg.Text = de.Key.ToString() & " - " & de.Value.ToString()
            Next

        End Try
    End Sub
End Class
