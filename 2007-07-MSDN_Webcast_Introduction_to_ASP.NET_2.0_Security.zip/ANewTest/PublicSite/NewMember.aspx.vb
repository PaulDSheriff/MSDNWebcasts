
Partial Class NewMember_aspx

End Class
