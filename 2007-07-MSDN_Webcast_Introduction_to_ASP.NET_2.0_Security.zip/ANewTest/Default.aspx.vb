
Partial Class Default_aspx
    Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Response.Redirect("~/PublicSite/HomePage.aspx")
    End Sub
End Class
