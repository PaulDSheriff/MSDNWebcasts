Public Class frmProducts
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub
  Protected WithEvents grdProducts As System.Web.UI.WebControls.DataGrid

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    GridLoad()
  End Sub

  Private Sub GridLoad()
    Dim ds As DataSet
    Dim da As SqlClient.SqlDataAdapter
    Dim strSQL As String
    Dim strConn As String

    strSQL = "SELECT * FROM Products"
    strConn = "Server=(local);Database=Northwind;uid=sa;pwd=sa"

    Try
      ds = New DataSet
      da = New SqlClient.SqlDataAdapter(strSQL, strConn)

      da.Fill(ds)

      grdProducts.DataSource = ds
      grdProducts.DataBind()

    Catch ex As Exception
      Response.Write(ex.Message)

    End Try
  End Sub

End Class
