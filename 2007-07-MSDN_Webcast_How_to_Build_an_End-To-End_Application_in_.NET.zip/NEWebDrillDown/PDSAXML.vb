Public Class PDSAXML
  '************************************************************
  '* Function Name: FileToDataSet()
  '* Syntax       : DataSet = XMLFileToDataSet(FileName, Optional DSName)
  '* Parameters   : FileName => File where XML is located
  '*                DSName => Name for DataSet
  '*
  '* Description  :
  '* This function will read the XML file and make a DataSet out of it.
  '*
  '************************************************************
  Public Shared Function FileToDataSet(ByVal FileName As String, Optional ByVal DSName As String = "") As DataSet
    Dim ds As DataSet

    If DSName.Trim = String.Empty Then
      ds = New DataSet()
    Else
      ds = New DataSet(DSName)
    End If

    ds.ReadXml(FileName)

    Return ds
  End Function

  '************************************************************
  '* Function Name: ConvertSpecial()
  '* Syntax       : String = Convert(XMLString, ConvertDirection)
  '* Parameters   : XMLString => String of XML characters
  '*                ConvertDirection => ToSpecialChars, ToNormalChars
  '*
  '* Description  :
  '* This function will replace the special XML characters with
  '* standard XML characters.
  '*
  '************************************************************
  Public Enum XMLConvertDirection
    ToSpecialChars = 0
    ToNormalChars = 1
  End Enum

  Public Function ConvertSpecial(ByVal XMLString As String, ByVal ConvertDirection As XMLConvertDirection) As String
    If ConvertDirection = XMLConvertDirection.ToSpecialChars Then
      XMLString = XMLString.Replace("&", "&amp;")
      XMLString = XMLString.Replace("'", "&apos;")
      XMLString = XMLString.Replace("""", "&quot;")
    Else
      XMLString = XMLString.Replace("&amp;", "&")
      XMLString = XMLString.Replace("&apos;", "'")
      XMLString = XMLString.Replace("&quot;", """")
    End If

    Return XMLString
  End Function

End Class
