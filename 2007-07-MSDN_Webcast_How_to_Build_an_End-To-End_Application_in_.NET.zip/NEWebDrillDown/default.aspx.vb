Public Class _default
  Inherits System.Web.UI.Page
  Protected WithEvents lblItemNumber As System.Web.UI.WebControls.Label
  Protected WithEvents lblUPC As System.Web.UI.WebControls.Label
  Protected WithEvents lblContains As System.Web.UI.WebControls.Label
  Protected WithEvents lblCalories As System.Web.UI.WebControls.Label
  Protected WithEvents lblServings As System.Web.UI.WebControls.Label
  Protected WithEvents lblServingPrice As System.Web.UI.WebControls.Label
  Protected WithEvents Label2 As System.Web.UI.WebControls.Label
  Protected WithEvents Label3 As System.Web.UI.WebControls.Label
  Protected WithEvents Label4 As System.Web.UI.WebControls.Label
  Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
  Protected WithEvents Label5 As System.Web.UI.WebControls.Label
  Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink
  Protected WithEvents Label6 As System.Web.UI.WebControls.Label
  Protected WithEvents HyperLink3 As System.Web.UI.WebControls.HyperLink
  Protected WithEvents Label7 As System.Web.UI.WebControls.Label
  Protected WithEvents HyperLink4 As System.Web.UI.WebControls.HyperLink
  Protected WithEvents HyperLink5 As System.Web.UI.WebControls.HyperLink
  Protected WithEvents Label8 As System.Web.UI.WebControls.Label
  Protected WithEvents Label9 As System.Web.UI.WebControls.Label
  Protected WithEvents Label10 As System.Web.UI.WebControls.Label
  Protected WithEvents Label11 As System.Web.UI.WebControls.Label
  Protected WithEvents Label14 As System.Web.UI.WebControls.Label
  Protected WithEvents datWebCopy As System.Web.UI.WebControls.DataList
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents imgProduct As System.Web.UI.WebControls.Image

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    'Put user code to initialize the page here
    If Not Page.IsPostBack Then
      imgProduct.ImageUrl = "images/sampleproduct1.gif"
      imgProduct.Width = Unit.Pixel(75)
      imgProduct.Height = Unit.Pixel(130)
      imgProduct.AlternateText = "Sample ALT text for product image"

      lblItemNumber.Text = "Item No. 94-90"
      lblUPC.Text = "UPC 6 54186 09490 4"

      lblContains.Text = "2 scoops 30g Contains:"

      lblCalories.Text = "140"
      lblServings.Text = "30"
      lblServingPrice.Text = "56�"

      DataListLoad()
    End If
  End Sub

  Private Sub DataListLoad()
    Dim strFile As String
    Dim ds As DataSet

    strFile = Server.MapPath("xml/webcopy.xml")

    ds = PDSAXML.FileToDataSet(strFile)

    datWebCopy.DataSource = ds
    datWebCopy.DataBind()
  End Sub

End Class
