Public Class frmProductInsert
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents txtProductName As System.Windows.Forms.TextBox
  Friend WithEvents Label2 As System.Windows.Forms.Label
  Friend WithEvents Label3 As System.Windows.Forms.Label
  Friend WithEvents btnInsert As System.Windows.Forms.Button
  Friend WithEvents txtUnitPrice As System.Windows.Forms.TextBox
  Friend WithEvents txtUnitsInStock As System.Windows.Forms.TextBox
  Friend WithEvents chkDisc As System.Windows.Forms.CheckBox
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.txtProductName = New System.Windows.Forms.TextBox()
    Me.txtUnitPrice = New System.Windows.Forms.TextBox()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.txtUnitsInStock = New System.Windows.Forms.TextBox()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.chkDisc = New System.Windows.Forms.CheckBox()
    Me.btnInsert = New System.Windows.Forms.Button()
    Me.SuspendLayout()
    '
    'Label1
    '
    Me.Label1.Location = New System.Drawing.Point(8, 8)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(128, 24)
    Me.Label1.TabIndex = 0
    Me.Label1.Text = "Product Name"
    '
    'txtProductName
    '
    Me.txtProductName.Location = New System.Drawing.Point(144, 8)
    Me.txtProductName.Name = "txtProductName"
    Me.txtProductName.Size = New System.Drawing.Size(264, 26)
    Me.txtProductName.TabIndex = 1
    Me.txtProductName.Text = ""
    '
    'txtUnitPrice
    '
    Me.txtUnitPrice.Location = New System.Drawing.Point(144, 40)
    Me.txtUnitPrice.Name = "txtUnitPrice"
    Me.txtUnitPrice.Size = New System.Drawing.Size(264, 26)
    Me.txtUnitPrice.TabIndex = 3
    Me.txtUnitPrice.Text = ""
    '
    'Label2
    '
    Me.Label2.Location = New System.Drawing.Point(8, 40)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(128, 24)
    Me.Label2.TabIndex = 2
    Me.Label2.Text = "Unit Price"
    '
    'txtUnitsInStock
    '
    Me.txtUnitsInStock.Location = New System.Drawing.Point(144, 72)
    Me.txtUnitsInStock.Name = "txtUnitsInStock"
    Me.txtUnitsInStock.Size = New System.Drawing.Size(264, 26)
    Me.txtUnitsInStock.TabIndex = 5
    Me.txtUnitsInStock.Text = ""
    '
    'Label3
    '
    Me.Label3.Location = New System.Drawing.Point(8, 72)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(128, 24)
    Me.Label3.TabIndex = 4
    Me.Label3.Text = "Units In Stock"
    '
    'chkDisc
    '
    Me.chkDisc.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
    Me.chkDisc.Location = New System.Drawing.Point(8, 112)
    Me.chkDisc.Name = "chkDisc"
    Me.chkDisc.Size = New System.Drawing.Size(152, 24)
    Me.chkDisc.TabIndex = 6
    Me.chkDisc.Text = "Discontinued"
    '
    'btnInsert
    '
    Me.btnInsert.Location = New System.Drawing.Point(328, 128)
    Me.btnInsert.Name = "btnInsert"
    Me.btnInsert.Size = New System.Drawing.Size(80, 32)
    Me.btnInsert.TabIndex = 7
    Me.btnInsert.Text = "Insert"
    '
    'frmProductInsert
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
    Me.ClientSize = New System.Drawing.Size(424, 170)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnInsert, Me.chkDisc, Me.txtUnitsInStock, Me.Label3, Me.txtUnitPrice, Me.Label2, Me.txtProductName, Me.Label1})
    Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Name = "frmProductInsert"
    Me.Text = "Insert a Product"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub btnInsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsert.Click
    InsertProduct()
  End Sub

  Private Sub InsertProduct()
    Dim prod As localhost.ProductsWS
    Dim prodTable As localhost.ProductsTable

    Try
      prod = New localhost.ProductsWS()
      prodTable = New localhost.ProductsTable()

      With prodTable
        .ProductName = txtProductName.Text
        .UnitPrice = Convert.ToDecimal(txtUnitPrice.Text)
        .UnitsInStock = Convert.ToInt16(txtUnitsInStock.Text)
        .Discontinued = chkDisc.Checked
      End With

      prod.InsertProduct(prodTable)

      MessageBox.Show("Product Inserted")
    Catch exp As Exception
      MessageBox.Show(exp.Message)

    End Try
  End Sub

End Class
