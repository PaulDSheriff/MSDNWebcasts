Public Class ProductInsert
  Inherits System.Web.UI.Page

  Protected WithEvents btnInsert As System.Web.UI.WebControls.Button
  Protected WithEvents chkDisc As System.Web.UI.WebControls.CheckBox
  Protected WithEvents txtUnitsInStock As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label3 As System.Web.UI.WebControls.Label
  Protected WithEvents txtUnitPrice As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label2 As System.Web.UI.WebControls.Label
  Protected WithEvents txtProductName As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
  Protected WithEvents Label4 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    'Put user code to initialize the page here
  End Sub

  Private Sub btnInsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsert.Click
    Dim prod As NWBusinessLayer.Products
    Dim prodTable As NWDataLayer.ProductsTable

    Try
      prod = New NWBusinessLayer.Products()
      prodTable = New NWDataLayer.ProductsTable()

      ' Fill in the Data
      With prodTable
        .ProductName = txtProductName.Text
        .UnitPrice = Convert.ToDecimal(txtUnitPrice.Text)
        .UnitsInStock = Convert.ToInt16(txtUnitsInStock.Text)
        .Discontinued = chkDisc.Checked
      End With

      ' Perform Insert Through Business Object
      prod.Insert(prodTable)

      Response.Redirect("Default.aspx")

    Catch exp As Exception
      lblMessage.Text = exp.Message

    End Try
  End Sub
End Class
