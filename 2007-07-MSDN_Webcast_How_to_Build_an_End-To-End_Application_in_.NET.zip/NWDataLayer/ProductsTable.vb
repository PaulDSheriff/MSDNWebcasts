Public Class ProductsTable
  '******************************************************
  ' Private Data To Match the Table Definition
  '******************************************************
  Private mintProductID As Integer
  Private mstrProductName As String
  Private mintSupplierID As Integer
  Private mintCategoryID As Integer
  Private mstrQuantityPerUnit As String
  Private mcurUnitPrice As Decimal
  Private msrtUnitsInStock As Short
  Private msrtUnitsOnOrder As Short
  Private msrtReorderLevel As Short
  Private mboolDiscontinued As Boolean

  '******************************************************
  '* Properties to Match Table Definition
  '******************************************************
  Property ProductID() As Integer
    Get
      Return mintProductID
    End Get

    Set(ByVal Value As Integer)
      mintProductID = Value
    End Set
  End Property

  Property ProductName() As String
    Get
      Return mstrProductName
    End Get

    Set(ByVal Value As String)
      mstrProductName = Value
    End Set
  End Property

  Property SupplierID() As Integer
    Get
      Return mintSupplierID
    End Get

    Set(ByVal Value As Integer)
      mintSupplierID = Value
    End Set
  End Property

  Property CategoryID() As Integer
    Get
      Return mintCategoryID
    End Get

    Set(ByVal Value As Integer)
      mintCategoryID = Value
    End Set
  End Property

  Property QuantityPerUnit() As String
    Get
      Return mstrQuantityPerUnit
    End Get

    Set(ByVal Value As String)
      mstrQuantityPerUnit = Value
    End Set
  End Property

  Property UnitPrice() As Decimal
    Get
      Return mcurUnitPrice
    End Get

    Set(ByVal Value As Decimal)
      mcurUnitPrice = Value
    End Set
  End Property

  Property UnitsInStock() As Short
    Get
      Return msrtUnitsInStock
    End Get

    Set(ByVal Value As Short)
      msrtUnitsInStock = Value
    End Set
  End Property

  Property UnitsOnOrder() As Short
    Get
      Return msrtUnitsOnOrder
    End Get

    Set(ByVal Value As Short)
      msrtUnitsOnOrder = Value
    End Set
  End Property

  Property ReorderLevel() As Short
    Get
      Return msrtReorderLevel
    End Get

    Set(ByVal Value As Short)
      msrtReorderLevel = Value
    End Set
  End Property

  Property Discontinued() As Boolean
    Get
      Return mboolDiscontinued
    End Get

    Set(ByVal Value As Boolean)
      mboolDiscontinued = Value
    End Set
  End Property

End Class
