Imports Microsoft.ApplicationBlocks.Data
Imports Common
Public Class ProductsData
  Public Function GetDataSet() As DataSet
    Dim strSQL As String

    strSQL = "SELECT * FROM Products"

    Try
      Return SqlHelper.ExecuteDataset(ConfigInfo.ConnectString, CommandType.Text, strSQL)

    Catch exp As Exception
      Throw exp

    End Try
  End Function

  Public Sub Insert(ByVal prodTable As NWDataLayer.ProductsTable)
    Dim strSQL As String

    strSQL = "INSERT INTO Products ("
    strSQL &= "ProductName, "
    strSQL &= "UnitPrice, "
    strSQL &= "UnitsInStock, "
    strSQL &= "Discontinued "
    strSQL &= ") VALUES ("
    strSQL &= "'" & prodTable.ProductName & "', "
    strSQL &= prodTable.UnitPrice & ", "
    strSQL &= prodTable.UnitsInStock & ", "
    strSQL &= IIf(prodTable.Discontinued, 1, 0).ToString() & " )"

    Try
      SqlHelper.ExecuteNonQuery(ConfigInfo.ConnectString, CommandType.Text, strSQL)

    Catch exp As Exception
      Throw exp

    End Try
  End Sub

  Public Sub Delete(ByVal prodTable As NWDataLayer.ProductsTable)
    Dim strSQL As String

    strSQL = "DELETE FROM Products "
    strSQL &= " WHERE ProductID = " & prodTable.ProductID

    Try
      SqlHelper.ExecuteNonQuery(ConfigInfo.ConnectString, CommandType.Text, strSQL)

    Catch exp As Exception
      Throw exp

    End Try
  End Sub

End Class
