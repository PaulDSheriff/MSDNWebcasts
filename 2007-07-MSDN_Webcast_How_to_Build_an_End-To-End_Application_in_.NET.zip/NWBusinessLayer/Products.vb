Public Class Products
  Public Function GetDataSet() As DataSet
    Dim prod As New NWDataLayer.ProductsData()

    Try
      Return prod.GetDataSet()

    Catch exp As Exception
      Throw exp

    End Try
  End Function

  Public Sub Insert(ByVal prodTable As NWDataLayer.ProductsTable)
    Dim prod As New NWDataLayer.ProductsData()

    Try
      Validate(prodTable)

      prod.Insert(prodTable)

    Catch exp As Exception
      Throw exp

    End Try
  End Sub

  Public Sub Validate(ByVal prodTable As NWDataLayer.ProductsTable)
    Dim strMsg As String = ""

    ' Check Business Rules
    If prodTable.ProductName.Trim = "" Then
      strMsg = "Product Name Must Be Filled In"
    End If

    If strMsg.Trim <> "" Then
      Throw New Exception(strMsg)
    End If
  End Sub

  Public Sub Delete(ByVal prodTable As NWDataLayer.ProductsTable)
    Dim prod As New NWDataLayer.ProductsData()

    Try
      prod.Delete(prodTable)

    Catch exp As Exception
      Throw exp

    End Try
  End Sub

End Class
