Imports System.Runtime.Remoting
Imports System.Runtime.Remoting.Channels

Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents TextUserName As System.Web.UI.WebControls.TextBox
    Protected WithEvents LabelFirstName As System.Web.UI.WebControls.Label
    Protected WithEvents LabelLastName As System.Web.UI.WebControls.Label
    Protected WithEvents LabelAge As System.Web.UI.WebControls.Label
    Protected WithEvents ButtonRetrieve As System.Web.UI.WebControls.Button
    Protected WithEvents LabelA As System.Web.UI.WebControls.Label
    Protected WithEvents LabelLN As System.Web.UI.WebControls.Label
    Protected WithEvents LabelFN As System.Web.UI.WebControls.Label
    Protected WithEvents RequiredFieldValidator1 As System.Web.UI.WebControls.RequiredFieldValidator

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub ButtonRetrieve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonRetrieve.Click
        Dim remoteObject As RemoteUserData.UserData
        Dim localHolder As RemoteUserData.UserDataHolder

        remoteObject = Activator.GetObject(GetType(RemoteUserData.UserData), _
            "http://localhost/RemoteUserData/UserData.rem")
        localHolder = remoteObject.GetUserData(TextUserName.Text)
        remoteObject = Nothing

        LabelFirstName.Text = localHolder.FirstName
        LabelLastName.Text = localHolder.LastName
        LabelAge.Text = localHolder.Age.ToString()

        LabelFN.Enabled = True
        LabelLN.Enabled = True
        LabelA.Enabled = True
    End Sub

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not (Page.IsPostBack) Then
            RemotingConfiguration.RegisterWellKnownClientType( _
                GetType(RemoteUserData.UserData), _
                "http://localhost/RemoteUserData")
        End If
    End Sub
End Class
