Option Strict On

<Serializable()> _
Public Class UserDataHolder
  Public FirstName As String = ""
  Public LastName As String = ""
  Public Age As Integer = 0
End Class

Public Class UserData
  Inherits MarshalByRefObject

  Public Function GetUserData(ByVal Username As String) As UserDataHolder
    Dim vb6Object As VB6.BusinessComponentClass
    Dim vb6Age As Short
    Dim myHolder As UserDataHolder

    myHolder = New UserDataHolder()
    vb6Object = New VB6.BusinessComponentClass()
    vb6Object.GetUserData(Username, myHolder.FirstName, myHolder.LastName, vb6Age)

    ' Release COM object
    'System.Runtime.InteropServices. _
    '  Marshal.ReleaseComObject(vb6Object)
    vb6Object = Nothing

    myHolder.Age = CType(vb6Age, Integer)

    Return (myHolder)
  End Function

End Class
