Option Strict On

Imports Microsoft.ApplicationBlocks.Data

Public Class DUser
    ' This is the Data logic class for User Management.
    ' This class uses the Microsoft Data Access Application Block, downloadable
    ' from Microsoft.com.

    Private Const CONN_STR As String = "server=(local);database=UserSample;Integrated Security=true;"

    Public Sub AddNew(ByVal Username As String, ByVal FirstName As String, ByVal LastName As String, ByVal Age As Integer)
        Dim commandText As String

        commandText = "sp_UserData_AddNew " _
            + "'" + Username + "', " _
            + "'" + FirstName + "', " _
            + "'" + LastName + "', " _
            + Age.ToString()
        SqlHelper.ExecuteNonQuery(CONN_STR, CommandType.Text, commandText)
    End Sub

    Public Function GetAll() As System.Data.DataSet
        Return (SqlHelper.ExecuteDataset(CONN_STR, CommandType.StoredProcedure, "sp_UserData_GetAll"))
    End Function

End Class
