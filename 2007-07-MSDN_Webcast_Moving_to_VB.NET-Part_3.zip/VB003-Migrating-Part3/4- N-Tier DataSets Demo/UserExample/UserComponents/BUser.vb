Option Strict On

Imports System.Data

Public Class BUser
    'This is the Business logic class for User Management.

    Public Sub AddNew(ByVal Username As String, ByVal FirstName As String, ByVal LastName As String, ByVal Age As Integer)
        Dim dataAccess As DUser
        Dim safeUsername As String
        Dim safeFirstName As String
        Dim safeLastName As String

        safeUsername = Username.Replace("'", "''")
        safeFirstName = FirstName.Replace("'", "''")
        safeLastName = LastName.Replace("'", "''")

        dataAccess = New DUser()
        dataAccess.AddNew(safeUsername, safeFirstName, safeLastName, Age)
        dataAccess = Nothing
    End Sub

    Public Function GetAll() As DataSet
        Dim dataAccess As DUser
        Dim result As DataSet

        dataAccess = New DUser()
        result = dataAccess.GetAll()
        dataAccess = Nothing

        Return (result)
    End Function

End Class
