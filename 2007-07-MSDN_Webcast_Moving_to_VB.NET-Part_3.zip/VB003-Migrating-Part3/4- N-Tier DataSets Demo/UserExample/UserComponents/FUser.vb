Option Strict On

Imports System.EnterpriseServices
Imports System.Data

<Transaction(TransactionOption.Supported)> _
Public Class FUser
    Inherits ServicedComponent
    ' This is the Business fa�ade class for User Management.
    '
    ' Note that this class supports transactions and transactional methods use
    ' AutoComplete.

    <AutoComplete()> _
    Public Sub AddNew(ByVal Username As String, ByVal FirstName As String, ByVal LastName As String, ByVal Age As Integer)
        'This function adds a new user.
        Dim biz As BUser

        biz = New BUser()
        biz.AddNew(Username, FirstName, LastName, Age)
        biz = Nothing
    End Sub

    Public Function GetAllUsers() As DataSet
        'This function gets all users in a DataSet.

        Dim biz As BUser
        Dim result As DataSet

        biz = New BUser()
        result = biz.GetAll()
        biz = Nothing

        Return (result)
    End Function

End Class
