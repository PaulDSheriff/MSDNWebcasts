Public Class frmMain
  Inherits System.Windows.Forms.Form

  Const CONN_STR As String = "Server=(local);Database=Northwind;uid=sa;pwd=sa"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
  Friend WithEvents btnRegular As System.Windows.Forms.Button
  Friend WithEvents btnTyped As System.Windows.Forms.Button
  Friend WithEvents da As System.Data.SqlClient.SqlDataAdapter
  Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
  Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
  Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
  Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
  Friend WithEvents cnn As System.Data.SqlClient.SqlConnection
  Friend WithEvents DsProducts1 As TypedDataSetExample.dsProducts
  Friend WithEvents btnFromDL As System.Windows.Forms.Button
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.btnRegular = New System.Windows.Forms.Button
    Me.btnTyped = New System.Windows.Forms.Button
    Me.da = New System.Data.SqlClient.SqlDataAdapter
    Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
    Me.cnn = New System.Data.SqlClient.SqlConnection
    Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
    Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
    Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
    Me.DsProducts1 = New TypedDataSetExample.dsProducts
    Me.btnFromDL = New System.Windows.Forms.Button
    CType(Me.DsProducts1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'btnRegular
    '
    Me.btnRegular.Location = New System.Drawing.Point(8, 8)
    Me.btnRegular.Name = "btnRegular"
    Me.btnRegular.Size = New System.Drawing.Size(96, 48)
    Me.btnRegular.TabIndex = 0
    Me.btnRegular.Text = "Regular DataSet"
    '
    'btnTyped
    '
    Me.btnTyped.Location = New System.Drawing.Point(112, 8)
    Me.btnTyped.Name = "btnTyped"
    Me.btnTyped.Size = New System.Drawing.Size(88, 48)
    Me.btnTyped.TabIndex = 1
    Me.btnTyped.Text = "Typed DataSet"
    '
    'da
    '
    Me.da.DeleteCommand = Me.SqlDeleteCommand1
    Me.da.InsertCommand = Me.SqlInsertCommand1
    Me.da.SelectCommand = Me.SqlSelectCommand1
    Me.da.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Products", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ProductID", "ProductID"), New System.Data.Common.DataColumnMapping("ProductName", "ProductName"), New System.Data.Common.DataColumnMapping("SupplierID", "SupplierID"), New System.Data.Common.DataColumnMapping("CategoryID", "CategoryID"), New System.Data.Common.DataColumnMapping("QuantityPerUnit", "QuantityPerUnit"), New System.Data.Common.DataColumnMapping("UnitPrice", "UnitPrice"), New System.Data.Common.DataColumnMapping("UnitsInStock", "UnitsInStock"), New System.Data.Common.DataColumnMapping("UnitsOnOrder", "UnitsOnOrder"), New System.Data.Common.DataColumnMapping("ReorderLevel", "ReorderLevel"), New System.Data.Common.DataColumnMapping("Discontinued", "Discontinued")})})
    Me.da.UpdateCommand = Me.SqlUpdateCommand1
    '
    'SqlDeleteCommand1
    '
    Me.SqlDeleteCommand1.CommandText = "DELETE FROM Products WHERE (ProductID = @Original_ProductID) AND (CategoryID = @O" & _
    "riginal_CategoryID OR @Original_CategoryID IS NULL AND CategoryID IS NULL) AND (" & _
    "Discontinued = @Original_Discontinued) AND (ProductName = @Original_ProductName)" & _
    " AND (QuantityPerUnit = @Original_QuantityPerUnit OR @Original_QuantityPerUnit I" & _
    "S NULL AND QuantityPerUnit IS NULL) AND (ReorderLevel = @Original_ReorderLevel O" & _
    "R @Original_ReorderLevel IS NULL AND ReorderLevel IS NULL) AND (SupplierID = @Or" & _
    "iginal_SupplierID OR @Original_SupplierID IS NULL AND SupplierID IS NULL) AND (U" & _
    "nitPrice = @Original_UnitPrice OR @Original_UnitPrice IS NULL AND UnitPrice IS N" & _
    "ULL) AND (UnitsInStock = @Original_UnitsInStock OR @Original_UnitsInStock IS NUL" & _
    "L AND UnitsInStock IS NULL) AND (UnitsOnOrder = @Original_UnitsOnOrder OR @Origi" & _
    "nal_UnitsOnOrder IS NULL AND UnitsOnOrder IS NULL)"
    Me.SqlDeleteCommand1.Connection = Me.cnn
    Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ProductID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductID", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CategoryID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoryID", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Discontinued", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Discontinued", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ProductName", System.Data.SqlDbType.NVarChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductName", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_QuantityPerUnit", System.Data.SqlDbType.NVarChar, 20, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "QuantityPerUnit", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ReorderLevel", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ReorderLevel", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_SupplierID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SupplierID", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UnitPrice", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UnitPrice", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UnitsInStock", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UnitsInStock", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UnitsOnOrder", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UnitsOnOrder", System.Data.DataRowVersion.Original, Nothing))
    '
    'cnn
    '
    Me.cnn.ConnectionString = "workstation id=PDSATOSHIBA7;packet size=4096;user id=sa;data source=""(local)"";per" & _
    "sist security info=True;initial catalog=Northwind;password=sa"
    '
    'SqlInsertCommand1
    '
    Me.SqlInsertCommand1.CommandText = "INSERT INTO Products(ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPr" & _
    "ice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued) VALUES (@ProductNam" & _
    "e, @SupplierID, @CategoryID, @QuantityPerUnit, @UnitPrice, @UnitsInStock, @Units" & _
    "OnOrder, @ReorderLevel, @Discontinued); SELECT ProductID, ProductName, SupplierI" & _
    "D, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLe" & _
    "vel, Discontinued FROM Products WHERE (ProductID = @@IDENTITY)"
    Me.SqlInsertCommand1.Connection = Me.cnn
    Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProductName", System.Data.SqlDbType.NVarChar, 40, "ProductName"))
    Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SupplierID", System.Data.SqlDbType.Int, 4, "SupplierID"))
    Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoryID", System.Data.SqlDbType.Int, 4, "CategoryID"))
    Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@QuantityPerUnit", System.Data.SqlDbType.NVarChar, 20, "QuantityPerUnit"))
    Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitPrice", System.Data.SqlDbType.Money, 8, "UnitPrice"))
    Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitsInStock", System.Data.SqlDbType.SmallInt, 2, "UnitsInStock"))
    Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitsOnOrder", System.Data.SqlDbType.SmallInt, 2, "UnitsOnOrder"))
    Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReorderLevel", System.Data.SqlDbType.SmallInt, 2, "ReorderLevel"))
    Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Discontinued", System.Data.SqlDbType.Bit, 1, "Discontinued"))
    '
    'SqlSelectCommand1
    '
    Me.SqlSelectCommand1.CommandText = "SELECT ProductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice" & _
    ", UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued FROM Products"
    Me.SqlSelectCommand1.Connection = Me.cnn
    '
    'SqlUpdateCommand1
    '
    Me.SqlUpdateCommand1.CommandText = "UPDATE Products SET ProductName = @ProductName, SupplierID = @SupplierID, Categor" & _
    "yID = @CategoryID, QuantityPerUnit = @QuantityPerUnit, UnitPrice = @UnitPrice, U" & _
    "nitsInStock = @UnitsInStock, UnitsOnOrder = @UnitsOnOrder, ReorderLevel = @Reord" & _
    "erLevel, Discontinued = @Discontinued WHERE (ProductID = @Original_ProductID) AN" & _
    "D (CategoryID = @Original_CategoryID OR @Original_CategoryID IS NULL AND Categor" & _
    "yID IS NULL) AND (Discontinued = @Original_Discontinued) AND (ProductName = @Ori" & _
    "ginal_ProductName) AND (QuantityPerUnit = @Original_QuantityPerUnit OR @Original" & _
    "_QuantityPerUnit IS NULL AND QuantityPerUnit IS NULL) AND (ReorderLevel = @Origi" & _
    "nal_ReorderLevel OR @Original_ReorderLevel IS NULL AND ReorderLevel IS NULL) AND" & _
    " (SupplierID = @Original_SupplierID OR @Original_SupplierID IS NULL AND Supplier" & _
    "ID IS NULL) AND (UnitPrice = @Original_UnitPrice OR @Original_UnitPrice IS NULL " & _
    "AND UnitPrice IS NULL) AND (UnitsInStock = @Original_UnitsInStock OR @Original_U" & _
    "nitsInStock IS NULL AND UnitsInStock IS NULL) AND (UnitsOnOrder = @Original_Unit" & _
    "sOnOrder OR @Original_UnitsOnOrder IS NULL AND UnitsOnOrder IS NULL); SELECT Pro" & _
    "ductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsIn" & _
    "Stock, UnitsOnOrder, ReorderLevel, Discontinued FROM Products WHERE (ProductID =" & _
    " @ProductID)"
    Me.SqlUpdateCommand1.Connection = Me.cnn
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProductName", System.Data.SqlDbType.NVarChar, 40, "ProductName"))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SupplierID", System.Data.SqlDbType.Int, 4, "SupplierID"))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CategoryID", System.Data.SqlDbType.Int, 4, "CategoryID"))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@QuantityPerUnit", System.Data.SqlDbType.NVarChar, 20, "QuantityPerUnit"))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitPrice", System.Data.SqlDbType.Money, 8, "UnitPrice"))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitsInStock", System.Data.SqlDbType.SmallInt, 2, "UnitsInStock"))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitsOnOrder", System.Data.SqlDbType.SmallInt, 2, "UnitsOnOrder"))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReorderLevel", System.Data.SqlDbType.SmallInt, 2, "ReorderLevel"))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Discontinued", System.Data.SqlDbType.Bit, 1, "Discontinued"))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ProductID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductID", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CategoryID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CategoryID", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Discontinued", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Discontinued", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ProductName", System.Data.SqlDbType.NVarChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductName", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_QuantityPerUnit", System.Data.SqlDbType.NVarChar, 20, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "QuantityPerUnit", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ReorderLevel", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ReorderLevel", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_SupplierID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "SupplierID", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UnitPrice", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UnitPrice", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UnitsInStock", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UnitsInStock", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UnitsOnOrder", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UnitsOnOrder", System.Data.DataRowVersion.Original, Nothing))
    Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProductID", System.Data.SqlDbType.Int, 4, "ProductID"))
    '
    'DsProducts1
    '
    Me.DsProducts1.DataSetName = "dsProducts"
    Me.DsProducts1.Locale = New System.Globalization.CultureInfo("en-US")
    '
    'btnFromDL
    '
    Me.btnFromDL.Location = New System.Drawing.Point(208, 8)
    Me.btnFromDL.Name = "btnFromDL"
    Me.btnFromDL.Size = New System.Drawing.Size(152, 48)
    Me.btnFromDL.TabIndex = 2
    Me.btnFromDL.Text = "Typed DataSet From Data Layer"
    '
    'frmMain
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
    Me.ClientSize = New System.Drawing.Size(384, 66)
    Me.Controls.Add(Me.btnFromDL)
    Me.Controls.Add(Me.btnTyped)
    Me.Controls.Add(Me.btnRegular)
    Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Name = "frmMain"
    Me.Text = "Typed DataSet Example"
    CType(Me.DsProducts1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)

  End Sub

#End Region


  Private Sub btnRegular_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRegular.Click
    Dim ds As New DataSet
    Dim dr As DataRow

    da.Fill(ds)

    For Each dr In ds.Tables(0).Rows
      Debug.WriteLine(dr.Item("ProductName"))
    Next
  End Sub

  Private Sub btnTyped_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTyped.Click
    Dim dr As dsProducts.ProductsRow

    da.Fill(DsProducts1)

    For Each dr In DsProducts1.Products.Rows
      Debug.WriteLine(dr.ProductName)
    Next
  End Sub

  Private Sub btnFromDL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFromDL.Click
    Dim prod As New DataLayer.Products
    Dim dr As DataLayer.dsProducts.ProductsRow

    For Each dr In prod.GetProducts().Products.Rows
      Debug.WriteLine(dr.ProductName)
    Next
  End Sub
End Class
