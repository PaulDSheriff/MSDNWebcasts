Option Explicit On 

Imports System.Data

Public Class WebForm1
  Inherits System.Web.UI.Page

    Protected WithEvents ButtonAddNew As System.Web.UI.WebControls.Button
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents DataGridUsers As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub ButtonAddNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonAddNew.Click
        Server.Transfer("NewUser.aspx", False)
    End Sub

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim userFacade As UserComponents.FUser
        Dim allUsers As DataSet

        Response.Clear()

        If Session("UsersDatasource") Is Nothing Then
            userFacade = New UserComponents.FUser()
            allUsers = userFacade.GetAllUsers()
            Session("UsersDatasource") = allUsers
            userFacade = Nothing
        Else
            allUsers = Session("UsersDatasource")
        End If

        DataGridUsers.DataSource = allUsers
        DataGridUsers.DataBind()

        If allUsers.Tables.Count = 0 Then
            Label1.Text = "No users found"
        End If
    End Sub

End Class
