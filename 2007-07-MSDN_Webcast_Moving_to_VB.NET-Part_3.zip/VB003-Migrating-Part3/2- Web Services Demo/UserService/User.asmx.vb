Imports System.Web.Services

<WebService(Namespace:="http://examples.microsoft.net")> _
Public Class User
  Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Web Services Designer.
    InitializeComponent()

    'Add your own initialization code after the InitializeComponent() call

  End Sub

  'Required by the Web Services Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Web Services Designer
  'It can be modified using the Web Services Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    components = New System.ComponentModel.Container()
  End Sub

  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    'CODEGEN: This procedure is required by the Web Services Designer
    'Do not modify it using the code editor.
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

#End Region

  <WebMethod()> _
  Public Sub GetUserData(ByVal Username As String, _
      ByRef FirstName As String, ByRef LastName As String, _
      ByRef Age As Integer)
    Dim vb6Biz As VB6.BusinessComponentClass

    vb6Biz = New VB6.BusinessComponentClass()
    vb6Biz.GetUserData(Username, FirstName, LastName, Age)

    ' Release the COM object
    System.Runtime.InteropServices. _
      Marshal.ReleaseComObject(vb6Biz)
    vb6Biz = Nothing

  End Sub

End Class
