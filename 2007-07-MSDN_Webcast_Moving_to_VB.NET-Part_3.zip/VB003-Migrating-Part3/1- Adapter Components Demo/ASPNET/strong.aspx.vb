Option Strict On

Public Class strong
  Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Dim strongComp As VBNET.MyStrongComponent
    Dim inputArray(4) As String
    Dim outputArray() As String
    Dim counter As Integer

    inputArray(0) = "happy"
    inputArray(1) = "wild"
    inputArray(2) = "amazed"
    inputArray(3) = "empowered"

    strongComp = New VBNET.MyStrongComponent()
    outputArray = strongComp.UpdatedData("Nigel", 24, inputArray)

    For counter = LBound(outputArray) To UBound(outputArray)
      Response.Write(outputArray(counter) + "<BR/>")
    Next
  End Sub

End Class
