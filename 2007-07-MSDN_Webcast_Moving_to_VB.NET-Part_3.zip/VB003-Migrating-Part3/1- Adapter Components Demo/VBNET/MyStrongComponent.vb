Public Class MyStrongComponent

  Public Function UpdatedData(ByVal Name As String, _
   ByVal Age As Integer, ByVal MyDataArray() As String) As String()
    Dim oldComponent As VB6.MyWeakComponentClass
    Dim returnObject As Object
    Dim resultArray() As String

    oldComponent = New VB6.MyWeakComponentClass()
    resultArray = oldComponent.UpdatedData(Name, Age, MyDataArray)

    ' Be sure to release COM object
    System.Runtime.InteropServices. _
     Marshal.ReleaseComObject(oldComponent)
    oldComponent = Nothing

    Return resultArray
  End Function
End Class
