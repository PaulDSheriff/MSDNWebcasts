using System;

using System.Data;
using System.Web.Mail;
using System.Security.Principal;
using System.Collections.Specialized;
using Microsoft.ApplicationBlocks.ExceptionManagement;

namespace ErrorCommonCS
{
	/// <summary>
	/// Summary description for emSQL.
	/// </summary>
	public class emEmail : IExceptionPublisher
	{
		public emEmail()
		{
		}

		void IExceptionPublisher.Publish(Exception appEx, 
			NameValueCollection additionalInfo, 
			NameValueCollection configSettings)
		{
			string strFromEmail = string.Empty;
			string strToEmail = string.Empty;
			string strSubject = string.Empty;
			string strSMTP = string.Empty;
			string strClassName = string.Empty;
			string strAppName = string.Empty;
			string strUserName = string.Empty;
		
			if (additionalInfo != null)
			{
				// Retrieve Additional Info
				strClassName = additionalInfo["ClassName"];
				strUserName = additionalInfo["UserName"];
				strAppName = additionalInfo["AppName"];
			}

			if (configSettings != null)
			{
				// Get Information from <Publisher> element
				strFromEmail = configSettings["FromEMail"];
				strToEmail = configSettings["ToEMail"];
				strSubject = configSettings["Subject"];
				strSMTP = configSettings["SMTPServer"];
			}

			strSubject += " - " + strClassName + " - " + strAppName;

			// Send Exception via Email
			SmtpMail.SmtpServer = strSMTP;
			SmtpMail.Send(strFromEmail, strToEmail, 
				strSubject, appEx.ToString());

		}
	}
}
