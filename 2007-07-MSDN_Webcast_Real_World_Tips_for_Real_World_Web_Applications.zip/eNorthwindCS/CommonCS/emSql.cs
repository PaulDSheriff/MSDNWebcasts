using System;
using System.Collections.Specialized;
using Microsoft.ApplicationBlocks.ExceptionManagement;

namespace CommonCS
{
	/// <summary>
	/// Summary description for emSQL.
	/// </summary>
	public class emSql : IExceptionPublisher
	{
		public emSql()
		{
		}

		void IExceptionPublisher.Publish(Exception appEx, NameValueCollection additionalInfo, NameValueCollection configSettings)
		{
			string strConnect = string.Empty;
			string strClassName = string.Empty;
			string strAppName = string.Empty;
			string strUserName = string.Empty;
			WebErrorLogDC dc;

			if (configSettings != null)
			{
				// Get Information from <Publisher> element
				strConnect = configSettings["SQLConnect"];
			}

			if (additionalInfo != null)
			{
				// Retrieve Additional Info
				strClassName = additionalInfo["ClassName"];
				strUserName = additionalInfo["UserName"];
				strAppName = additionalInfo["AppName"];
			}

			dc = new WebErrorLogDC(strConnect);
			dc.ExceptionObject = appEx;
			dc.ClassName = strClassName;
			dc.AppName = strAppName;
			dc.UserName = strUserName;
			dc.Insert();
		}
	}
}
