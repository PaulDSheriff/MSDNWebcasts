using System;
using System.Data;

using DataLayerCS;

namespace CommonCS
{
	/// <summary>
	/// Summary description for WebUserLogDC.
	/// </summary>
	public class WebUserLogDC
	{
		private string mConnectString;
    
		public WebUserLogDC(string ConnectString)
		{
			mConnectString = ConnectString;
		}

		private string mClassName;
		private string mUserName;
		private string mAppName;

		public string ClassName
		{
			get { return mClassName; }
			set { mClassName = value; }
		}

		public string UserName
		{
			get { return mUserName; }
			set { mUserName = value; }
		}

		public string AppName
		{
			get { return mAppName; }
			set { mAppName = value; }
		}

		// DEMO: 05.2-The Insert method will track user statistics
		public void Insert()
		{
			string sql;

			sql = "INSERT INTO WebUserLog(";
			sql += " sUserName, sClassName, sAppName, dtEntryDate) ";
			sql += " VALUES('{0}', '{1}', '{2}', '{3}')";

			sql = string.Format(sql, mUserName, mClassName,
				mAppName, DateTime.Now.ToString());

			SqlHelper.ExecuteSQL(sql, mConnectString);
		}
	}
}
