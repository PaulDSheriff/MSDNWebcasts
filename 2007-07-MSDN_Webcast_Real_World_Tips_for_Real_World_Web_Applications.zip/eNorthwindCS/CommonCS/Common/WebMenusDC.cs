using System;
using System.Data;

using DataLayerCS;

namespace CommonCS
{
  /// <summary>
  /// Summary description for WebMenusDC.
  /// </summary>
  public class WebMenusDC
  {
    private string mConnectString;

    public WebMenusDC(string ConnectString)
    {
      mConnectString = ConnectString;
    }

    public IDataReader GetMenusByMenuName(string MenuName)
    {
      string sql;

      sql = "SELECT RTrim(sMenuText) As sMenuText, ";
      sql += " RTrim(sAction) As sAction";
      sql += " FROM WebMenus ";
      sql += " WHERE sMenuName = '{0}' ";
      sql += " ORDER BY srtSeqNum";

      sql = string.Format(sql, MenuName);

      return SqlHelper.GetDataReader(sql, mConnectString);
    }
  }
}
