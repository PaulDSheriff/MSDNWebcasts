using System;
using System.Data;

using DataLayerCS;

namespace CommonCS
{
	/// <summary>
	/// Summary description for WebErrorLogDC.
	/// </summary>
  public class WebErrorLogDC
  {

    private string mConnectString;

    public WebErrorLogDC(string ConnectString)
    {
      mConnectString = ConnectString;
    }

    private string mClassName;
    private string mUserName;
    private string mAppName;
    private Exception mex;

    public string ClassName
    {
      get { return mClassName; }
      set { mClassName = value; }
    }

    public string UserName
    {
      get { return mUserName; }
      set { mUserName = value; }
    }

    public string AppName
    {
      get { return mAppName; }
      set { mAppName = value; }
    }

    public Exception ExceptionObject
    {
      get { return mex;}
      set { mex = value;}
    }

    public void Insert()
    {
      string sql;

      sql = "INSERT INTO WebErrorLog ";
      sql += " (sUserName, sClassName, dtErrorDate, ";
      sql += " sAppName, sErrorText) ";
      sql += " VALUES('{0}', '{1}', '{2}', '{3}', '{4}')";

      sql = string.Format(sql, mUserName, mClassName, 
        DateTime.Now.ToString(), mAppName, 
        mex.ToString().Replace("'", "''"));

      SqlHelper.ExecuteSQL(sql, mConnectString);
    }
  }
}
