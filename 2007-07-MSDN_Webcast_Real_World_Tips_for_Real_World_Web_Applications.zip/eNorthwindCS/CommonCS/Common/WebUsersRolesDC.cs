using System;
using System.Data;

using DataLayerCS;

namespace CommonCS
{
  /// <summary>
  /// Summary description for WebUserRolesDC.
  /// </summary>
  public class WebUsersRolesDC
  {
    private string mConnectString;

    public WebUsersRolesDC(string ConnectString)
    {
      mConnectString = ConnectString;
    }

    public IDataReader GetAllUsers()
    {
      return SqlHelper.GetDataReader( 
        "SELECT * FROM WebUsersRoles", mConnectString);
    }

    public string GetRoleByLoginID(string LoginID)
    {
      string sql;

      sql = "SELECT RoleName FROM WebUsersRoles ";
      sql += " WHERE LoginID = '{0}' ";
      sql = string.Format(sql, LoginID);

      return Convert.ToString(
        SqlHelper.ExecuteScalar(sql, mConnectString));
    }

    public bool Exists(string LoginID)
    {
      string sql;

      sql = "SELECT Count(*) FROM WebUsersRoles ";
      sql += " WHERE LoginID = '{0}' ";
      sql = string.Format(sql, LoginID);

      return (Convert.ToInt32(
        SqlHelper.ExecuteScalar(sql, mConnectString)) > 0);
    }
  }
}
