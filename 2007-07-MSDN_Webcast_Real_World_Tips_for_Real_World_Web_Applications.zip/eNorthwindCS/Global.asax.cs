using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;
using System.Security.Principal;

using NorthwindDataLayerCS;
using WebCommonCS;
using CommonCS;

namespace eNorthwindCS 
{
	/// <summary>
	/// Summary description for Global.
	/// </summary>
	public class Global : System.Web.HttpApplication
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		public Global()
		{
			InitializeComponent();
		}	
		
		protected void Session_Start(Object sender, EventArgs e)
		{
			WebSessionInfo.LastCustomerID = "ALFKI";
			WebSessionInfo.LastPage = "Default";
		}

		protected void Application_AuthenticateRequest(Object sender, EventArgs e)
		{
			string[] astrRoles;
			GenericIdentity gi;

			if (Request.IsAuthenticated)
			{
				astrRoles = BuildRole();

				gi = new GenericIdentity(User.Identity.Name);
				Context.User = new GenericPrincipal(gi, astrRoles);														}
		}

		private string[] BuildRole()
		{
			string strRole;
			WebUsersRolesDC dc;
			string[] astrRoles;

			try
			{
				dc = new WebUsersRolesDC(WebAppConfig.ConnectString);
				strRole = dc.GetRoleByLoginID(User.Identity.Name);
				astrRoles = new String[] {strRole};

				return astrRoles;
			}

			catch (Exception ex)
			{
				throw ex;
			}
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
		}
		#endregion
	}
}

