using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NorthwindDataLayerCS;
using WebCommonCS;

namespace eNorthwindCS.Main
{
	/// <summary>
	/// Summary description for _Default.
	/// </summary>
	// DEMO: 04.1-Inherit from your own base page class
	public class HomePage : WebPageBase
	{
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid grdProducts;
		protected System.Web.UI.WebControls.DropDownList ddlCategories;
		protected System.Web.UI.WebControls.Label Label1;
  
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				// DEMO: 01.1-Load Categories Call
				LoadCategories();
				LoadProducts();
			}
		}

		private void LoadCategories()
		{
			IDataReader dr;

			try
			{
				// DEMO: 01.2-CategoriesDC Class
				// DEMO: 02.1-Here is the call to WebAppConfig.ConnectString
				// DEMO: 06.3-Comment out the following to show exception handling
				CategoriesDC cat = new CategoriesDC(WebAppConfig.ConnectString);
				dr = cat.GetCategories();

				ddlCategories.DataTextField = "CategoryName";
				ddlCategories.DataValueField = "CategoryID";
				ddlCategories.DataSource = dr;
				ddlCategories.DataBind();

				dr.Close();
			}
			catch (Exception ex)
			{
	         // DEMO: 06.1-Call PublishException for all Exceptions
				WebException.Publish(ex);
			}
		}

		private void LoadProducts()
		{
			IDataReader dr;

			// DEMO: 08.1-Example routine with no Try...Catch
			// NOTE: NO EXCEPTION HANDLING IN THIS ROUTINE!
			// Any errors will be caught by OnError() in Base Page Class
			// Comment the following line out to show exception 
			ProductsDC prod = new ProductsDC(WebAppConfig.ConnectString);
			// ProductsDC prod = new ProductsDC("");

			dr = prod.GetProductsByCategory(Convert.ToInt32(ddlCategories.SelectedItem.Value));

			grdProducts.DataSource = dr;
			grdProducts.DataBind();

			dr.Close();
		}

    #region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ddlCategories.SelectedIndexChanged += new System.EventHandler(this.ddlCategories_SelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
    #endregion

		private void ddlCategories_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			LoadProducts();
		}
	}
}
