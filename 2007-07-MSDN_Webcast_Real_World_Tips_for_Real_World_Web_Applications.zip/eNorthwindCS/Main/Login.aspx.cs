using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using System.Security.Principal;
using System.Web.Security;
using WebCommonCS;
using CommonCS;

namespace eNorthwindCS.Main
{
	/// <summary>
	/// Summary description for Login.
	/// </summary>
	public class Login : WebPageBase
	{
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.TextBox txtLogin;
		protected System.Web.UI.WebControls.Button btnLogin;
		protected System.Web.UI.WebControls.Label lblMessage;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		// DEMO: 09.3-Validate user credentials
		private void btnLogin_Click(object sender, System.EventArgs e)
		{
			if (LoginValid())
				FormsAuthentication.RedirectFromLoginPage(txtLogin.Text, false);
			else
				lblMessage.Text = "Invalid LoginID";
		}

		private bool LoginValid()
		{
			WebUsersRolesDC dc;
			bool boolRet = false;

			try
			{
				dc = new WebUsersRolesDC(WebAppConfig.ConnectString);

				boolRet = dc.Exists(txtLogin.Text);
			}
			catch (Exception ex)
			{
				WebException.Publish(ex);

				lblMessage.Text = ex.Message;
			}

			return boolRet;
		}
	}
}
