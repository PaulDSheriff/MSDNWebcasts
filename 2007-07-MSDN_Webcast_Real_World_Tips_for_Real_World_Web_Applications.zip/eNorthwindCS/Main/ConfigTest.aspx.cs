using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace eNorthwindCS.Main
{
  /// <summary>
  /// Summary description for ConfigTest.
  /// </summary>
  public class ConfigTest : System.Web.UI.Page
  {
    private void Page_Load(object sender, System.EventArgs e)
    {
      ConfigDisplay();
      ExceptionSample();
      AdditionalInfo();
    }

    private void ConfigDisplay()
    {
      Response.Write(ConfigurationSettings.AppSettings["SiteName"]);
      Response.Write(ConfigurationSettings.AppSettings["ConnectString"]);
      Response.Write(ConfigurationSettings.AppSettings["DefaultCategoryID"]);
    }

    private void ExceptionSample()
    {
      try
      {
        int i;
        int j;

        i = 0;
        j = 0;

        Response.Write(i / j);
      }
      catch (Exception ex)
      {
        Microsoft.ApplicationBlocks.
          ExceptionManagement.ExceptionManager.Publish(ex);
      }
    }

    private void AdditionalInfo()
    {
      try
      {
        int i;
        int j;

        i = 0;
        j = 0;

        Response.Write(i / j);
      }
      catch (Exception ex)
      {
        System.Collections.Specialized.NameValueCollection nvc = 
          new System.Collections.Specialized.NameValueCollection();

        nvc.Add("ClassName", "ConfigTest");
        nvc.Add("UserName", "JohnDoe");

        Microsoft.ApplicationBlocks.
          ExceptionManagement.ExceptionManager.Publish(ex, nvc);
      }
    }

    #region Web Form Designer generated code
    override protected void OnInit(EventArgs e)
    {
      //
      // CODEGEN: This call is required by the ASP.NET Web Form Designer.
      //
      InitializeComponent();
      base.OnInit(e);
    }
		
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {    
      this.Load += new System.EventHandler(this.Page_Load);

    }
    #endregion
  }
}
