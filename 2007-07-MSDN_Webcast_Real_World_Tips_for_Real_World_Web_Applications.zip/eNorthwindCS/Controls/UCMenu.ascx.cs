namespace eNorthwindCS.Controls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	using NorthwindDataLayerCS;
	using WebCommonCS;
	using CommonCS;

	/// <summary>
	///		Summary description for UCMenu.
	/// </summary>
	public class UCMenu : System.Web.UI.UserControl
	{
		private string mstrMenuName;

		public string MenuHeader
		{
			get { return lblHeader.Text; }
			set { lblHeader.Text = value; }
		}

		public string MenuName
		{
			get { return mstrMenuName; }
			set { mstrMenuName = value;}
		}

		public RepeatDirection RepeatDirection
		{
			get { return datMenu.RepeatDirection; }
			set { datMenu.RepeatDirection = value; }
		}

		protected System.Web.UI.WebControls.Label lblHeader;
		protected System.Web.UI.WebControls.DataList datMenu;

		private void Page_Load(object sender, System.EventArgs e)
		{
			LoadMenu();
		}
	
		// DEMO: 03.5-Use the MenuItemsDC class to retrieve menus by name
		private void LoadMenu()
		{
			IDataReader dr;
			WebMenusDC dc;

			try
			{
				dc = new WebMenusDC(WebAppConfig.ConnectString);

				dr = dc.GetMenusByMenuName(mstrMenuName);

				datMenu.DataSource = dr;
				datMenu.DataBind();

				dr.Close();
			}
			catch (Exception ex)
			{
				WebException.Publish(ex);

				throw ex;
			}
		}

    #region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.datMenu.ItemCommand += new System.Web.UI.WebControls.DataListCommandEventHandler(this.datMenu_ItemCommand);
			this.Load += new System.EventHandler(this.Page_Load);

		}
    #endregion

   
		private void datMenu_ItemCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
		{
			if (e.CommandArgument.ToString() != string.Empty)
				Response.Redirect(e.CommandArgument.ToString());
		}
	}
}
