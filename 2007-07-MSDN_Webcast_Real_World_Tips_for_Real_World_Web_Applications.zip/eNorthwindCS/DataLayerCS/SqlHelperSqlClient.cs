using System;
using System.Data;
using System.Data.SqlClient;

namespace DataLayerCS
{
    /// <summary>
    /// Summary description for SqlHelperSqlClient.
    /// </summary>
    public class SqlHelperSqlClient
    {
        public static DataSet GetDataSet(string SQL, string ConnectString)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(SQL, ConnectString);
            da.Fill(ds);
            return ds;
        }

        public static IDataReader GetDataReader(string SQL, string ConnectString)
        {
            SqlConnection cnn = new SqlConnection(ConnectString);
            try   
            {
                SqlCommand cmd = new SqlCommand(SQL, cnn);
                cnn.Open();
                return cmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception ex)       
            {
                // If there's an error, close the connection.
                if (cnn != null)
                    cnn.Close();
                throw ex;
            }
        }


        public static int ExecuteSQL(string SQL, string ConnectString)
        {
            using (SqlConnection cnn = new SqlConnection(ConnectString))
            {
                SqlCommand cmd = new SqlCommand(SQL, cnn);
                cnn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        public static object ExecuteScalar(string SQL, string ConnectString)
        {
            using (SqlConnection cnn = new SqlConnection(ConnectString))
            {
                SqlCommand cmd = new SqlCommand(SQL, cnn);
                cnn.Open();
                return cmd.ExecuteScalar();
            }
        }
    }
}
