using System;
using System.Data;
using System.Data.OleDb;

namespace DataLayerCS
{
	/// <summary>
	/// Summary description for DataClassBase.
	/// </summary>
  public class SqlHelper
  {
    public static DataSet GetDataSet(string SQL, string ConnectString)
    {
        DataSet ds = new DataSet();
        OleDbDataAdapter da = new OleDbDataAdapter(SQL, ConnectString);
        da.Fill(ds);
        return ds;
    }

	 // DEMO: 01.4-GetDataReader Method in SqlHelper Class
    public static IDataReader GetDataReader(string SQL, string ConnectString)
    {
        OleDbConnection cnn = new OleDbConnection(ConnectString);
        try   
        {
            OleDbCommand cmd = new OleDbCommand(SQL, cnn);
            cnn.Open();
            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }
        catch (Exception ex)       
        {
            // If there's an error, close the connection.
            if (cnn != null)
                cnn.Close();
            throw ex;
        }
    }

      public static int ExecuteSQL(string SQL, string ConnectString)
      {
          using (OleDbConnection cnn = new OleDbConnection(ConnectString))
          {
              OleDbCommand cmd = new OleDbCommand(SQL, cnn);
              cnn.Open();
              return cmd.ExecuteNonQuery();
          }
      }

      public static object ExecuteScalar(string SQL, string ConnectString)
      {
          using (OleDbConnection cnn = new OleDbConnection(ConnectString))
          {
              OleDbCommand cmd = new OleDbCommand(SQL, cnn);
              cnn.Open();
              return cmd.ExecuteScalar();
          }
      }
  }
}
