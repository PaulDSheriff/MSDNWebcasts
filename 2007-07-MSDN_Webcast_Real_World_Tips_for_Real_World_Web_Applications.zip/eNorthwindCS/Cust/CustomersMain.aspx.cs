using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using WebCommonCS;

namespace eNorthwindCS.Cust
{
	/// <summary>
	/// Summary description for CustomersMain.
	/// </summary>
	public class CustomersMain : WebPageBase
	{
		protected System.Web.UI.WebControls.Button btnGetOrders;
		protected System.Web.UI.WebControls.TextBox txtCustID;
		protected System.Web.UI.WebControls.Label Label1;

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnGetOrders.Click += new System.EventHandler(this.btnGetOrders_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnGetOrders_Click(object sender, System.EventArgs e)
		{
			// This is the standard technique
			//Session("LastCustomerID") = txtCustID.Text
			// DEMO: 07.1-Use SessionInfo class to set Session variables
			WebSessionInfo.LastCustomerID = txtCustID.Text;

			// Add a keyed pair to Context Object
			Context.Items.Add("CustID", txtCustID.Text);
			// Use Server.Transfer to call next page
			// You must use Server.Transfer and not Response.Redirect
			// if you use the Context object
			Server.Transfer("CustOrders.aspx");
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			// DEMO: 09.4-Show IsInRole method
			if (!User.IsInRole("Admin"))
				txtCustID.Enabled = false;

			// This is the standard technique
			// txtCustID.Text = Session("LastCustomerID").ToString()
			// DEMO: 07.2-Use SessionInfo class to get Session variables
			txtCustID.Text = WebSessionInfo.LastCustomerID;
			}
	}
}
