using System;
using System.Web;

namespace WebCommonCS
{
	/// <summary>
	/// Summary description for WebSessionInfo.
	/// </summary>
	public class WebSessionInfo
	{
		public WebSessionInfo()
		{
			LastCustomerID = string.Empty;
			LastPage = string.Empty;
		}

		// DEMO: 07.3-LastCustomerID Property
		public static string LastCustomerID
		{
			get { return HttpContext.Current.Session["LastCustomerID"].ToString(); }
			set { HttpContext.Current.Session["LastCustomerID"] = value; }
		}

		public static string LastPage
		{
			get { return HttpContext.Current.Session["LastPage"].ToString(); }
			set { HttpContext.Current.Session["LastPage"] = value; }
		}

	}
}
