using System;
using System.Web;
using System.Collections.Specialized;
using Microsoft.ApplicationBlocks.ExceptionManagement;

namespace WebCommonCS
{
  /// <summary>
  /// Summary description for WebException.
  /// </summary>
  public class WebException
  {
    public WebException()
    {
    }

    public static void Publish(Exception ex)
    {
      string strPageName;

      strPageName = HttpContext.Current.Request.ServerVariables["PATH_INFO"];

      strPageName = strPageName.Substring(strPageName.LastIndexOf("/")+1);
        
      Publish(ex, 
        strPageName,
        HttpContext.Current.Request.Url.Host +
        HttpContext.Current.Request.ApplicationPath, 
        GetUserName());
    }

    public static void Publish(Exception ex, string PageName)
    {
      Publish(ex, PageName, 
        HttpContext.Current.Request.Url.Host +
        HttpContext.Current.Request.ApplicationPath, 
        GetUserName());
    }

    public static void Publish(Exception ex, string PageName, 
      string SiteName, string UserName)
    {
      NameValueCollection nvc = new NameValueCollection();

      // Additional info for Exception Publisher
      nvc.Add("ClassName", PageName);
      nvc.Add("AppName", SiteName);
      nvc.Add("UserName", UserName);

      // DEMO: 06.2-WebException.Publish calls ExceptionManager.Publish()
      // Publish the error
      ExceptionManager.Publish(ex, nvc);
    }

    private static string GetUserName()
    {
      string sUserName;

      sUserName = HttpContext.Current.User.Identity.Name;
      if (sUserName == string.Empty)
        sUserName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

      return sUserName;
    }
  }
}
