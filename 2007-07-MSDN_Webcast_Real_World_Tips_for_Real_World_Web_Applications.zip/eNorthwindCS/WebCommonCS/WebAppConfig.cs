using System;
using System.Configuration;
using System.Collections.Specialized;
using Microsoft.ApplicationBlocks.ExceptionManagement;

namespace WebCommonCS
{
	/// <summary>
	/// Summary description for WebAppConfig.
	/// </summary>
	public class WebAppConfig : IConfigurationSectionHandler
	{
		private static string mConnectString;
		private static string mSiteName;
		private static int mDefaultCategoryID;

		public static string ConnectString
		{
			get { return mConnectString; }
			set { mConnectString = value; }
		}

		public static string SiteName
		{
			get { return mSiteName; }
			set { mSiteName = value; }
		}

		public static int DefaultCategoryID
		{
			get { return mDefaultCategoryID; }
			set { mDefaultCategoryID = value; }
		}

		static WebAppConfig()
		{
			try
			{
				// DEMO: 02.2-Call GetConfig() to Read in <AppConfig> Section
				// Calling GetConfig() calls the Create method in 
				// the class registered in Web.Config
				ConfigurationSettings.GetConfig("AppConfig");

			}
			catch (Exception ex)
			{
				ExceptionManager.Publish(ex);
			}
		}

		// DEMO: 02.3-The Create() method is called in response to GetConfig() method call
		// This method is called when the 
		// ConfigurationSettings.GetConfig method is called
		// and passed in the name of the section
		object IConfigurationSectionHandler.Create( 
			object parent, object configContext, 
			System.Xml.XmlNode input)
		{
			NameValueCollection nvc;
			NameValueSectionHandler handler;

			try
			{
				handler = new NameValueSectionHandler();

				nvc = (NameValueCollection) handler.Create(parent, configContext, input);

                // DEMO: 02.4-Retrieve values using NameValueCollection
                if (nvc != null)
                {
                    mConnectString = nvc["ConnectString"];
                    mSiteName = nvc["SiteName"];
                    mDefaultCategoryID = 
                        Convert.ToInt32(nvc["DefaultCategoryID"]);
                }
            }
			catch (Exception ex)
			{
				ExceptionManager.Publish(ex);

				throw ex;
			}

			return nvc;
		}
	}
}

