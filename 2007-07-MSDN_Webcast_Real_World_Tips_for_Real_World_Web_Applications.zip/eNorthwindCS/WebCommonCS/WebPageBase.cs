using System;
using System.Collections.Specialized;
using Microsoft.ApplicationBlocks.ExceptionManagement;
using NorthwindDataLayerCS;
using CommonCS;

namespace WebCommonCS
{
	/// <summary>
	/// Summary description for WebPageBase.
	/// </summary>
	// DEMO: 04.2-WebPageBase inherits from .NET Page Class
	public class WebPageBase : System.Web.UI.Page
	{
		public WebPageBase()
		{
		}

		private string mPageName;
		private string mUserName;
		private string mSiteName;
		private bool mTrackUser = true;

		protected bool TrackUser
		{
			get { return mTrackUser; }
			set { mTrackUser = value; }
		}

		protected string PageName
		{
			get { return mPageName; }
			set { mPageName = value; }
		}

		protected string UserName
		{
			get { return mUserName; }
			set { mUserName = value; }
		}

		protected string SiteName
		{
			get { return mSiteName; }
			set { mSiteName = value; }
		}

		private void SetDefaultPageName()
		{
			// Get the name of the current page.
			mPageName = Request.ServerVariables["PATH_INFO"];

			// Strip out Path
			mPageName = mPageName.Substring(
				mPageName.LastIndexOf("/") + 1);
		}

		private void SetDefaultUserName()
		{
			mUserName = Context.User.Identity.Name;
			if (mUserName == string.Empty)
				mUserName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
		}

		private void SetDefaultSiteName()
		{
			mSiteName = "http://" + Context.Request.Url.Host +
				Context.Request.ApplicationPath;
		}

		// DEMO: 08.2-OnError Overrides
		protected override void OnError(System.EventArgs e)
		{
			WebException.Publish(Server.GetLastError(), 
				mPageName, mSiteName, mUserName);

			// Call OnError event on child page
			base.OnError(e);
		}

		protected override void OnLoad(EventArgs e)
		{
			// Place any code here to run before the Page_Load
			SetDefaultPageName();
			SetDefaultUserName();
			SetDefaultSiteName();

			// Call OnLoad in child page to allow them
			// to override the page name or user name
			base.OnLoad (e);

			if (!Page.IsPostBack)
			{
				// Track User?
				if (mTrackUser)
				{
					HandleUserTracking();
				}
			}
		}

		// DEMO: 05.1-HandleUserTracking Method
		private void HandleUserTracking()
		{
			WebUserLogDC userLog;

			try
			{
				userLog = new WebUserLogDC(WebAppConfig.ConnectString);
				userLog.ClassName = mPageName;
				userLog.AppName = mSiteName;
				userLog.UserName = mUserName;
				userLog.Insert();
			}
			catch (Exception ex)
			{
				WebException.Publish(ex);
			}    
		}
	}
}
