using System;
using System.Data;

using CommonCS;
using DataLayerCS;

namespace NorthwindDataLayerCS
{
	/// <summary>
	/// Summary description for ProductsDC.
	/// </summary>
  public class ProductsDC
  {
    private string mConnectString;

    public ProductsDC(string ConnectString)
    {
      mConnectString = ConnectString;
    }

    public IDataReader GetProducts()
    {
      string sql;

      sql = "SELECT ProductID, ProductName, UnitPrice, UnitsInStock FROM Products";

      return SqlHelper.GetDataReader(sql, mConnectString);
    }

    public IDataReader GetProductsByCategory(int CategoryID)
    {
      string sql;

      sql = "SELECT ProductName, UnitPrice, UnitsInStock FROM Products ";
      sql += "WHERE CategoryID = {0} ";
      sql = string.Format(sql, CategoryID);

      return SqlHelper.GetDataReader(sql, mConnectString);
    }
  }
}
