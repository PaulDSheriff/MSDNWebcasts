using System;
using System.Data;

using CommonCS;
using DataLayerCS;

namespace NorthwindDataLayerCS
{
	/// <summary>
	/// Summary description for CategoriesDC.
	/// </summary>
	public class CategoriesDC
	{
		private string mConnectString;

		public CategoriesDC(string ConnectString) 
		{
			mConnectString = ConnectString;
		}

		// DEMO: 01.3-GetCategories Method creates SQL
		public IDataReader GetCategories()
		{
			string sql;

			sql = "SELECT * FROM Categories";

			return SqlHelper.GetDataReader(sql, mConnectString);
		}

		public IDataReader GetSalesByCategory()
		{
			string sql;

			sql = "SELECT * FROM [Sales By Category]";

			return SqlHelper.GetDataReader(sql, mConnectString);
		}
	}
}
