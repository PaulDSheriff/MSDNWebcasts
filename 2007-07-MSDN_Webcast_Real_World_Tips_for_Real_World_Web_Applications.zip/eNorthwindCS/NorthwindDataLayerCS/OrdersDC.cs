using System;
using System.Data;

using CommonCS;
using DataLayerCS;

namespace NorthwindDataLayerCS
{
	/// <summary>
	/// Summary description for OrdersDC.
	/// </summary>
	public class OrdersDC
	{
    private string mConnectString;

		public OrdersDC(string ConnectString)
		{
      mConnectString = ConnectString;
		}

    public IDataReader GetOrders()
    {
      string sql;

      sql = "SELECT * FROM Orders ORDER BY CustomerID";

      return SqlHelper.GetDataReader(sql, mConnectString);
    }
	}
}
