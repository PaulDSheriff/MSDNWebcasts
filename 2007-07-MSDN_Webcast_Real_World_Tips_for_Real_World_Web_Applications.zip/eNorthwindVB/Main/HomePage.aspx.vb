'*************************************************************
'* Copyright (C) 2003, PDSA, Inc.
'* www.pdsa.com
'* All rights reserved.
'*
'* The code contained herein is intended for teaching
'* concepts and as a supplement to PDSA, Inc.
'* books and teaching materials only.
'*
'* THIS CODE AND INFORMATION IS PROVIDED "AS IS"
'* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED 
'* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
'* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
'* FOR A PARTICULAR PURPOSE.
'*************************************************************
Public Class HomePage
  ' DEMO: 04.1-Inherit from your own base page class
  Inherits WebPageBase

  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents ddlCategories As System.Web.UI.WebControls.DropDownList
  Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
  Protected WithEvents grdProducts As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    If Not Page.IsPostBack Then
      ' DEMO: 01.1-Load Categories Call
      LoadCategories()
      LoadProducts(WebAppConfig.ConnectString)
    End If
  End Sub

  Private Sub LoadCategories()
    Dim dc As CategoriesDC
    Dim dr As IDataReader

    Try
      ' DEMO: 01.2-CategoriesDC Class
      ' DEMO: 02.1-Here is the call to WebAppConfig.ConnectString
      ' DEMO: 06.3-Comment out the following to show exception handling
      'dc = New CategoriesDC(WebAppConfig.ConnectString)

      dr = dc.GetCategories()

      ddlCategories.DataTextField = "CategoryName"
      ddlCategories.DataValueField = "CategoryID"
      ddlCategories.DataSource = dr
      ddlCategories.DataBind()

      dr.Close()

    Catch ex As Exception
      ' DEMO: 06.1-Call PublishException for all Exceptions
      WebException.Publish(ex)

      lblMessage.Text = ex.Message
    End Try
  End Sub

  Private Sub ddlCategories_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlCategories.SelectedIndexChanged
    LoadProducts(WebAppConfig.ConnectString)
  End Sub

  Private Sub LoadProducts(ByVal ConnectString As String)
    Dim dc As ProductsDC
    Dim dr As IDataReader

    ' DEMO: 08.1-Example routine with no Try...Catch
    ' NOTE: NO EXCEPTION HANDLING IN THIS ROUTINE!
    ' Any errors will be caught by OnError() in Base Page Class
    ' Comment the following line out to show exception 
    dc = New ProductsDC(ConnectString)
    'dc = New ProductsDC("")
    dr = dc.GetProductsByCategory( _
        Convert.ToInt32(ddlCategories.SelectedItem.Value))

    grdProducts.DataSource = dr
    grdProducts.DataBind()

    dr.Close()
  End Sub
End Class
