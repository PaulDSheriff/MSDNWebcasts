Public Class ConfigTest
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ConfigDisplay()
    ExceptionSample()
    AdditionalInfo()
  End Sub

  Private Sub ConfigDisplay()
    Response.Write(ConfigurationSettings.AppSettings("SiteName"))
    Response.Write(ConfigurationSettings.AppSettings("ConnectString"))
    Response.Write(ConfigurationSettings.AppSettings("DefaultCategoryID"))
  End Sub

  Private Sub ExceptionSample()
    Dim i As Integer
    Dim j As Integer

    Try
      i = 0
      j = 0

      Response.Write(i / j)
      Catch ex As Exception
         Microsoft.ApplicationBlocks. _
          ExceptionManagement.ExceptionManager.Publish(ex)
      End Try
  End Sub

  Private Sub AdditionalInfo()
    Dim i As Integer
    Dim j As Integer

    Try
      i = 0
      j = 0

      Response.Write(i / j)
      Catch ex As Exception
         Dim nvc As New System.Collections.Specialized.NameValueCollection()

         nvc.Add("ClassName", "ConfigTest")
         nvc.Add("UserName", "JohnDoe")

         Microsoft.ApplicationBlocks. _
          ExceptionManagement.ExceptionManager.Publish(ex, nvc)
      End Try
  End Sub

End Class
