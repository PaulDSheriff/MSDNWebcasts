'*************************************************************
'* Copyright (C) 2003, PDSA, Inc.
'* www.pdsa.com
'* All rights reserved.
'*
'* The code contained herein is intended for teaching
'* concepts and as a supplement to PDSA, Inc.
'* books and teaching materials only.
'*
'* THIS CODE AND INFORMATION IS PROVIDED "AS IS"
'* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED 
'* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
'* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
'* FOR A PARTICULAR PURPOSE.
'*************************************************************
Imports System.Security.Principal
Imports System.Web.Security

Public Class Login
  Inherits WebPageBase

  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents txtLogin As System.Web.UI.WebControls.TextBox
  Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
  Protected WithEvents Label3 As System.Web.UI.WebControls.Label
  Protected WithEvents btnLogin As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  ' DEMO: 09.3-Validate user credentials
  Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
    If LoginValid() Then
      FormsAuthentication.RedirectFromLoginPage( _
        txtLogin.Text, False)
    Else
      lblMessage.Text = "Invalid LoginID"
    End If
  End Sub

  Private Function LoginValid() As Boolean
    Dim dc As WebUsersRolesDC

    Try
      dc = New WebUsersRolesDC(WebAppConfig.ConnectString)
      Return dc.Exists(txtLogin.Text)

    Catch ex As Exception
      WebException.Publish(ex)

      lblMessage.Text = ex.Message
    End Try
  End Function
End Class
