Imports System.Data.OleDb

Public Class SqlHelper
  Public Shared Function GetDataSet(ByVal SQL As String, ByVal ConnectString As String) As DataSet
    Dim ds As New DataSet
    Dim da As OleDbDataAdapter
    da = New OleDbDataAdapter(SQL, ConnectString)
    da.Fill(ds)
    Return ds
  End Function

  ' DEMO: 01.4-GetDataReader Method in SqlHelper Class
  Public Shared Function GetDataReader(ByVal SQL As String, ByVal ConnectString As String) As IDataReader
    Dim cmd As OleDbCommand
    Dim cnn As OleDbConnection

    Try
      cnn = New OleDbConnection(ConnectString)
      cmd = New OleDbCommand(SQL, cnn)
      cnn.Open()
      Return cmd.ExecuteReader(CommandBehavior.CloseConnection)

    Catch
      ' If there's an error, close the connection.
      If Not cnn Is Nothing Then
        cnn.Close()
      End If
      Throw
    End Try
  End Function

  Public Shared Function ExecuteSQL(ByVal SQL As String, ByVal ConnectString As String) As Integer
    Dim cmd As OleDbCommand
    Dim cnn As OleDbConnection

    Try
      cnn = New OleDbConnection(ConnectString)
      cmd = New OleDbCommand(SQL, cnn)
      cnn.Open()
      Return cmd.ExecuteNonQuery()

    Finally
      If Not cnn Is Nothing Then
        cnn.Close()
      End If
    End Try
  End Function

  Public Shared Function ExecuteScalar(ByVal SQL As String, ByVal ConnectString As String) As Object
    Dim cmd As OleDbCommand
    Dim cnn As OleDbConnection

    Try
      cnn = New OleDbConnection(ConnectString)
      cmd = New OleDbCommand(SQL, cnn)
      cnn.Open()
      Return cmd.ExecuteScalar()

    Finally
      If Not cnn Is Nothing Then
        cnn.Close()
      End If
    End Try
  End Function
End Class