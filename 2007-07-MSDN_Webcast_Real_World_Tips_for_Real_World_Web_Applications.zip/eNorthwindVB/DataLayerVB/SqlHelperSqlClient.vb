Imports System.Data.SqlClient

Public Class SqlHelperSqlClient
  Public Shared Function GetDataSet(ByVal SQL As String, ByVal ConnectString As String) As DataSet
    Dim ds As New DataSet
    Dim da As SqlDataAdapter = New SqlDataAdapter(SQL, ConnectString)
    da.Fill(ds)
    Return ds
  End Function

  Public Shared Function GetDataReader(ByVal SQL As String, ByVal ConnectString As String) As IDataReader
    Dim cnn As SqlConnection
    Dim cmd As SqlCommand

    Try
      cnn = New SqlConnection(ConnectString)
      cmd = New SqlCommand(SQL, cnn)
      cnn.Open()
      Return cmd.ExecuteReader(CommandBehavior.CloseConnection)

    Catch
      ' If there's an error, close the connection.
      If Not cnn Is Nothing Then
        cnn.Close()
      End If
      Throw
    End Try
  End Function

  Public Shared Function ExecuteSQL(ByVal SQL As String, ByVal ConnectString As String) As Integer
    Dim cnn As SqlConnection
    Dim cmd As SqlCommand

    Try
      cnn = New SqlConnection(ConnectString)
      cmd = New SqlCommand(SQL, cnn)
      cnn.Open()
      Return cmd.ExecuteNonQuery()

    Finally
      If Not cnn Is Nothing Then
        cnn.Close()
      End If
    End Try
  End Function

  Public Shared Function ExecuteScalar(ByVal SQL As String, ByVal ConnectString As String) As Object
    Dim cnn As SqlConnection
    Dim cmd As SqlCommand

    Try
      cnn = New SqlConnection(ConnectString)
      cmd = New SqlCommand(SQL, cnn)
      cnn.Open()
      Return cmd.ExecuteScalar()

    Finally
      If Not cnn Is Nothing Then
        cnn.Close()
      End If
    End Try
  End Function
End Class