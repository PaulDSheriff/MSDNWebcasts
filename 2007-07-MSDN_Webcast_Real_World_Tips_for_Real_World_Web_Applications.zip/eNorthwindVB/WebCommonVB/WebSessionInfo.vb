Public Class WebSessionInfo
   ' DEMO: 07.3-LastCustomerID Property
   Public Shared Property LastCustomerID() As String
      Get
         Return HttpContext.Current.Session("LastCustomerID").ToString()
      End Get

      Set(ByVal Value As String)
         HttpContext.Current.Session("LastCustomerID") = Value
      End Set
   End Property

   Public Shared Property LastPage() As String
      Get
         Return HttpContext.Current.Session("LastPage").ToString()
      End Get

      Set(ByVal Value As String)
         HttpContext.Current.Session("LastPage") = Value
      End Set
   End Property

   Public Shared Property LastException() As Exception
      Get
         Return DirectCast(HttpContext.Current.Session("LastException"), Exception)
      End Get

      Set(ByVal Value As Exception)
         HttpContext.Current.Session("LastException") = Value
      End Set
   End Property

   Shared Sub New()
      WebSessionInfo.LastCustomerID = String.Empty
      WebSessionInfo.LastPage = String.Empty
      WebSessionInfo.LastException = Nothing
   End Sub
End Class
