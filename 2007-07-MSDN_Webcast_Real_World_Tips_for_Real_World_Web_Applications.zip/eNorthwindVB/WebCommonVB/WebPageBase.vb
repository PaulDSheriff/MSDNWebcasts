'*************************************************************
'* Copyright (C) 2003, PDSA, Inc.
'* www.pdsa.com
'* All rights reserved.
'*
'* The code contained herein is intended for teaching
'* concepts and as a supplement to PDSA, Inc.
'* books and teaching materials only.
'*
'* THIS CODE AND INFORMATION IS PROVIDED "AS IS"
'* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED 
'* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
'* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
'* FOR A PARTICULAR PURPOSE.
'*************************************************************
Imports Microsoft.ApplicationBlocks.ExceptionManagement
Imports System.Collections.Specialized

' DEMO: 04.2-WebPageBase inherits from .NET Page Class
Public Class WebPageBase
  Inherits System.Web.UI.Page

  Private mPageName As String
  Private mUserName As String
  Private mSiteName As String
  Private mTrackUser As Boolean = True

  Protected Property TrackUser() As Boolean
    Get
      Return mTrackUser
    End Get

    Set(ByVal Value As Boolean)
      mTrackUser = Value
    End Set
  End Property

  Protected Property UserName() As String
    Get
      Return mUserName
    End Get

    Set(ByVal Value As String)
      mUserName = Value
    End Set
  End Property

  Protected Property PageName() As String
    Get
      Return mPageName
    End Get

    Set(ByVal Value As String)
      mPageName = Value
    End Set
  End Property

  Protected Property SiteName() As String
    Get
      Return mSiteName
    End Get

    Set(ByVal Value As String)
      mSiteName = Value
    End Set
  End Property

#Region " Initialization Methods "
  Private Sub SetDefaultPageName()
    ' Get the name of the current page.
    mPageName = HttpContext.Current.Request. _
      ServerVariables("PATH_INFO")

    ' Strip out Path
    mPageName = mPageName.Substring( _
      mPageName.LastIndexOf("/") + 1)
  End Sub

  Private Sub SetDefaultUserName()
    mUserName = Context.User.Identity.Name
    If mUserName = String.Empty Then
      mUserName = System.Security.Principal. _
      WindowsIdentity.GetCurrent.Name
    End If
  End Sub

  Private Sub SetDefaultSiteName()
    mSiteName = "http://" & _
      Context.Request.Url.Host & _
      Context.Request.ApplicationPath
  End Sub
#End Region

  ' DEMO: 08.2-OnError Overrides
  Protected Overrides Sub OnError( _
  ByVal e As System.EventArgs)
    WebException.Publish(Server.GetLastError(), mPageName, _
      mSiteName, mUserName)

    ' Call OnError event on child page
    MyBase.OnError(e)
  End Sub

  Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
    ' Place any code here to run before the Page_Load
    SetDefaultPageName()
    SetDefaultUserName()
    SetDefaultSiteName()

    ' Call OnLoad in child page to allow them 
    ' to override the page name or user name
    MyBase.OnLoad(e)

    If Not Page.IsPostBack Then
      ' Track User?
      If mTrackUser Then
        HandleUserTracking()
      End If
    End If
  End Sub

  ' DEMO: 05.1-HandleUserTracking Method
  Private Sub HandleUserTracking()
    ' Track user info
    Dim userLog As WebUserLogDC

    Try
      userLog = New WebUserLogDC(WebAppConfig.ConnectString)
      userLog.ClassName = mPageName
      userLog.AppName = mSiteName
      userLog.UserName = mUserName
      userLog.Insert()

    Catch ex As Exception
      WebException.Publish(ex)

    End Try
  End Sub
End Class