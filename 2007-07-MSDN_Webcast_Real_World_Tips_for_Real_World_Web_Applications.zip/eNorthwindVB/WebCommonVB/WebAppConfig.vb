'*************************************************************
'* Copyright (C) 2003, PDSA, Inc.
'* www.pdsa.com
'* All rights reserved.
'*
'* The code contained herein is intended for teaching
'* concepts and as a supplement to PDSA, Inc.
'* books and teaching materials only.
'*
'* THIS CODE AND INFORMATION IS PROVIDED "AS IS"
'* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED 
'* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
'* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
'* FOR A PARTICULAR PURPOSE.
'*************************************************************
Imports System.Collections.Specialized
Imports Microsoft.ApplicationBlocks.ExceptionManagement

Public Class WebAppConfig
  Implements IConfigurationSectionHandler

  Private Shared mConnectString As String
  Private Shared mSiteName As String
  Private Shared mDefaultCategoryID As Integer

  Public Shared ReadOnly Property ConnectString() As String
    Get
      Return mConnectString
    End Get
  End Property

  Public Shared ReadOnly Property SiteName() As String
    Get
      Return mSiteName
    End Get
  End Property

  Public Shared ReadOnly Property DefaultCategoryID() As Integer
    Get
      Return mDefaultCategoryID
    End Get
  End Property

  Shared Sub New()
    Try
      ' DEMO: 02.2-Call GetConfig() to Read in <AppConfig> Section
      ' Calling GetConfig() calls the Create method
      System.Configuration. _
        ConfigurationSettings.GetConfig("AppConfig")

    Catch ex As Exception
      ExceptionManager.Publish(ex)
    End Try

  End Sub

  ' DEMO: 02.3-The Create() method is called in response to GetConfig() method call
  ' This method is called when the 
  ' ConfigurationSettings.GetConfig method is called
  ' and passed in the name of the section
  Public Function Create(ByVal parent As Object, _
    ByVal configContext As Object, _
    ByVal input As Xml.XmlNode) As Object _
    Implements IConfigurationSectionHandler.Create

    Dim nvc As NameValueCollection
    Dim handler As NameValueSectionHandler

    Try
      handler = New NameValueSectionHandler

      nvc = DirectCast(handler. _
       Create(parent, configContext, input), NameValueCollection)

      ' DEMO: 02.4-Retrieve values using NameValueCollection
      If Not nvc Is Nothing Then
        mConnectString = nvc("ConnectString")
        mSiteName = nvc("SiteName")
        mDefaultCategoryID = _
         Convert.ToInt32(nvc("DefaultCategoryID"))
      End If

    Catch ex As Exception
      ExceptionManager.Publish(ex)

      Throw ex
    End Try

    Return nvc
  End Function
End Class
