Imports System.Collections.Specialized
Imports Microsoft.ApplicationBlocks.ExceptionManagement

Public Class WebException
  Public Shared Sub Publish(ByVal ex As Exception)
    Dim strPageName As String

    strPageName = HttpContext.Current. _
      Request.ServerVariables("PATH_INFO")
    strPageName = strPageName.Substring(strPageName.LastIndexOf("/") + 1)

    Publish(ex, strPageName, _
      HttpContext.Current.Request.Url.Host & _
      HttpContext.Current.Request.ApplicationPath, _
      GetUserName())
  End Sub

  Public Shared Sub Publish(ByVal ex As Exception, _
  ByVal PageName As String)

    Publish(ex, PageName, _
      HttpContext.Current.Request.Url.Host & _
      HttpContext.Current.Request.ApplicationPath, _
      GetUserName())

  End Sub

  Public Shared Sub Publish(ByVal ex As Exception, _
  ByVal PageName As String, _
  ByVal SiteName As String, _
  ByVal UserName As String)
    Dim nvc As New NameValueCollection

    ' Additional info for Exception Publisher
    nvc.Add("ClassName", PageName)
    nvc.Add("AppName", SiteName)
    nvc.Add("UserName", UserName)

    ' DEMO: 06.2-WebException.Publish calls ExceptionManager.Publish()
    ' Publish the error
    ExceptionManager.Publish(ex, nvc)
  End Sub

  Private Shared Function GetUserName() As String
    Dim sUserName As String

    sUserName = HttpContext.Current.User.Identity.Name
    If sUserName = String.Empty Then
      sUserName = System.Security.Principal. _
      WindowsIdentity.GetCurrent.Name
    End If

    Return sUserName
  End Function
End Class
