'*************************************************************
'* Copyright (C) 2002, PDSA, Inc.
'* www.pdsa.com
'* All rights reserved.
'*
'* The code contained herein is intended for teaching
'* concepts and as a supplement to PDSA, Inc.
'* books and teaching materials only.
'*
'* THIS CODE AND INFORMATION IS PROVIDED "AS IS"
'* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED 
'* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
'* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
'* FOR A PARTICULAR PURPOSE.
'*************************************************************
Public Class PwdChange
  Inherits WebPageBase
  Protected WithEvents lblLogin As System.Web.UI.WebControls.Label
  Protected WithEvents txtLoginID As System.Web.UI.WebControls.TextBox
  Protected WithEvents lblPassword As System.Web.UI.WebControls.Label
  Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents txtConfirm As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label2 As System.Web.UI.WebControls.Label
  Protected WithEvents btnChange As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub btnChange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChange.Click
    Server.Transfer("~/Admin/AdminMain.aspx")
  End Sub
End Class
