USE Northwind
GO
DROP TABLE WebErrorLog
Go
DROP TABLE WebUserLog
Go
DROP TABLE WebMenus
Go
DROP TABLE WebUsersRoles
Go

CREATE TABLE WebErrorLog
(
iError_id int IDENTITY (1, 1) NOT NULL PRIMARY KEY,
sUserName varchar(50) NULL, 
sClassName varchar(50) NULL, 
dtErrorDate datetime NULL,
sAppName varchar(250) NULL,
sErrorText varchar(2500) NULL
)
GO

CREATE TABLE WebUserLog
(
iUserLog_id int IDENTITY (1, 1) NOT NULL PRIMARY KEY,
sUserName varchar(50) NULL,
sClassName varchar(50) NULL,
sAppName varchar(250) NULL,
dtEntryDate datetime NULL
)
GO

CREATE TABLE WebMenus
(
iMenu_id int NOT NULL PRIMARY KEY,
sMenuName char(16) NULL,
sMenuText varchar(50) NULL,
sAction varchar(255) NULL,
srtSeqNum smallint NULL,
sAppName varchar(250) NULL
)
GO

INSERT INTO WebMenus (iMenu_id,sMenuName,sMenuText,sAction,srtSeqNum,sAppName) VALUES(1,'MAIN','Home','~/Main/HomePage.aspx',10,'eNorthwind') 
INSERT INTO WebMenus (iMenu_id,sMenuName,sMenuText,sAction,srtSeqNum,sAppName) VALUES(2,'MAIN','Customers','~/Cust/CustomersMain.aspx',20,'eNorthwind') 
INSERT INTO WebMenus (iMenu_id,sMenuName,sMenuText,sAction,srtSeqNum,sAppName) VALUES(3,'MAIN','Admin','~/Admin/AdminMain.aspx',30,'eNorthwind') 
INSERT INTO WebMenus (iMenu_id,sMenuName,sMenuText,sAction,srtSeqNum,sAppName) VALUES(4,'CUSTMAIN','Home','~/Main/HomePage.aspx',10,'eNorthwind') 
INSERT INTO WebMenus (iMenu_id,sMenuName,sMenuText,sAction,srtSeqNum,sAppName) VALUES(6,'CUSTMAIN','Customer Orders','CustOrders.aspx',20,'eNorthwind') 
INSERT INTO WebMenus (iMenu_id,sMenuName,sMenuText,sAction,srtSeqNum,sAppName) VALUES(7,'ADMINMAIN','Home','~/Main/HomePage.aspx',10,'eNorthwind') 
INSERT INTO WebMenus (iMenu_id,sMenuName,sMenuText,sAction,srtSeqNum,sAppName) VALUES(8,'ADMINMAIN','Employee Maint','~/Admin/AdminEmployees.aspx',20,'eNorthwind') 
INSERT INTO WebMenus (iMenu_id,sMenuName,sMenuText,sAction,srtSeqNum,sAppName) VALUES(9,'ADMINMAIN','Change password','~/Admin/AdminPwdChange.aspx',30,'eNorthwind') 
GO

CREATE TABLE WebUsersRoles
(
	LoginID varchar(50) NOT NULL PRIMARY KEY,
	RoleName varchar(20) NULL
)
GO

INSERT INTO WebUsersRoles VALUES('Paul', 'Admin')
INSERT INTO WebUsersRoles VALUES('Ken', 'Supervisor')
INSERT INTO WebUsersRoles VALUES('Bruce', 'User')
GO