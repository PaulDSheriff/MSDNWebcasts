Public Class OrdersDC
  Private mConnectString As String

  Public Sub New(ByVal ConnectString As String)
    mConnectString = ConnectString
  End Sub

  Public Function GetOrders() As IDataReader
    Dim strSQL As String

    strSQL = "SELECT * FROM Orders ORDER BY CustomerID "

    Return SqlHelper.GetDataReader(strSQL, mConnectString)

  End Function
End Class
