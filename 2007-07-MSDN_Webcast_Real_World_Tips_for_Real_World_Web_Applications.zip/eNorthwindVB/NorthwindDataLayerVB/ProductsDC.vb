Public Class ProductsDC
  Private mConnectString As String

  Public Sub New(ByVal ConnectString As String)
    mConnectString = ConnectString
  End Sub

  Public Function GetProducts() As IDataReader
    Dim strSQL As String

    strSQL = "SELECT ProductName, UnitPrice, UnitsInStock " & _
    " FROM Products"

    Return SqlHelper.GetDataReader(strSQL, mConnectString)
  End Function

  Public Function GetProductsByCategory( _
   ByVal CategoryID As Integer) As IDataReader
    Dim strSQL As String

    strSQL = _
      "SELECT ProductName, UnitPrice, UnitsInStock  " & _
      "FROM Products " & _
      "WHERE CategoryID = {0} "
    strSQL = String.Format(strSQL, CategoryID)

    Return SqlHelper.GetDataReader(strSQL, mConnectString)
  End Function
End Class
