Public Class CategoriesDC
  Private mConnectString As String

  Public Sub New(ByVal ConnectString As String)
    mConnectString = ConnectString
  End Sub

  ' DEMO: 01.3-GetCategories Method creates SQL
  Public Function GetCategories() As IDataReader
    Dim strSQL As String

    strSQL = "SELECT * FROM Categories"
    Return SqlHelper.GetDataReader(strSQL, mConnectString)

  End Function

  Public Function GetSalesByCategory() As IDataReader
    Dim strSQL As String

    strSQL = "SELECT * FROM [Sales By Category]"
    Return SqlHelper.GetDataReader(strSQL, mConnectString)

  End Function
End Class
