'*************************************************************
'* Copyright (C) 2003, PDSA, Inc.
'* www.pdsa.com
'* All rights reserved.
'*
'* The code contained herein is intended for teaching
'* concepts and as a supplement to PDSA, Inc.
'* books and teaching materials only.
'*
'* THIS CODE AND INFORMATION IS PROVIDED "AS IS"
'* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED 
'* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
'* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
'* FOR A PARTICULAR PURPOSE.
'*************************************************************
Public Class CustOrders
  Inherits WebPageBase

  Protected WithEvents grdCustOrders As System.Web.UI.WebControls.DataGrid
  Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    If Not Page.IsPostBack Then
      GridLoad()
    End If
  End Sub

  Private Sub GridLoad()
    Dim dc As OrdersDC
    Dim dr As IDataReader
    Dim custID As String

    Try
      dc = New OrdersDC(WebAppConfig.ConnectString)

      ' Get Orders By Customer
      dr = dc.GetOrders()

      grdCustOrders.DataSource = dr
      grdCustOrders.DataBind()

      dr.Close()

    Catch ex As Exception
      WebException.Publish(ex)

      lblMessage.Text = ex.Message
    End Try
  End Sub
End Class
