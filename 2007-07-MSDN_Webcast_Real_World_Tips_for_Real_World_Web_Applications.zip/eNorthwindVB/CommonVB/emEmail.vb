Imports Microsoft.ApplicationBlocks.ExceptionManagement
Imports System.Collections.Specialized
Imports System.Web.Mail

Public Class EMeMail
  Implements IExceptionPublisher

  Public Sub Publish(ByVal exception As Exception, _
    ByVal additionalInfo As NameValueCollection, _
    ByVal configSettings As NameValueCollection) _
    Implements IExceptionPublisher.Publish

    Dim strFromEmail As String
    Dim strToEmail As String
    Dim strSubject As String
    Dim strClassName As String
    Dim strAppName As String
    Dim strUserName As String
    Dim strSMTP As String

    If Not (additionalInfo Is Nothing) Then
      ' Retrieve Additional Info
      strClassName = additionalInfo("ClassName")
      strAppName = additionalInfo("AppName")
      strUserName = additionalInfo("UserName")
    End If

    If Not (configSettings Is Nothing) Then
      ' Retrieve Attributes from Config File
      strFromEmail = configSettings("FromEMail")
      strToEmail = configSettings("ToEMail")
      strSubject = configSettings("Subject")
      strSMTP = configSettings("SMTPServer")
    End If

    strSubject &= " - " & strClassName & _
    " - " & strAppName

    ' Send Exception via Email
    SmtpMail.SmtpServer = strSMTP
    SmtpMail.Send(strFromEmail, strToEmail, _
        strSubject, exception.ToString())
  End Sub
End Class