Public Class WebErrorLogDC
  Private mConnectString As String
  Private mUserName As String
  Private mClassName As String
  Private mAppName As String
  Private mEx As Exception

  Public Sub New(ByVal ConnectString As String)
    mConnectString = ConnectString
  End Sub

  Property ExceptionObject() As Exception
    Get
      Return mEx
    End Get

    Set(ByVal Value As Exception)
      mEx = Value
    End Set
  End Property

  Property UserName() As String
    Get
      Return mUserName
    End Get
    Set(ByVal Value As String)
      mUserName = Value
    End Set
  End Property

  Property ClassName() As String
    Get
      Return mClassName
    End Get
    Set(ByVal Value As String)
      mClassName = Value
    End Set
  End Property

  Property AppName() As String
    Get
      Return mAppName
    End Get
    Set(ByVal Value As String)
      mAppName = Value
    End Set
  End Property

  Public Sub Insert()
    Dim strSQL As String

    strSQL = "INSERT INTO WebErrorLog "
    strSQL &= " (sUserName, sClassName, dtErrorDate, "
    strSQL &= " sAppName, sErrorText) "
    strSQL &= " VALUES('{0}', '{1}', '{2}', '{3}', '{4}')"

    strSQL = String.Format(strSQL, _
        mUserName, mClassName, _
        DateTime.Now.ToString(), _
        mAppName, mEx.ToString.Replace("'", "''"))

    SqlHelper.ExecuteSQL(strSQL, mConnectString)

  End Sub
End Class
