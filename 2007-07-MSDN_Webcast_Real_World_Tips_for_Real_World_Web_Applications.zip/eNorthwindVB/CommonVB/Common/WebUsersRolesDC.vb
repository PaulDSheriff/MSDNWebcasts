Public Class WebUsersRolesDC
  Private mConnectString As String

  Public Sub New(ByVal ConnectString As String)
    mConnectString = ConnectString
  End Sub

  Public Function GetAllUsers() As IDataReader
    Dim strSQL As String

    Try
      strSQL = "SELECT * FROM WebUsersRoles"

      Return SqlHelper.GetDataReader(strSQL, mConnectString)

    Catch ex As Exception
      Throw ex

    End Try
  End Function

  Public Function GetRoleByLoginID(ByVal LoginID As String) As String
    Dim strSQL As String

    Try
      strSQL = "SELECT RoleName FROM WebUsersRoles WHERE LoginID = '{0}' "
      strSQL = String.Format(strSQL, LoginID)

      Return SqlHelper.ExecuteScalar(strSQL, mConnectString)

    Catch ex As Exception
      Throw ex

    End Try
  End Function

  Public Function Exists(ByVal LoginID As String) As Boolean
    Dim strSQL As String

    Try
      strSQL = "SELECT Count(*) FROM WebUsersRoles WHERE LoginID = '{0}' "
      strSQL = String.Format(strSQL, LoginID)

      Return (Convert.ToInt32(SqlHelper.ExecuteScalar(strSQL, mConnectString)) > 0)

    Catch ex As Exception
      Throw ex

    End Try
  End Function
End Class
