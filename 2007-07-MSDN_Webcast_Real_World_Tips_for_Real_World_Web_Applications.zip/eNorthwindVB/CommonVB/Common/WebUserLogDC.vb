Public Class WebUserLogDC
  Private mConnectString As String
  Private mUserName As String
  Private mClassName As String
  Private mAppName As String

  Public Sub New(ByVal ConnectString As String)
    mConnectString = ConnectString
  End Sub

  Property UserName() As String
    Get
      Return mUserName
    End Get

    Set(ByVal Value As String)
      mUserName = Value
    End Set
  End Property

  Property ClassName() As String
    Get
      Return mClassName
    End Get

    Set(ByVal Value As String)
      mClassName = Value
    End Set
  End Property

  Property AppName() As String
    Get
      Return mAppName
    End Get

    Set(ByVal Value As String)
      mAppName = Value
    End Set
  End Property

  ' DEMO: 05.2-The Insert method will track user statistics
  Public Sub Insert()
    Dim strSQL As String

    Try
      strSQL = "INSERT INTO WebUserLog("
      strSQL &= "sUserName, sClassName, sAppName, "
      strSQL &= " dtEntryDate) "
      strSQL &= "VALUES('{0}', '{1}', '{2}', '{3}')"

      strSQL = String.Format(strSQL, _
        mUserName, mClassName, mAppName, _
        DateTime.Now().ToString())

      SqlHelper.ExecuteSQL(strSQL, mConnectString)

    Catch ex As Exception
      Throw ex

    End Try
  End Sub
End Class
