Public Class WebMenusDC
  Private mConnectString As String

  Public Sub New(ByVal ConnectString As String)
    mConnectString = ConnectString
  End Sub

  Public Function GetMenusByMenuName(ByVal MenuName As String) As IDataReader
    Dim strSQL As String

    strSQL = "SELECT RTrim(sMenuText) As sMenuText, "
    strSQL &= " RTrim(sAction) As sAction"
    strSQL &= " FROM WebMenus "
    strSQL &= " WHERE sMenuName = '{0}' "
    strSQL &= " ORDER BY srtSeqNum"
    strSQL = String.Format(strSQL, MenuName)

    Return SqlHelper.GetDataReader(strSQL, mConnectString)

  End Function
End Class
