'*************************************************************
'* Copyright (C) 2003, PDSA, Inc.
'* www.pdsa.com
'* All rights reserved.
'*
'* The code contained herein is intended for teaching
'* concepts and as a supplement to PDSA, Inc.
'* books and teaching materials only.
'*
'* THIS CODE AND INFORMATION IS PROVIDED "AS IS"
'* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED 
'* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
'* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
'* FOR A PARTICULAR PURPOSE.
'*************************************************************
Imports Microsoft.ApplicationBlocks.ExceptionManagement
Imports System.Collections.Specialized

Public Class emSql
  Implements IExceptionPublisher

  Public Sub Publish(ByVal appEx As Exception, _
      ByVal additionalInfo As NameValueCollection, _
      ByVal configSettings As NameValueCollection) _
      Implements IExceptionPublisher.Publish

    Dim strConnect As String
    Dim strClassName As String
    Dim strAppName As String
    Dim strUserName As String
    Dim dc As WebErrorLogDC

    If Not (configSettings Is Nothing) Then
      ' Retrieve attributes from <Publisher> element
      strConnect = configSettings("SQLConnect")
    End If

    If Not (additionalInfo Is Nothing) Then
      ' Retrieve additional info
      strClassName = additionalInfo("ClassName")
      strAppName = additionalInfo("AppName")
      strUserName = additionalInfo("UserName")
    End If

    ' Log error from Exception Manager
    ' into Application Event Log
    dc = New WebErrorLogDC(strConnect)
    dc.ClassName = strClassName
    dc.AppName = strAppName
    dc.UserName = strUserName
    dc.ExceptionObject = appEx
    dc.Insert()
  End Sub
End Class