'*************************************************************
'* Copyright (C) 2003, PDSA, Inc.
'* www.pdsa.com
'* All rights reserved.
'*
'* The code contained herein is intended for teaching
'* concepts and as a supplement to PDSA, Inc.
'* books and teaching materials only.
'*
'* THIS CODE AND INFORMATION IS PROVIDED "AS IS"
'* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED 
'* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
'* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
'* FOR A PARTICULAR PURPOSE.
'*************************************************************
Imports System.Web
Imports System.Security.Principal

Public Class Global
  Inherits System.Web.HttpApplication

#Region " Component Designer Generated Code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Component Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Required by the Component Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Component Designer
  'It can be modified using the Component Designer.
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    components = New System.ComponentModel.Container
  End Sub

#End Region

  Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
    Dim astrRoles() As String
    Dim gi As GenericIdentity

    If Request.IsAuthenticated Then
      astrRoles = BuildRole()

      gi = New GenericIdentity(User.Identity.Name)
      Context.User = New GenericPrincipal(gi, astrRoles)
    End If
  End Sub

  Private Function BuildRole() As String()
    Dim strRole As String
    Dim dc As WebUsersRolesDC
    Dim astrRoles() As String

    dc = New WebUsersRolesDC(WebAppConfig.ConnectString)
    strRole = dc.GetRoleByLoginID(User.Identity.Name)
    astrRoles = New String() {strRole}

    Return astrRoles
  End Function

  Sub Session_Start()
    WebSessionInfo.LastCustomerID = "ALFKI"
    WebSessionInfo.LastPage = "Default"
  End Sub
End Class
