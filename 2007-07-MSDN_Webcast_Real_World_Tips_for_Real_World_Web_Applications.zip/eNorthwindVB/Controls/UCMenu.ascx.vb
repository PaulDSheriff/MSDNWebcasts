'*************************************************************
'* Copyright (C) 2003, PDSA, Inc.
'* www.pdsa.com
'* All rights reserved.
'*
'* The code contained herein is intended for teaching
'* concepts and as a supplement to PDSA, Inc.
'* books and teaching materials only.
'*
'* THIS CODE AND INFORMATION IS PROVIDED "AS IS"
'* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED 
'* OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
'* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
'* FOR A PARTICULAR PURPOSE.
'*************************************************************
Public MustInherit Class UCMenu
   Inherits System.Web.UI.UserControl

   Protected WithEvents datMenu As System.Web.UI.WebControls.DataList
   Protected WithEvents lblHeader As System.Web.UI.WebControls.Label

   Private mstrMenuName As String

   Property MenuHeader() As String
      Get
         Return lblHeader.Text
      End Get
      Set(ByVal Value As String)
         lblHeader.Text = Value
      End Set
   End Property

   Property RepeatDirection() As RepeatDirection
      Get
         Return datMenu.RepeatDirection
      End Get
      Set(ByVal Value As RepeatDirection)
         datMenu.RepeatDirection = Value
      End Set
   End Property

   Property MenuName() As String
      Get
         Return mstrMenuName
      End Get
      Set(ByVal Value As String)
         mstrMenuName = Value
      End Set
   End Property

#Region " Web Form Designer Generated Code "

   'This call is required by the Web Form Designer.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

   End Sub

   Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
      'CODEGEN: This method call is required by the Web Form Designer
      'Do not modify it using the code editor.
      InitializeComponent()
   End Sub

#End Region

   Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      If Not Page.IsPostBack Then
         LoadMenu()
      End If
   End Sub

   ' DEMO: 03.5-Use the MenuItemsDC class to retrieve menus by name
   Private Sub LoadMenu()
      Dim dc As WebMenusDC
      Dim dr As IDataReader

      Try
         dc = New WebMenusDC( _
            WebAppConfig.ConnectString)
         dr = dc.GetMenusByMenuName(mstrMenuName)

         datMenu.DataSource = dr
         datMenu.DataBind()

         dr.Close()

      Catch ex As Exception
         WebException.Publish(ex)

         Throw ex
      End Try
   End Sub

   Private Sub datMenu_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataListCommandEventArgs) Handles datMenu.ItemCommand
      If e.CommandArgument.ToString <> String.Empty Then
         Response.Redirect(e.CommandArgument.ToString)
      End If
   End Sub
End Class
