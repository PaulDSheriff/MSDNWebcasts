Public Class BasePage
  Inherits System.Web.UI.Page

  Property ConnectSTring() As String
    Get

    End Get
    Set(ByVal Value As String)

    End Set
  End Property

  Public Sub New()
    MyBase.New()
  End Sub

  Protected Overrides Sub onLoad(ByVal e As EventArgs)
    ' Do things before

    MyBase.OnLoad(e)

    ' Do Things After

    ' Track User Information

  End Sub

  Protected Overrides Sub OnError(ByVal e As EventArgs)
    DataAccess.ErrorLog.WriteError(Server.GetLastError(), _
     Application("ConnectString").ToString)

    MyBase.OnError(e)
  End Sub
End Class
