Imports System.Data.SqlClient

Public Class DAL
  Public Shared Function GetDataReader( _
  ByVal SQLStatement As String, _
  ByVal ConnectionString As String) As SqlDataReader

    Dim dr As SqlDataReader
    Dim cmd As New SqlCommand()

    With cmd
      .Connection = _
          New SqlConnection(ConnectionString)
      .Connection.Open()

      .CommandText = SQLStatement
      dr = .ExecuteReader(CommandBehavior.CloseConnection)
    End With

    Return dr
  End Function

  Public Shared Sub GetDataSet( _
    ByVal SQLString As String, _
    ByVal ConnectionString As String, _
    ByRef ds As DataSet)

    Dim da As SqlDataAdapter

    Try
      ' Create new DataAdapter
      da = New SqlDataAdapter( _
          SQLString, ConnectionString)

      ' Fill DataSet from DataAdapter
      da.Fill(ds)

    Catch
      Throw

    End Try
  End Sub

  Public Shared Function ExecuteSQL( _
    ByVal SQLStatement As String, _
    ByVal ConnectionString As String) As Integer

    Dim cmd As SqlCommand
    Dim intRows As Integer

    Try
      cmd = New SqlCommand()
      With cmd
        ' Create a Connection object
        .Connection = _
        New SqlConnection(ConnectionString)

        ' Fill in command text, set type
        .CommandText = SQLStatement
        .CommandType = CommandType.Text

        ' Open the Connection
        .Connection.Open()

        ' Execute SQL
        intRows = .ExecuteNonQuery()
      End With

    Catch
      Throw

    Finally
      ' Close the Connection
      With cmd.Connection
        If .State = ConnectionState.Open Then
          .Close()
        End If
      End With
    End Try

    Return intRows
  End Function

  Public Shared Function ExecuteScalar( _
  ByVal SQL As String, _
  ByVal ConnectionString As String) As Object

    Dim dr As SqlDataReader
    Dim cmd As New SqlCommand()
    Dim Value As Object

    Try
      With cmd
        .Connection = _
          New SqlConnection(ConnectionString)
        .Connection.Open()

        .CommandText = SQL
        Value = .ExecuteScalar()
        .Connection.Close()
      End With

    Catch
      Throw

    End Try

    Return Value
  End Function

  Public Shared Function QuoteString( _
  ByVal Value As String) As String

    Return String.Format("'{0}'", Value.Replace("'", "''"))
  End Function

End Class

