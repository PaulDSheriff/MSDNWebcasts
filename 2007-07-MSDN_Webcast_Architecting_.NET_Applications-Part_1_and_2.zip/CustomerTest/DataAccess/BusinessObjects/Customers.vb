Imports DataLayer

Public Class Customers
  Public Function GetAllCustomers(ByVal ConnectString As String) As CustomersData
    Dim strSQL As String
    Dim cust As New CustomersData()

    strSQL = "SELECT CustomerID, CompanyName FROM Customers"

    DAL.GetDataSet(strSQL, ConnectString, CType(cust, DataSet))

    Return cust
  End Function

  Public Function GetCustomerByID(ByVal CustID As String, _
    ByVal ConnectString As String) As CustomersData
    Dim strSQL As String
    Dim cust As New CustomersData()

    strSQL = "SELECT * FROM Customers "
    strSQL &= " WHERE CustomerID = '{0}'"

    strSQL = String.Format(strSQL, CustID)

    DAL.GetDataSet(strSQL, ConnectString, CType(cust, DataSet))

    Return cust
  End Function

  Public Sub Insert(ByVal CustID As String, _
  ByVal CompanyName As String, _
  ByVal ContactName As String, _
  ByVal ContactTitle As String, _
  ByVal ConnectString As String)
    Dim strSQL As String

    strSQL = "INSERT INTO Customers("
    strSQL &= "CustomerID, CompanyName, "
    strSQL &= "ContactName, ContactTitle "
    strSQL &= " ) "
    strSQL &= " VALUES ("
    strSQL &= "'{0}', '{1}', '{2}', '{3}'"
    strSQL &= " ) "

    Try
      ' Validate Business Rules
      Validate(CustID, CompanyName, ContactName, ContactTitle)

      strSQL = String.Format(strSQL, CustID, _
        DAL.QuoteString(CompanyName), _
        DAL.QuoteString(ContactName), _
        DAL.QuoteString(ContactTitle))

      DAL.ExecuteSQL(strSQL, ConnectString)

    Catch
      Throw

    End Try
  End Sub

  Public Sub Update(ByVal CustID As String, _
  ByVal CompanyName As String, _
  ByVal ContactName As String, _
  ByVal ContactTitle As String, _
  ByVal ConnectString As String)
    Dim strSQL As String

    strSQL = "UPDATE Customers SET "
    strSQL &= "CompanyName = {0},  "
    strSQL &= "ContactName = {1}, "
    strSQL &= "ContactTitle = {2} "
    strSQL &= " WHERE CustomerID = {3} "

    Try
      ' Validate Business Rules
      Validate(CustID, CompanyName, ContactName, ContactTitle)

      strSQL = String.Format(strSQL, _
        DAL.QuoteString(CompanyName), _
        DAL.QuoteString(ContactName), _
        DAL.QuoteString(ContactTitle), _
        DAL.QuoteString(CustID))

      DAL.ExecuteSQL(strSQL, ConnectString)

    Catch
      Throw

    End Try
  End Sub

  Public Sub Validate(ByVal CustID As String, _
  ByVal CompanyName As String, _
  ByVal ContactName As String, _
  ByVal ContactTitle As String)
    Dim strMsg As String

    If Len(Trim(CustID)) = 0 Then
      strMsg &= "Customer ID must be filled in"
    End If

    If Len(Trim(CompanyName)) = 0 Then
      strMsg &= "Company Name must be filled in"
    End If

    If Len(strMsg) > 0 Then
      Throw New Exception(strMsg)
    End If
  End Sub
End Class

