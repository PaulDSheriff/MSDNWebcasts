Imports DataLayer

Public Class Employees
  Public Function EmployeeValid(ByVal LastName As String, _
   ByVal Extension As String, _
   ByVal ConnectString As String) As Boolean
    Dim boolFound As Boolean
    Dim strSQL As String

    strSQL = "SELECT Count(*) FROM Employees " & _
    "WHERE LastName = " & _
    DAL.QuoteString(LastName) & _
    " AND Extension = " & _
    DAL.QuoteString(Extension)

      Try
        'Execute query and return count of valid records
      boolFound = (CInt(DAL. _
       ExecuteScalar(strSQL, ConnectString)) > 0)

      Return boolFound

      Catch exp As Exception
        Throw exp

      End Try
  End Function

End Class

