Imports System.Runtime.Serialization

'**********************************************
'* DataSet Class 
'**********************************************
<System.ComponentModel.DesignerCategory("Code"), _
 SerializableAttribute()> _
Public Class CustomersData
  Inherits DataSet

  '*************************************
  ' Sub New:
  '   Constructor to support serialization.
  '*************************************
  Public Sub New(ByVal info As SerializationInfo, _
   ByVal context As StreamingContext)
    MyBase.New(info, context)
  End Sub

  '*************************************
  ' Sub New:
  '*************************************
  Public Sub New()
    MyBase.New()
  End Sub

  ReadOnly Property ObjectName() As String
    Get
      Return "Customers"
    End Get
  End Property

  '******************************************************
  '* Properties to Return Column Names
  '******************************************************
  ReadOnly Property CustomerID() As String
    Get
      Return "CustomerID"
    End Get
  End Property

  ReadOnly Property CompanyName() As String
    Get
      Return "CompanyName"
    End Get
  End Property

  ReadOnly Property ContactName() As String
    Get
      Return "ContactName"
    End Get
  End Property

  ReadOnly Property ContactTitle() As String
    Get
      Return "ContactTitle"
    End Get
  End Property

  ReadOnly Property Address() As String
    Get
      Return "Address"
    End Get
  End Property

  ReadOnly Property City() As String
    Get
      Return "City"
    End Get
  End Property

  ReadOnly Property Region() As String
    Get
      Return "Region"
    End Get
  End Property

  ReadOnly Property PostalCode() As String
    Get
      Return "PostalCode"
    End Get
  End Property

  ReadOnly Property Country() As String
    Get
      Return "Country"
    End Get
  End Property

  ReadOnly Property Phone() As String
    Get
      Return "Phone"
    End Get
  End Property

  ReadOnly Property Fax() As String
    Get
      Return "Fax"
    End Get
  End Property
End Class

