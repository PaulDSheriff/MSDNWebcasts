Imports System.Runtime.Serialization

'**********************************************
'* DataSet Class 
'**********************************************
<System.ComponentModel.DesignerCategory("Code"), _
SerializableAttribute()> _
Public Class EmployeesData
  Inherits DataSet

  '*************************************
  ' Sub New:
  '   Constructor to support serialization.
  '*************************************
  Public Sub New(ByVal info As SerializationInfo, _
    ByVal context As StreamingContext)
    MyBase.New(info, context)
  End Sub

  '*************************************
  ' Sub New:
  '*************************************
  Public Sub New()
    MyBase.New()
  End Sub

  ReadOnly Property ObjectName() As String
    Get
      Return "Employees"
    End Get
  End Property

  '******************************************************
  '* Properties to Return Column Names
  '******************************************************
  ReadOnly Property LastName() As String
    Get
      Return "LastName"
    End Get
  End Property

  ReadOnly Property FirstName() As String
    Get
      Return "FirstName"
    End Get
  End Property

  ReadOnly Property Extension() As String
    Get
      Return "Extension"
    End Get
  End Property
End Class

