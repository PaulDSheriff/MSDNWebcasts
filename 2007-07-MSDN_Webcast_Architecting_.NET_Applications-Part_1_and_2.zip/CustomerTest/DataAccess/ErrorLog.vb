Imports DataLayer

Public Class ErrorLog
  Public Shared Sub WriteError(ByVal exp As Exception, ByVal ConnectString As String)
    Dim strSQL As String

    strSQL = "INSERT INTO WebErrorLog("
    strSQL &= "dtError_dt, szError_tx)"
    strSQL &= " VALUES( "
    strSQL &= " {0}, {1} )"

    strSQL = String.Format(strSQL, _
     DAL.QuoteString(Now.ToString()), _
     DAL.QuoteString(exp.Message))

    DAL.ExecuteSQL(strSQL, ConnectString)
  End Sub
End Class
