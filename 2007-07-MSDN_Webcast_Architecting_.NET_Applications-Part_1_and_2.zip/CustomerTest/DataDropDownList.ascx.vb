Imports DataLayer

Public MustInherit Class DataDropDownList
  Inherits System.Web.UI.UserControl
  Protected WithEvents ddlList As System.Web.UI.WebControls.DropDownList

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private mstrDataTable As String

  Public Property DataTable() As String
    Get
      Return mstrDataTable
    End Get
    Set(ByVal Value As String)
      mstrDataTable = Value
    End Set
  End Property

  Public Property DataTextField() As String
    Get
      Return ddlList.DataTextField
    End Get
    Set(ByVal Value As String)
      ddlList.DataTextField = Value
    End Set
  End Property

  Public Property DataValueField() As String
    Get
      Return ddlList.DataValueField
    End Get
    Set(ByVal Value As String)
      ddlList.DataValueField = Value
    End Set
  End Property

  Public Overrides Sub DataBind()
    Dim strSQL As String
    Dim strConn As String
    Dim ds As New DataSet()

    strSQL = String.Format("SELECT {0}, {1} FROM {2}", _
     DataTextField, DataValueField, DataTable)
    strConn = WebAppConfig.ConnectString

    With ddlList
      DAL.GetDataSet(strSQL, strConn, ds)

      .DataSource = ds
      .DataBind()
    End With
  End Sub

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

  End Sub
End Class
