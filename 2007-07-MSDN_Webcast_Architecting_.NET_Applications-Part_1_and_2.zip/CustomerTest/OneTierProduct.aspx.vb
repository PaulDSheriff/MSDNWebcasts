Public Class WebForm2
    Inherits System.Web.UI.Page
  Protected WithEvents grdProducts As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    GridLoad()
  End Sub

  Private Sub GridLoad()
    Dim ds As DataSet
    Dim da As SqlClient.SqlDataAdapter

    ds = New DataSet()
    da = New SqlClient.SqlDataAdapter( _
     "SELECT * FROM Products", _
     "Server=(local);Database=Northwind;uid=sa;pwd=sa")

    da.Fill(ds)

    grdProducts.DataSource = ds
    grdProducts.DataBind()
  End Sub

End Class
