Public Class nTierCustomerDetail
  Inherits System.Web.UI.Page
  Protected WithEvents Label2 As System.Web.UI.WebControls.Label
  Protected WithEvents Label3 As System.Web.UI.WebControls.Label
  Protected WithEvents Label4 As System.Web.UI.WebControls.Label
  Protected WithEvents Label5 As System.Web.UI.WebControls.Label
  Protected WithEvents btnSave As System.Web.UI.WebControls.Button
  Protected WithEvents txtCustID As System.Web.UI.WebControls.TextBox
  Protected WithEvents txtCompanyName As System.Web.UI.WebControls.TextBox
  Protected WithEvents txtContactName As System.Web.UI.WebControls.TextBox
  Protected WithEvents txtContactTitle As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label6 As System.Web.UI.WebControls.Label
  Protected WithEvents RequiredFieldValidator1 As System.Web.UI.WebControls.RequiredFieldValidator
  Protected WithEvents Label7 As System.Web.UI.WebControls.Label
  Protected WithEvents txtPhone As System.Web.UI.WebControls.TextBox
  Protected WithEvents RegularExpressionValidator1 As System.Web.UI.WebControls.RegularExpressionValidator
  Protected WithEvents ValidationSummary1 As System.Web.UI.WebControls.ValidationSummary
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Protected WithEvents dddlRegions As DataDropDownList

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    If Not Page.IsPostBack Then
      UCRegionLoad()
      FormShow()
    End If
  End Sub

  Private Sub UCRegionLoad()
    With dddlRegions
      .DataTable = "Region"
      .DataTextField = "RegionDescription"
      .DataValueField = "RegionID"

      .DataBind()
    End With
  End Sub

  Private Sub FormShow()
    Dim cust As New DataAccess.Customers()
    Dim cr As DataAccess.CustomersData

    cr = cust.GetCustomerByID(Request.QueryString("ID").ToString, Application("ConnectString").ToString)

    With cr.Tables(0).Rows(0)
      txtCustID.Text = .Item(cr.CustomerID).ToString
      txtCompanyName.Text = .Item(cr.CompanyName).ToString
      txtContactName.Text = .Item(cr.ContactName).ToString
      txtContactTitle.Text = .Item(cr.ContactTitle).ToString
    End With

  End Sub

  Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
    Dim cust As New DataAccess.Customers()

    Try
      cust.Update(txtCustID.Text, txtCompanyName.Text, _
       txtContactName.Text, txtContactTitle.Text, _
       Application("ConnectString").ToString)

      Response.Redirect("nTierCustomers.aspx")

    Catch exp As Exception
      Response.Write("Error Occurred Updating Data: " & exp.Message)

    End Try
  End Sub

End Class
