Imports DataLayer
Imports System.Web.Security

Public Class Login
  Inherits System.Web.UI.Page
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents Label2 As System.Web.UI.WebControls.Label
  Protected WithEvents btnLogin As System.Web.UI.WebControls.Button
  Protected WithEvents txtLogin As System.Web.UI.WebControls.TextBox
  Protected WithEvents lblMsg As System.Web.UI.WebControls.Label
  Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    If Not Page.IsPostBack Then
      txtLogin.Text = Session("LoginID").ToString
    End If
  End Sub

  Private Sub btnLogin_Click( _
  ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles btnLogin.Click

    Dim strID As String
    Dim strPwd As String

    strID = txtLogin.Text
    strPwd = txtPassword.Text

    If LoginValid(strID, strPwd) Then
      If Session("LoginID").ToString = String.Empty Then
        Session("LoginID") = strID
        Session("Password") = strPwd

        FormsAuthentication.RedirectFromLoginPage( _
          strID, False)
      End If
    Else
      lblMsg.Text = "Invalid Login ID/Password."
    End If
  End Sub

  Private Function LoginValid( _
  ByVal LoginID As String, _
  ByVal Password As String) As Boolean
    Dim boolFound As Boolean
    Dim emp As New DataAccess.Employees()

    Try
      'Execute query and return count of valid records
      boolFound = emp.EmployeeValid(LoginID, Password, _
        WebAppConfig.ConnectString)

      If Not boolFound Then
        lblMsg.Text = _
          "Invalid Login ID/Password combination."
      End If

    Catch exp As Exception
      lblMsg.Text = exp.Message

    End Try

    Return boolFound
  End Function
End Class
