using System;

namespace NWTableClassesCS
{
	/// <summary>
	/// Summary description for ProductsTable.
	/// </summary>
	public class ProductsTable
	{
		public ProductsTable()
		{
		}

		private int mintProductID; 
		private string mstrProductName; 
		private int mintSupplierID; 
		private int mintCategoryID; 
		private string mstrQuantityPerUnit;
		private decimal mcurUnitPrice; 
		private short msrtUnitsInStock; 
		private short msrtUnitsOnOrder; 
		private short msrtReorderLevel; 
		private bool mboolDiscontinued; 

		public int ProductID
		{
			get { return mintProductID;}
			set { mintProductID = value; }
		}

		public string ProductName
		{
			get { return mstrProductName;}
			set { mstrProductName = value; }
		}

		public int SupplierID
		{
			get { return mintSupplierID;}
			set { mintSupplierID = value; }
		}

		public int CategoryID
		{
			get { return mintCategoryID;}
			set { mintCategoryID = value; }
		}

		public string QuantityPerUnit
		{
			get { return mstrQuantityPerUnit;}
			set { mstrQuantityPerUnit = value; }
		}

		public decimal UnitPrice
		{
			get { return mcurUnitPrice;}
			set { mcurUnitPrice = value; }
		}

		public short UnitsInStock
		{
			get { return msrtUnitsInStock;}
			set { msrtUnitsInStock = value; }
		}

		public short UnitsOnOrder
		{
			get { return msrtUnitsOnOrder;}
			set { msrtUnitsOnOrder = value; }
		}

		public short ReorderLevel
		{
			get { return msrtReorderLevel;}
			set { msrtReorderLevel = value; }
		}

		public bool Discontinued
		{
			get { return mboolDiscontinued;}
			set { mboolDiscontinued = value; }
		}
	}
}
