using System;

using CommonCS;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.Text;
using NWTableClassesCS;

namespace NWDataClassesCS
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class ProductsData
	{
		public ProductsData()
		{
		}

		public DataSet GetDataSet()
		{
			string strSQL;
			strSQL = "SELECT * FROM Products";

			try
			{
				return SqlHelper.ExecuteDataset(ConfigInfo.ConnectString, CommandType.Text, strSQL);
			}
			catch (Exception exp)
			{
				throw exp;
			}
		}

		public void Insert(ProductsTable prodTable)
		{
			StringBuilder sb = new StringBuilder(1024);

			sb.Append("INSERT INTO Products (");
			sb.Append("ProductName, ");
			sb.Append("UnitPrice, ");
			sb.Append("UnitsInStock, ");
			sb.Append("Discontinued ");
			sb.Append(") VALUES (");
			sb.AppendFormat("'{0}', ", prodTable.ProductName);
			sb.AppendFormat("{0}, ", prodTable.UnitPrice);
			sb.AppendFormat("{0}, ", prodTable.UnitsInStock);
			if (prodTable.Discontinued)
				sb.AppendFormat("{0})", 1);
			else
				sb.AppendFormat("{0})", 0);

			try
			{
				SqlHelper.ExecuteNonQuery( 
					ConfigInfo.ConnectString, 
					CommandType.Text, sb.ToString());
			}
			catch (Exception exp)
			{
				throw exp;
			}
		}

		public void Delete(ProductsTable prodTable)
		{
			StringBuilder sb = new StringBuilder(255);

			sb.Append("DELETE FROM Products ");
			sb.AppendFormat(" WHERE ProductID = {0}", 
				prodTable.ProductID);

			try
			{
				SqlHelper.ExecuteNonQuery( 
					ConfigInfo.ConnectString, 
					CommandType.Text, sb.ToString());
			}
			catch (Exception exp)
			{
				throw exp;
			}
		}
	}
}
