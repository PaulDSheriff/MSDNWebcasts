using System;
using System.Data;
using NWDataClassesCS;
using NWTableClassesCS;

namespace NWBusinessLayerCS
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class Products
	{
		public Products()
		{
		}

		public DataSet GetDataSet()
		{
			ProductsData prod = new ProductsData();

			try
			{
				return prod.GetDataSet();
			}
			catch (Exception exp)
			{
				throw exp;
			}
		}

		public void Insert(ProductsTable prodTable)
		{
			ProductsData prod = new ProductsData();

			try
			{
				Validate(prodTable);

				prod.Insert(prodTable);
			}
			catch (Exception exp)
			{
				throw exp;
			}
		}

		public void Delete(ProductsTable prodTable)
		{
			ProductsData prod = new ProductsData();

			try
			{
				prod.Delete(prodTable);
			}
			catch (Exception exp)
			{
				throw exp;
			}
		}

		public void Validate(ProductsTable prodTable)
		{
			string strMsg = "";

			// Check Business Rules
			if (prodTable.ProductName.Trim() == String.Empty)
				strMsg = "Product Name Must Be Filled In";

			if (prodTable.UnitPrice < 0)
				strMsg += "Unit Price Must Be greater than zero";

			if (strMsg.Trim() != String.Empty)
				throw new ApplicationException(strMsg);
		}
	}
}
