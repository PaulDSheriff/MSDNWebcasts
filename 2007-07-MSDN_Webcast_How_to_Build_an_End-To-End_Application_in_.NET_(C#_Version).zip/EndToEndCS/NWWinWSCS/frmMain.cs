using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace NWWinWSCS
{
	/// <summary>
	/// Summary description for frmMain.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnProducts;
		private System.Windows.Forms.Button btnInsert;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnProducts = new System.Windows.Forms.Button();
			this.btnInsert = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnProducts
			// 
			this.btnProducts.Location = new System.Drawing.Point(8, 8);
			this.btnProducts.Name = "btnProducts";
			this.btnProducts.Size = new System.Drawing.Size(160, 72);
			this.btnProducts.TabIndex = 0;
			this.btnProducts.Text = "Display Products";
			this.btnProducts.Click += new System.EventHandler(this.btnProducts_Click);
			// 
			// btnInsert
			// 
			this.btnInsert.Location = new System.Drawing.Point(184, 8);
			this.btnInsert.Name = "btnInsert";
			this.btnInsert.Size = new System.Drawing.Size(160, 72);
			this.btnInsert.TabIndex = 1;
			this.btnInsert.Text = "Insert a Product";
			this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
			this.ClientSize = new System.Drawing.Size(352, 90);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																																	this.btnInsert,
																																	this.btnProducts});
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "frmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Web Service Examples";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		private void btnProducts_Click(object sender, System.EventArgs e)
		{
			frmProducts frm = new frmProducts();

			frm.Show();
		}

		private void btnInsert_Click(object sender, System.EventArgs e)
		{
			frmProductsInsert frm = new frmProductsInsert();

			frm.Show();
		}
	}
}
