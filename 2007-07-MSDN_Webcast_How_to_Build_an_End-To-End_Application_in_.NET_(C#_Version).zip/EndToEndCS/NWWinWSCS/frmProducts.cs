using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace NWWinWSCS
{
	/// <summary>
	/// Summary description for frmProducts.
	/// </summary>
	public class frmProducts : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid grdProducts;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmProducts()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.grdProducts = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.grdProducts)).BeginInit();
			this.SuspendLayout();
			// 
			// grdProducts
			// 
			this.grdProducts.DataMember = "";
			this.grdProducts.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.grdProducts.Location = new System.Drawing.Point(16, 16);
			this.grdProducts.Name = "grdProducts";
			this.grdProducts.Size = new System.Drawing.Size(520, 240);
			this.grdProducts.TabIndex = 1;
			// 
			// frmProducts
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(552, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																																	this.grdProducts});
			this.Name = "frmProducts";
			this.Text = "Display Products";
			this.Load += new System.EventHandler(this.frmProducts_Load);
			((System.ComponentModel.ISupportInitialize)(this.grdProducts)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion


		private void frmProducts_Load(object sender, System.EventArgs e)
		{
			GridLoad();
		}

		private void GridLoad()
		{
			NWWinWSCS.localhost.ProductsWS prod;

			prod = new NWWinWSCS.localhost.ProductsWS();

			grdProducts.DataSource = 
				prod.GetProducts().Tables[0];
		}
	}
}
