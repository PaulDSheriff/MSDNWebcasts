using System;

namespace CommonCS
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class ConfigInfo
	{
		public ConfigInfo()
		{
		}

		public static string ConnectString
		{
			get { return System.Configuration.ConfigurationSettings.AppSettings.Get("ConnectString"); }
		}
	}
}
