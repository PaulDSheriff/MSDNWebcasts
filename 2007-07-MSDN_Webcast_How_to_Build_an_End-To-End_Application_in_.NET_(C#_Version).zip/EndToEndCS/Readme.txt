How to Develop a .NET Application End-ToEnd
--------------------------------------------
Thank you for attending this Microsoft webcast. In this ZIP file are the sample files that were created during the webcast. Below is a description of each of the projects and some setup notes.

To Install this ZIP file, create a folder on your hard drive somewhere. Unzip this file into that folder and extract so it creates all of the folders in this ZIP file.

Next you should create a virtual root in your IIS called "Samples" that maps to this new folder. If you do this, then the samples should work since they were created under a virtual root named "Samples". If you decide to call this virtual root something else, you will need to change any of the .SLN files that use this name.
 

******************************************************
\EndToEndCS\EndToEndCS.sln
This is the solution file that will open all of the projects. This does assume that you have setup the appropriate virtual directories as explained above.

\NWAppCS
This is the ASP.NET Application that uses the Business and Data Layers.

This project was created in a virtual root named "Samples\EndToEndCS". To use this application you must either create a virtual root on your machine named "Samples\EndToEndCS", or you must change the .SLN file to point to a different virtual root.

******************************************************
\NWWinCS
This is the Windows Application that uses the BUsiness and Data Layers.

******************************************************
\NWWebServiceCS
This is a web service application that exposes the Business and Data Layers.

This project was created in a virtual root named "Samples\EndToEndCS". To use this application you must either create a virtual root on your machine named "Samples\EndToEndCS", or you must change the .SLN file to point to a different virtual root.

******************************************************
\NWWinCS
This is a Windows Application that consumes the Web Service application.

You may need to fix up references to the Web Service application after bringing up this solution. You must have the Web Service installed on your LocalHost first before you bring up this solution.

******************************************************
\NWBusinessLayerCS
This Class Library project contains the business classes.

******************************************************
\NWDataClassesCS
This Class Library project contains the data classes.

******************************************************
\NWTableClassesCS
This Class Library project contains the table classes.

