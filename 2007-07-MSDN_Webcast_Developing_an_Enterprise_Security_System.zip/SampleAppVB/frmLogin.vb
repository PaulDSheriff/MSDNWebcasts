Imports System.Security.Cryptography
Imports System.Data.SqlClient

Public Class frmLogin
   Inherits System.Windows.Forms.Form

   Private mboolValidLogon As Boolean

   ReadOnly Property ValidLogon() As Boolean
      Get
         Return mboolValidLogon
      End Get
   End Property

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents lblLogin As System.Windows.Forms.Label
   Friend WithEvents txtLogin As System.Windows.Forms.TextBox
   Friend WithEvents lblPassword As System.Windows.Forms.Label
   Friend WithEvents btnLogin As System.Windows.Forms.Button
   Friend WithEvents txtPassword As System.Windows.Forms.TextBox
   Friend WithEvents btnCancel As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.lblLogin = New System.Windows.Forms.Label
      Me.txtLogin = New System.Windows.Forms.TextBox
      Me.txtPassword = New System.Windows.Forms.TextBox
      Me.lblPassword = New System.Windows.Forms.Label
      Me.btnLogin = New System.Windows.Forms.Button
      Me.btnCancel = New System.Windows.Forms.Button
      Me.SuspendLayout()
      '
      'lblLogin
      '
      Me.lblLogin.Location = New System.Drawing.Point(8, 8)
      Me.lblLogin.Name = "lblLogin"
      Me.lblLogin.Size = New System.Drawing.Size(136, 24)
      Me.lblLogin.TabIndex = 5
      Me.lblLogin.Text = "Enter Login ID"
      Me.lblLogin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
      '
      'txtLogin
      '
      Me.txtLogin.Location = New System.Drawing.Point(160, 8)
      Me.txtLogin.Name = "txtLogin"
      Me.txtLogin.Size = New System.Drawing.Size(208, 20)
      Me.txtLogin.TabIndex = 1
      Me.txtLogin.Text = ""
      '
      'txtPassword
      '
      Me.txtPassword.Location = New System.Drawing.Point(160, 40)
      Me.txtPassword.MaxLength = 16
      Me.txtPassword.Name = "txtPassword"
      Me.txtPassword.PasswordChar = Microsoft.VisualBasic.ChrW(42)
      Me.txtPassword.Size = New System.Drawing.Size(120, 20)
      Me.txtPassword.TabIndex = 3
      Me.txtPassword.Text = ""
      '
      'lblPassword
      '
      Me.lblPassword.Location = New System.Drawing.Point(8, 40)
      Me.lblPassword.Name = "lblPassword"
      Me.lblPassword.Size = New System.Drawing.Size(136, 24)
      Me.lblPassword.TabIndex = 2
      Me.lblPassword.Text = "Enter Password"
      Me.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
      '
      'btnLogin
      '
      Me.btnLogin.Location = New System.Drawing.Point(296, 72)
      Me.btnLogin.Name = "btnLogin"
      Me.btnLogin.TabIndex = 5
      Me.btnLogin.Text = "Login"
      '
      'btnCancel
      '
      Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.btnCancel.Location = New System.Drawing.Point(216, 72)
      Me.btnCancel.Name = "btnCancel"
      Me.btnCancel.TabIndex = 4
      Me.btnCancel.Text = "Cancel"
      '
      'frmLogin
      '
      Me.AcceptButton = Me.btnLogin
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.btnCancel
      Me.ClientSize = New System.Drawing.Size(378, 106)
      Me.ControlBox = False
      Me.Controls.Add(Me.btnCancel)
      Me.Controls.Add(Me.btnLogin)
      Me.Controls.Add(Me.txtPassword)
      Me.Controls.Add(Me.lblPassword)
      Me.Controls.Add(Me.txtLogin)
      Me.Controls.Add(Me.lblLogin)
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "frmLogin"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Please Login..."
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
      Dim strLogin As String
      Dim strPwd As String

      strLogin = txtLogin.Text.Trim()
      strPwd = txtPassword.Text.Trim()

      Try
         If FormValidate() Then
            ' Compare Login ID and Password against user table
            If IsUserValid(strLogin, strPwd) Then
               mboolValidLogon = True

               Me.Close()
            Else
               MessageBox.Show("Invalid Login ID and/or Password")
            End If
         End If

      Catch exp As Exception
         MessageBox.Show(exp.Message)

      End Try
   End Sub

   Private Function FormValidate() As Boolean
      Dim strMsg As String = String.Empty

      ' Login ID is required
      If txtLogin.Text.Trim() = String.Empty Then
         strMsg &= "Login ID must be filled in" & Environment.NewLine
      End If

      ' Password is Required
      If txtPassword.Text.Trim() = String.Empty Then
         strMsg &= "Password is required, please fill it in" & Environment.NewLine
      End If

      If strMsg.Trim().Length > 0 Then
         MessageBox.Show(strMsg)
         Return False
      Else
         Return True
      End If
   End Function

   Private Function IsUserValid(ByVal LoginID As String, ByVal Password As String) As Boolean
      Dim strSQL As String
      Dim intRows As Integer
      Dim cmd As SqlCommand
      Dim ds As New DataSet
      Dim dr As DataRow
      Dim da As SqlDataAdapter

      Try
         ' Retrieve User Information
         strSQL = "SELECT * FROM eUsers WHERE sLoginID = @sLoginID"
         da = New SqlDataAdapter(strSQL, AppConfig.ConnectString)
         da.SelectCommand.Parameters.Add( _
           New SqlParameter("@sLoginID", SqlDbType.VarChar))
         da.SelectCommand.Parameters("@sLoginID").Value = LoginID

         da.Fill(ds)

         If ds.Tables(0).Rows.Count > 0 Then
            dr = ds.Tables(0).Rows(0)

            ' Hash Password
            Password = dr.Item("iUserID").ToString() & LoginID & Password
            Password = HashString(Password)

            strSQL = "SELECT Count(*) FROM eUsers "
            strSQL &= " WHERE sLoginID = @sLoginID "
            strSQL &= " AND sPassword = @sPassword "

            cmd = New SqlCommand(strSQL)
            cmd.Connection = New SqlConnection(AppConfig.ConnectString)
            cmd.Connection.Open()

            cmd.Parameters.Add(New SqlParameter("@sLoginID", SqlDbType.VarChar))
            cmd.Parameters("@sLoginID").Value = LoginID

            cmd.Parameters.Add(New SqlParameter("@sPassword", SqlDbType.VarChar))
            cmd.Parameters("@sPassword").Value = Password

            intRows = Convert.ToInt32(cmd.ExecuteScalar())

            Return intRows > 0
         Else
            Return False
         End If

      Catch
         Throw

      Finally
         If Not (cmd Is Nothing) Then
            If Not (cmd.Connection Is Nothing) Then
               If cmd.Connection.State <> ConnectionState.Closed Then
                  cmd.Connection.Close()
               End If
               cmd.Connection.Dispose()
            End If
         End If
      End Try
   End Function

   Private Function HashString(ByVal Value As String) As String
      Dim bytValue() As Byte
      Dim bytHash() As Byte
      Dim hash As New SHA1CryptoServiceProvider

      ' Convert the original string to array of Bytes
      bytValue = System.Text.Encoding.UTF8.GetBytes(Value)

      ' Compute the Hash, returns an array of Bytes
      bytHash = hash.ComputeHash(bytValue)

      hash.Clear()

      ' Return a base 64 encoded string of the Hash value
      Return Convert.ToBase64String(bytHash)
   End Function

   Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
      mboolValidLogon = False
      Me.Close()
   End Sub

   Private Sub frmLogin_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Enter
      txtLogin.Focus()
   End Sub
End Class