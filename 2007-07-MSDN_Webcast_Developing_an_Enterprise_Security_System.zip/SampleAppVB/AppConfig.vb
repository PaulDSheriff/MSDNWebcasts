Imports System.Security.Cryptography
Imports Microsoft.Win32
Imports System.Text
Imports System.IO

Public Class AppConfig
   Private Shared mstrConnectString As String

   Shared Sub New()

      mstrConnectString = DecryptString(GetConnectString(), _
         GetEncKey(), GetEncIV())

   End Sub

   Private Shared Function DecryptString(ByVal Value As String, ByVal Key As String, ByVal IV As String) As String
      Dim ct As ICryptoTransform
      Dim ms As MemoryStream
      Dim cs As CryptoStream
      Dim byt() As Byte
      Dim csp As New DESCryptoServiceProvider

      ct = csp.CreateDecryptor(Convert.FromBase64String(Key), Convert.FromBase64String(IV))

      byt = Convert.FromBase64String(Value)

      ms = New MemoryStream
      cs = New CryptoStream(ms, ct, CryptoStreamMode.Write)
      cs.Write(byt, 0, byt.Length)
      cs.FlushFinalBlock()

      cs.Close()

      Return Encoding.UTF8.GetString(ms.ToArray())
   End Function

   Public Shared ReadOnly Property ConnectString() As String
      Get
         Return mstrConnectString
      End Get
   End Property

#Region "Registry Methods"
   Const CONNECTION_KEY As String = "Software\MyApp\Data"

   Private Shared Function GetRegData(ByVal Key As String, ByVal SubKey As String) As String
      Dim rk As RegistryKey

      Try
         rk = Registry.CurrentUser.OpenSubKey(Key)

         If Not (rk Is Nothing) Then
            Return rk.GetValue(SubKey).ToString()
         End If

      Catch exp As Exception

      Finally
         If Not (rk Is Nothing) Then
            rk.Close()
         End If

      End Try
   End Function

   Public Shared Function GetConnectString() As String
      Return GetRegData(CONNECTION_KEY, "EncString")
   End Function

   Public Shared Function GetEncKey() As String
      Return GetRegData(CONNECTION_KEY, "EncKey")
   End Function

   Public Shared Function GetEncIV() As String
      Return GetRegData(CONNECTION_KEY, "EncIV")
   End Function
#End Region
End Class
