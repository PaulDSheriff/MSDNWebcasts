using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.Security.Cryptography;
using System.Text;

namespace CryptoSampleCS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmHash : System.Windows.Forms.Form
	{
		// Private Variables for this Form
		private HashAlgorithm mhash;

		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.RadioButton optMD5;
		internal System.Windows.Forms.RadioButton optSHA1;
		internal System.Windows.Forms.Label Label4;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.TextBox txtHashed;
		internal System.Windows.Forms.TextBox txtOriginal;
		internal System.Windows.Forms.Button cmdHash;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmHash()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.GroupBox1 = new System.Windows.Forms.GroupBox();
      this.optMD5 = new System.Windows.Forms.RadioButton();
      this.optSHA1 = new System.Windows.Forms.RadioButton();
      this.Label4 = new System.Windows.Forms.Label();
      this.Label1 = new System.Windows.Forms.Label();
      this.txtHashed = new System.Windows.Forms.TextBox();
      this.txtOriginal = new System.Windows.Forms.TextBox();
      this.cmdHash = new System.Windows.Forms.Button();
      this.GroupBox1.SuspendLayout();
      this.SuspendLayout();
      // 
      // GroupBox1
      // 
      this.GroupBox1.Controls.Add(this.optMD5);
      this.GroupBox1.Controls.Add(this.optSHA1);
      this.GroupBox1.Location = new System.Drawing.Point(8, 8);
      this.GroupBox1.Name = "GroupBox1";
      this.GroupBox1.Size = new System.Drawing.Size(432, 64);
      this.GroupBox1.TabIndex = 0;
      this.GroupBox1.TabStop = false;
      this.GroupBox1.Text = "Select Hashing Type";
      // 
      // optMD5
      // 
      this.optMD5.Location = new System.Drawing.Point(16, 42);
      this.optMD5.Name = "optMD5";
      this.optMD5.Size = new System.Drawing.Size(160, 16);
      this.optMD5.TabIndex = 1;
      this.optMD5.Text = "MD5";
      // 
      // optSHA1
      // 
      this.optSHA1.Checked = true;
      this.optSHA1.Location = new System.Drawing.Point(16, 24);
      this.optSHA1.Name = "optSHA1";
      this.optSHA1.Size = new System.Drawing.Size(168, 16);
      this.optSHA1.TabIndex = 0;
      this.optSHA1.TabStop = true;
      this.optSHA1.Text = "SHA1";
      // 
      // Label4
      // 
      this.Label4.Location = new System.Drawing.Point(8, 200);
      this.Label4.Name = "Label4";
      this.Label4.Size = new System.Drawing.Size(64, 40);
      this.Label4.TabIndex = 4;
      this.Label4.Text = "Hashed String";
      // 
      // Label1
      // 
      this.Label1.Location = new System.Drawing.Point(8, 88);
      this.Label1.Name = "Label1";
      this.Label1.Size = new System.Drawing.Size(64, 40);
      this.Label1.TabIndex = 1;
      this.Label1.Text = "Original String";
      // 
      // txtHashed
      // 
      this.txtHashed.Location = new System.Drawing.Point(72, 200);
      this.txtHashed.Multiline = true;
      this.txtHashed.Name = "txtHashed";
      this.txtHashed.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtHashed.Size = new System.Drawing.Size(368, 64);
      this.txtHashed.TabIndex = 5;
      this.txtHashed.Text = "";
      // 
      // txtOriginal
      // 
      this.txtOriginal.Location = new System.Drawing.Point(72, 88);
      this.txtOriginal.Multiline = true;
      this.txtOriginal.Name = "txtOriginal";
      this.txtOriginal.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtOriginal.Size = new System.Drawing.Size(368, 64);
      this.txtOriginal.TabIndex = 2;
      this.txtOriginal.Text = "Password";
      // 
      // cmdHash
      // 
      this.cmdHash.Location = new System.Drawing.Point(72, 160);
      this.cmdHash.Name = "cmdHash";
      this.cmdHash.Size = new System.Drawing.Size(120, 24);
      this.cmdHash.TabIndex = 3;
      this.cmdHash.Text = "Hash";
      this.cmdHash.Click += new System.EventHandler(this.cmdHash_Click);
      // 
      // frmHash
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
      this.ClientSize = new System.Drawing.Size(448, 266);
      this.Controls.Add(this.GroupBox1);
      this.Controls.Add(this.Label4);
      this.Controls.Add(this.Label1);
      this.Controls.Add(this.txtHashed);
      this.Controls.Add(this.txtOriginal);
      this.Controls.Add(this.cmdHash);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "frmHash";
      this.Text = "Hashing Strings";
      this.GroupBox1.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion


		private void cmdHash_Click(object sender, System.EventArgs e)
		{
			txtHashed.Text = HashString(txtOriginal.Text);

			// Call Hard Coded Routines
			TestHash(txtOriginal.Text);
			TestHashMD5(txtOriginal.Text);
		}

		private string HashString(string Value)
		{
			byte[] bytValue;
			byte[] bytHash;

			mhash = SetHash();

			// Convert the original string to array of Bytes
			bytValue = System.Text.Encoding.UTF8.GetBytes(Value);

			// Compute the Hash, returns an array of Bytes
			bytHash = mhash.ComputeHash(bytValue);

			mhash.Clear();

			// Return a base 64 encoded string of the Hash value
			return Convert.ToBase64String(bytHash);
		}

		private HashAlgorithm SetHash()
		{
			if(this.optSHA1.Checked)
				return new SHA1CryptoServiceProvider();
			else
				return new MD5CryptoServiceProvider();
		}

		#region "Hard Coded Routines
		private void TestHash(string TextToHash)
		{
			byte[] bytValue;
			byte[] bytHash;
			SHA1CryptoServiceProvider SHA1;

			SHA1 = new SHA1CryptoServiceProvider();

			// Convert the original string to array of Bytes
			bytValue = System.Text.Encoding.
        UTF8.GetBytes(TextToHash);

			// Compute the Hash, returns an array of Bytes
			bytHash = SHA1.ComputeHash(bytValue);

			SHA1.Clear();

			// Return a base 64 encoded string of the Hash value
			System.Diagnostics.Debug.
        WriteLine(Convert.ToBase64String(bytHash));
		}

		private void TestHashMD5(string TextToHash)
		{
			byte[] bytValue;
			byte[] bytHash;
			MD5CryptoServiceProvider MD5;

			MD5 = new MD5CryptoServiceProvider();

			// Convert the original string to array of Bytes
			bytValue = System.Text.Encoding.
        UTF8.GetBytes(TextToHash);

			// Compute the Hash, returns an array of Bytes
			bytHash = MD5.ComputeHash(bytValue);

			MD5.Clear();

			// Return a base 64 encoded string of the Hash value
			System.Diagnostics.Debug.
        WriteLine(Convert.ToBase64String(bytHash));
		}
		#endregion
	}
}
