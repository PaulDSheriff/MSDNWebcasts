using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace PasswordIsStrongCS
{
	/// <summary>
	/// Summary description for frmPasswordTest.
	/// </summary>
	public class frmPasswordTest : System.Windows.Forms.Form
	{
    internal System.Windows.Forms.Button btnCheck;
    internal System.Windows.Forms.TextBox txtPassword;
    internal System.Windows.Forms.Label Label1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmPasswordTest()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() 
    {
      Application.Run(new frmPasswordTest());
    }


		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.btnCheck = new System.Windows.Forms.Button();
      this.txtPassword = new System.Windows.Forms.TextBox();
      this.Label1 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // btnCheck
      // 
      this.btnCheck.Location = new System.Drawing.Point(264, 40);
      this.btnCheck.Name = "btnCheck";
      this.btnCheck.TabIndex = 5;
      this.btnCheck.Text = "Check";
      this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
      // 
      // txtPassword
      // 
      this.txtPassword.Location = new System.Drawing.Point(112, 8);
      this.txtPassword.Name = "txtPassword";
      this.txtPassword.Size = new System.Drawing.Size(224, 20);
      this.txtPassword.TabIndex = 4;
      this.txtPassword.Text = "";
      // 
      // Label1
      // 
      this.Label1.Location = new System.Drawing.Point(8, 8);
      this.Label1.Name = "Label1";
      this.Label1.Size = new System.Drawing.Size(88, 23);
      this.Label1.TabIndex = 3;
      this.Label1.Text = "Password";
      // 
      // frmPasswordTest
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(344, 66);
      this.Controls.Add(this.btnCheck);
      this.Controls.Add(this.txtPassword);
      this.Controls.Add(this.Label1);
      this.Name = "frmPasswordTest";
      this.Text = "Check for Strong Password";
      this.ResumeLayout(false);

    }
		#endregion

    private void btnCheck_Click(object sender, System.EventArgs e)
    {
      if (IsStrongPassword(txtPassword.Text))
        MessageBox.Show("Password is Valid");
      else
        MessageBox.Show("Password is Invalid");
    }

    private bool IsStrongPassword(string password)
    {
      bool boolRet = false;
      Regex rx;

      rx = new Regex(@"^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*\W)", RegexOptions.Singleline);

      if (rx.IsMatch(password))
        boolRet = true;

      return boolRet;
    }
	}
}
