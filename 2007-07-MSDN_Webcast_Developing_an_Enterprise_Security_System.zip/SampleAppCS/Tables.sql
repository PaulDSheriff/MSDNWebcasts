CREATE TABLE eUsers
(
	iUserID int NOT NULL PRIMARY KEY,
	sLoginID varchar(20) NOT NULL,
	sUserName varchar(50) NULL,
	sPassword varchar(255) NOT NULL
)
GO

INSERT INTO eUsers(1, 'Paul', 'Paul Sheriff', 'pPtwLs57jNthzXU1PQXTF2dRyD0=')
INSERT INTO eUsers(2, 'Ken', 'Ken Getz', 'g2taAIV/7Xf1zWQCX+DM4YB8/tg=')
INSERT INTO eUsers(3, 'Bruce', 'Bruce Jones', '5cTAKJiF4zjQtmdKV4btTMB7V/4=')
GO