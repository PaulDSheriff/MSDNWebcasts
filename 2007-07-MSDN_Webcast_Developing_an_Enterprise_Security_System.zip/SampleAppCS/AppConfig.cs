using System;
using System.Security.Cryptography;
using Microsoft.Win32;
using System.Text;
using System.IO;

namespace SampleAppCS
{
	/// <summary>
	/// Summary description for AppConfig.
	/// </summary>
	public class AppConfig
	{
    // Constructor
		static AppConfig()
		{
			 mConnectString = DecryptString(GetConnectString(), 
         GetEncKey(), GetEncIV());
		}

    private static string mConnectString;

    public static string ConnectString
    {
      get {return mConnectString;}
    }

    private static string DecryptString(string Value, string key, string IV)
    {
      ICryptoTransform ct;
      MemoryStream ms;
      CryptoStream cs;
      byte[] byt;
      DESCryptoServiceProvider csp = new DESCryptoServiceProvider();

      ct = csp.CreateDecryptor(Convert.FromBase64String(key), Convert.FromBase64String(IV));

      byt = Convert.FromBase64String(Value);

      ms = new MemoryStream();
      cs = new CryptoStream(ms, ct, CryptoStreamMode.Write);
      cs.Write(byt, 0, byt.Length);
      cs.FlushFinalBlock();

      cs.Close();

      return Encoding.UTF8.GetString(ms.ToArray());
    }

    const string CONNECTION_KEY = @"Software\MyApp\Data";

    private static string GetRegData(string Key, string SubKey)
    {
      RegistryKey rk = null;

      try
      {
        rk = Registry.CurrentUser.OpenSubKey(Key);

        if (rk != null)
          return rk.GetValue(SubKey).ToString();
      }

      catch
      {
        throw;
      }

      finally
      {
        if (rk != null)
          rk.Close();
      }

      return "";
    }

    public static string GetConnectString()
    {
      return GetRegData(CONNECTION_KEY, "EncString");
    }

    public static string GetEncKey()
    {
      return GetRegData(CONNECTION_KEY, "EncKey");
    }

    public static string GetEncIV()
    {
      return GetRegData(CONNECTION_KEY, "EncIV");
    }
	}
}
