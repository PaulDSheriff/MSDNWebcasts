using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace SampleAppCS
{
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class frmMain : System.Windows.Forms.Form
  {
    private System.Windows.Forms.DataGrid grdProducts;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public frmMain()
    {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing )
    {
      if( disposing )
      {
        if (components != null) 
        {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.grdProducts = new System.Windows.Forms.DataGrid();
      ((System.ComponentModel.ISupportInitialize)(this.grdProducts)).BeginInit();
      this.SuspendLayout();
      // 
      // grdProducts
      // 
      this.grdProducts.DataMember = "";
      this.grdProducts.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.grdProducts.Location = new System.Drawing.Point(8, 8);
      this.grdProducts.Name = "grdProducts";
      this.grdProducts.Size = new System.Drawing.Size(688, 320);
      this.grdProducts.TabIndex = 0;
      // 
      // frmMain
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(704, 338);
      this.Controls.Add(this.grdProducts);
      this.Name = "frmMain";
      this.Text = "Display Products";
      this.Load += new System.EventHandler(this.frmMain_Load);
      ((System.ComponentModel.ISupportInitialize)(this.grdProducts)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() 
    {
      Application.Run(new frmMain());
    }

    private void frmMain_Load(object sender, System.EventArgs e)
    {
      if (LoginValid())
        GridLoad();
      else
        this.Close();
    }

    private bool LoginValid()
    {
      frmLogin frm = new frmLogin();

      frm.ShowDialog();

      return frm.ValidLogon;
    }

    private void GridLoad()
    {
      DataSet ds = new DataSet();
      SqlDataAdapter da;
      
      try
      {
        da = new SqlDataAdapter("SELECT * FROM Products", AppConfig.ConnectString);

        da.Fill(ds);

        grdProducts.DataSource = ds.Tables[0];
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
  }
}
