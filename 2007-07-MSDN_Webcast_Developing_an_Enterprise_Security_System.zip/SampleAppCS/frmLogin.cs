using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Data.SqlClient;
using System.Data;

namespace SampleAppCS
{
  /// <summary>
  /// Summary description for frmLogin.
  /// </summary>
  public class frmLogin : System.Windows.Forms.Form
  {
    internal System.Windows.Forms.Button btnCancel;
    internal System.Windows.Forms.Button btnLogin;
    internal System.Windows.Forms.TextBox txtPassword;
    internal System.Windows.Forms.Label lblPassword;
    internal System.Windows.Forms.TextBox txtLogin;
    internal System.Windows.Forms.Label lblLogin;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    private bool mboolValidLogon;

    public bool ValidLogon
    {
      get {return mboolValidLogon;}
    }

    public frmLogin()
    {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing )
    {
      if( disposing )
      {
        if(components != null)
        {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.btnCancel = new System.Windows.Forms.Button();
      this.btnLogin = new System.Windows.Forms.Button();
      this.txtPassword = new System.Windows.Forms.TextBox();
      this.lblPassword = new System.Windows.Forms.Label();
      this.txtLogin = new System.Windows.Forms.TextBox();
      this.lblLogin = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // btnCancel
      // 
      this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.btnCancel.Location = new System.Drawing.Point(216, 72);
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.TabIndex = 9;
      this.btnCancel.Text = "Cancel";
      this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
      // 
      // btnLogin
      // 
      this.btnLogin.Location = new System.Drawing.Point(296, 72);
      this.btnLogin.Name = "btnLogin";
      this.btnLogin.TabIndex = 11;
      this.btnLogin.Text = "Login";
      this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
      // 
      // txtPassword
      // 
      this.txtPassword.Location = new System.Drawing.Point(160, 40);
      this.txtPassword.MaxLength = 16;
      this.txtPassword.Name = "txtPassword";
      this.txtPassword.PasswordChar = '*';
      this.txtPassword.Size = new System.Drawing.Size(120, 20);
      this.txtPassword.TabIndex = 8;
      this.txtPassword.Text = "";
      // 
      // lblPassword
      // 
      this.lblPassword.Location = new System.Drawing.Point(8, 40);
      this.lblPassword.Name = "lblPassword";
      this.lblPassword.Size = new System.Drawing.Size(136, 24);
      this.lblPassword.TabIndex = 7;
      this.lblPassword.Text = "Enter Password";
      this.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // txtLogin
      // 
      this.txtLogin.Location = new System.Drawing.Point(160, 8);
      this.txtLogin.Name = "txtLogin";
      this.txtLogin.Size = new System.Drawing.Size(208, 20);
      this.txtLogin.TabIndex = 6;
      this.txtLogin.Text = "";
      // 
      // lblLogin
      // 
      this.lblLogin.Location = new System.Drawing.Point(8, 8);
      this.lblLogin.Name = "lblLogin";
      this.lblLogin.Size = new System.Drawing.Size(136, 24);
      this.lblLogin.TabIndex = 10;
      this.lblLogin.Text = "Enter Login ID";
      this.lblLogin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // frmLogin
      // 
      this.AcceptButton = this.btnLogin;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.CancelButton = this.btnCancel;
      this.ClientSize = new System.Drawing.Size(376, 98);
      this.Controls.Add(this.btnCancel);
      this.Controls.Add(this.btnLogin);
      this.Controls.Add(this.txtPassword);
      this.Controls.Add(this.lblPassword);
      this.Controls.Add(this.txtLogin);
      this.Controls.Add(this.lblLogin);
      this.Name = "frmLogin";
      this.Text = "Please Login";
      this.Enter += new System.EventHandler(this.frmLogin_Enter);
      this.ResumeLayout(false);

    }
    #endregion

    private void btnCancel_Click(object sender, System.EventArgs e)
    {
      mboolValidLogon = false;

      this.Close();
    }

    private void frmLogin_Enter(object sender, System.EventArgs e)
    {
      txtLogin.Focus();
    }
  
    private void btnLogin_Click(object sender, System.EventArgs e)
    {
      string login;
      string pwd;

      login = txtLogin.Text.Trim();
      pwd = txtPassword.Text.Trim();

      try
      {
        if (FormValidate())
        {
          if (IsUserValid(login, pwd))
          {
            mboolValidLogon = true;

            this.Close();
          }
          else
            MessageBox.Show("Invalid Login ID and/or Password");
        }

      }

      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }   
    }

    private bool FormValidate()
    {
      string msg = String.Empty;

      // Login ID is required
      if (txtLogin.Text.Trim() == String.Empty)
        msg += "Login ID must be filled in" + Environment.NewLine;

      // Password is required
      if (txtPassword.Text.Trim() == String.Empty)
        msg += "Password is Required, please fill it in" + Environment.NewLine;

      if (msg.Trim().Length > 0)
      {
        MessageBox.Show(msg);
        return false;
      }
      else
        return true;
    }

    private bool IsUserValid(string LoginID, string Password)
    {
      string sql = String.Empty;
      int rows = 0;
      SqlCommand cmd = null;
      DataSet ds = new DataSet();
      DataRow dr = null;
      SqlDataAdapter da = null;

      try
      {
        // Retrieve User Information
        sql = "SELECT * FROM eUsers WHERE sLoginID = @sLoginID";
        da = new SqlDataAdapter(sql, AppConfig.ConnectString);
        da.SelectCommand.Parameters.Add(
          new SqlParameter("@sLoginID", SqlDbType.VarChar));
        da.SelectCommand.Parameters["@sLoginID"].Value = LoginID;

        da.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
          dr = ds.Tables[0].Rows[0];

          // Hash Password
          Password = dr["iUserID"].ToString() + LoginID + Password;
          Password = HashString(Password);

          sql = "SELECT Count(*) FROM eUsers ";
          sql += " WHERE sLoginID = @sLoginID ";
          sql += " AND sPassword = @sPassword ";

          cmd = new SqlCommand(sql);
          cmd.Connection = new SqlConnection(AppConfig.ConnectString);
          cmd.Connection.Open();

          cmd.Parameters.Add(new SqlParameter("@sLoginID", SqlDbType.VarChar));
          cmd.Parameters["@sLoginID"].Value = LoginID;

          cmd.Parameters.Add(new SqlParameter("@sPassword", SqlDbType.VarChar));
          cmd.Parameters["@sPassword"].Value = Password;

          rows = Convert.ToInt32(cmd.ExecuteScalar());

          return (rows > 0);
        }
        else
          return false;
      }
      catch
      {
        throw;
      }
      finally
      {
        if (cmd != null)
        {
          if (cmd.Connection != null)
          {
            if (cmd.Connection.State != ConnectionState.Closed)
              cmd.Connection.Close();

            cmd.Connection.Dispose();
          }
        }
      }

    }

    private string HashString(string Value)
    {
      byte[] bytValue;
      byte[] bytHash;
      SHA1CryptoServiceProvider hash = new SHA1CryptoServiceProvider();

      // Convert the original string to array of Bytes
      bytValue = System.Text.Encoding.UTF8.GetBytes(Value);

      // Compute the Hash, returns an array of Bytes
      bytHash = hash.ComputeHash(bytValue);

      hash.Clear();

      // Return a base 64 encoded string of the Hash value
      return Convert.ToBase64String(bytHash);
    }
  }
}
