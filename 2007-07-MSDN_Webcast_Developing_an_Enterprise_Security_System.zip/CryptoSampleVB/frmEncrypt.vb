Imports System.Security.Cryptography
Imports System.Text
Imports System.IO

Public Class frmEncrypt
   Inherits System.Windows.Forms.Form

   Const CONNECTION_KEY As String = "Software\MyApp\Data"

   Private mCSP As SymmetricAlgorithm

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents Label5 As System.Windows.Forms.Label
   Friend WithEvents Label4 As System.Windows.Forms.Label
   Friend WithEvents txtEncrypted As System.Windows.Forms.TextBox
   Friend WithEvents txtIV As System.Windows.Forms.TextBox
   Friend WithEvents txtKey As System.Windows.Forms.TextBox
   Friend WithEvents txtOriginal As System.Windows.Forms.TextBox
   Friend WithEvents btnIVGen As System.Windows.Forms.Button
   Friend WithEvents btnKeyGen As System.Windows.Forms.Button
   Friend WithEvents Label3 As System.Windows.Forms.Label
   Friend WithEvents Label2 As System.Windows.Forms.Label
   Friend WithEvents cmdDecrypt As System.Windows.Forms.Button
   Friend WithEvents cmdEncrypt As System.Windows.Forms.Button
   Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
   Friend WithEvents optTripleDES As System.Windows.Forms.RadioButton
   Friend WithEvents optDES As System.Windows.Forms.RadioButton
   Friend WithEvents btnSave As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.Label5 = New System.Windows.Forms.Label
      Me.Label4 = New System.Windows.Forms.Label
      Me.txtEncrypted = New System.Windows.Forms.TextBox
      Me.txtIV = New System.Windows.Forms.TextBox
      Me.txtKey = New System.Windows.Forms.TextBox
      Me.txtOriginal = New System.Windows.Forms.TextBox
      Me.btnIVGen = New System.Windows.Forms.Button
      Me.btnKeyGen = New System.Windows.Forms.Button
      Me.Label3 = New System.Windows.Forms.Label
      Me.Label2 = New System.Windows.Forms.Label
      Me.cmdDecrypt = New System.Windows.Forms.Button
      Me.cmdEncrypt = New System.Windows.Forms.Button
      Me.GroupBox1 = New System.Windows.Forms.GroupBox
      Me.optTripleDES = New System.Windows.Forms.RadioButton
      Me.optDES = New System.Windows.Forms.RadioButton
      Me.btnSave = New System.Windows.Forms.Button
      Me.GroupBox1.SuspendLayout()
      Me.SuspendLayout()
      '
      'Label5
      '
      Me.Label5.Location = New System.Drawing.Point(8, 264)
      Me.Label5.Name = "Label5"
      Me.Label5.Size = New System.Drawing.Size(88, 48)
      Me.Label5.TabIndex = 11
      Me.Label5.Text = "Encrypted String"
      '
      'Label4
      '
      Me.Label4.Location = New System.Drawing.Point(8, 168)
      Me.Label4.Name = "Label4"
      Me.Label4.Size = New System.Drawing.Size(80, 40)
      Me.Label4.TabIndex = 7
      Me.Label4.Text = "Original String"
      '
      'txtEncrypted
      '
      Me.txtEncrypted.Location = New System.Drawing.Point(104, 272)
      Me.txtEncrypted.Multiline = True
      Me.txtEncrypted.Name = "txtEncrypted"
      Me.txtEncrypted.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtEncrypted.Size = New System.Drawing.Size(384, 64)
      Me.txtEncrypted.TabIndex = 12
      Me.txtEncrypted.Text = ""
      '
      'txtIV
      '
      Me.txtIV.Location = New System.Drawing.Point(104, 136)
      Me.txtIV.Name = "txtIV"
      Me.txtIV.Size = New System.Drawing.Size(280, 26)
      Me.txtIV.TabIndex = 5
      Me.txtIV.Text = ""
      '
      'txtKey
      '
      Me.txtKey.Location = New System.Drawing.Point(104, 104)
      Me.txtKey.Name = "txtKey"
      Me.txtKey.Size = New System.Drawing.Size(280, 26)
      Me.txtKey.TabIndex = 2
      Me.txtKey.Text = ""
      '
      'txtOriginal
      '
      Me.txtOriginal.Location = New System.Drawing.Point(104, 168)
      Me.txtOriginal.Multiline = True
      Me.txtOriginal.Name = "txtOriginal"
      Me.txtOriginal.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtOriginal.Size = New System.Drawing.Size(384, 64)
      Me.txtOriginal.TabIndex = 8
      Me.txtOriginal.Text = "Server=localhost;Database=Northwind;UID=sa;PWD=sa"
      '
      'btnIVGen
      '
      Me.btnIVGen.Location = New System.Drawing.Point(392, 136)
      Me.btnIVGen.Name = "btnIVGen"
      Me.btnIVGen.Size = New System.Drawing.Size(96, 24)
      Me.btnIVGen.TabIndex = 6
      Me.btnIVGen.Text = "Gen IV"
      '
      'btnKeyGen
      '
      Me.btnKeyGen.Location = New System.Drawing.Point(392, 104)
      Me.btnKeyGen.Name = "btnKeyGen"
      Me.btnKeyGen.Size = New System.Drawing.Size(96, 24)
      Me.btnKeyGen.TabIndex = 3
      Me.btnKeyGen.Text = "Gen Key"
      '
      'Label3
      '
      Me.Label3.Location = New System.Drawing.Point(8, 136)
      Me.Label3.Name = "Label3"
      Me.Label3.Size = New System.Drawing.Size(48, 16)
      Me.Label3.TabIndex = 4
      Me.Label3.Text = "IV"
      '
      'Label2
      '
      Me.Label2.Location = New System.Drawing.Point(8, 112)
      Me.Label2.Name = "Label2"
      Me.Label2.Size = New System.Drawing.Size(72, 16)
      Me.Label2.TabIndex = 1
      Me.Label2.Text = "Key"
      '
      'cmdDecrypt
      '
      Me.cmdDecrypt.Location = New System.Drawing.Point(237, 240)
      Me.cmdDecrypt.Name = "cmdDecrypt"
      Me.cmdDecrypt.Size = New System.Drawing.Size(120, 24)
      Me.cmdDecrypt.TabIndex = 10
      Me.cmdDecrypt.Text = "Decrypt"
      '
      'cmdEncrypt
      '
      Me.cmdEncrypt.Location = New System.Drawing.Point(104, 240)
      Me.cmdEncrypt.Name = "cmdEncrypt"
      Me.cmdEncrypt.Size = New System.Drawing.Size(120, 24)
      Me.cmdEncrypt.TabIndex = 9
      Me.cmdEncrypt.Text = "Encrypt"
      '
      'GroupBox1
      '
      Me.GroupBox1.Controls.Add(Me.optTripleDES)
      Me.GroupBox1.Controls.Add(Me.optDES)
      Me.GroupBox1.Location = New System.Drawing.Point(8, 16)
      Me.GroupBox1.Name = "GroupBox1"
      Me.GroupBox1.Size = New System.Drawing.Size(480, 80)
      Me.GroupBox1.TabIndex = 0
      Me.GroupBox1.TabStop = False
      Me.GroupBox1.Text = "Select Encryption Type"
      '
      'optTripleDES
      '
      Me.optTripleDES.Location = New System.Drawing.Point(16, 48)
      Me.optTripleDES.Name = "optTripleDES"
      Me.optTripleDES.Size = New System.Drawing.Size(160, 24)
      Me.optTripleDES.TabIndex = 1
      Me.optTripleDES.Text = "Triple DES"
      '
      'optDES
      '
      Me.optDES.Checked = True
      Me.optDES.Location = New System.Drawing.Point(16, 24)
      Me.optDES.Name = "optDES"
      Me.optDES.Size = New System.Drawing.Size(168, 16)
      Me.optDES.TabIndex = 0
      Me.optDES.TabStop = True
      Me.optDES.Text = "DES"
      '
      'btnSave
      '
      Me.btnSave.Location = New System.Drawing.Point(368, 240)
      Me.btnSave.Name = "btnSave"
      Me.btnSave.Size = New System.Drawing.Size(120, 24)
      Me.btnSave.TabIndex = 13
      Me.btnSave.Text = "Save"
      '
      'frmEncrypt
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
      Me.ClientSize = New System.Drawing.Size(496, 338)
      Me.Controls.Add(Me.btnSave)
      Me.Controls.Add(Me.GroupBox1)
      Me.Controls.Add(Me.Label5)
      Me.Controls.Add(Me.Label4)
      Me.Controls.Add(Me.txtEncrypted)
      Me.Controls.Add(Me.txtIV)
      Me.Controls.Add(Me.txtKey)
      Me.Controls.Add(Me.txtOriginal)
      Me.Controls.Add(Me.btnIVGen)
      Me.Controls.Add(Me.btnKeyGen)
      Me.Controls.Add(Me.Label3)
      Me.Controls.Add(Me.Label2)
      Me.Controls.Add(Me.cmdDecrypt)
      Me.Controls.Add(Me.cmdEncrypt)
      Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.Name = "frmEncrypt"
      Me.Text = "Encryption"
      Me.GroupBox1.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnEncrypt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdEncrypt.Click
      txtEncrypted.Text = EncryptString(txtOriginal.Text)
   End Sub

   Private Sub btnDecrypt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDecrypt.Click
      txtOriginal.Text = DecryptString(txtEncrypted.Text)
   End Sub

   Private Function EncryptString(ByVal Value As String) As String
      Dim ct As ICryptoTransform
      Dim ms As MemoryStream
      Dim cs As CryptoStream
      Dim byt() As Byte

      ct = mCSP.CreateEncryptor(mCSP.Key, mCSP.IV)

      byt = Encoding.UTF8.GetBytes(Value)

      ms = New MemoryStream
      cs = New CryptoStream(ms, ct, CryptoStreamMode.Write)
      cs.Write(byt, 0, byt.Length)
      cs.FlushFinalBlock()

      cs.Close()

      Return Convert.ToBase64String(ms.ToArray())
   End Function

   Private Function DecryptString(ByVal Value As String) As String
      Dim ct As ICryptoTransform
      Dim ms As MemoryStream
      Dim cs As CryptoStream
      Dim byt() As Byte

      ct = mCSP.CreateDecryptor(mCSP.Key, mCSP.IV)

      byt = Convert.FromBase64String(Value)

      ms = New MemoryStream
      cs = New CryptoStream(ms, ct, CryptoStreamMode.Write)
      cs.Write(byt, 0, byt.Length)
      cs.FlushFinalBlock()

      cs.Close()

      Return Encoding.UTF8.GetString(ms.ToArray())
   End Function

   Private Function SetEnc() As SymmetricAlgorithm
      If optDES.Checked Then
         Return New DESCryptoServiceProvider
      Else
         If optTripleDES.Checked Then
            Return New TripleDESCryptoServiceProvider
         End If
      End If
   End Function

   Private Sub btnKeyGen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeyGen.Click
      mCSP = SetEnc()

      mCSP.GenerateKey()

      txtKey.Text = Convert.ToBase64String(mCSP.Key)
   End Sub

   Private Sub btnIVGen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIVGen.Click
      mCSP.GenerateIV()

      txtIV.Text = Convert.ToBase64String(mCSP.IV)
   End Sub

   Private Sub frmEncrypt_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

   End Sub

   Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
      SaveRegData(CONNECTION_KEY, "EncString", txtEncrypted.Text)
      SaveRegData(CONNECTION_KEY, "EncKey", txtKey.Text)
      SaveRegData(CONNECTION_KEY, "EncIV", txtIV.Text)
   End Sub

   Private Sub SaveRegData(ByVal Key As String, ByVal SubKey As String, ByVal Value As String)
      Dim rk As Microsoft.Win32.RegistryKey

      Try
         rk = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Key, True)

         If rk Is Nothing Then
            rk = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(Key)
         End If

         rk.SetValue(SubKey, Value)

      Catch exp As Exception

      Finally
         rk.Close()

      End Try
   End Sub
End Class
