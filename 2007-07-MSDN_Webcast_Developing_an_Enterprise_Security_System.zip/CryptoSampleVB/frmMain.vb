Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
  Friend WithEvents btnHash As System.Windows.Forms.Button
  Friend WithEvents btnEncrypt As System.Windows.Forms.Button
  Friend WithEvents Button1 As System.Windows.Forms.Button
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.btnHash = New System.Windows.Forms.Button
    Me.btnEncrypt = New System.Windows.Forms.Button
    Me.Button1 = New System.Windows.Forms.Button
    Me.SuspendLayout()
    '
    'btnHash
    '
    Me.btnHash.Location = New System.Drawing.Point(8, 8)
    Me.btnHash.Name = "btnHash"
    Me.btnHash.Size = New System.Drawing.Size(128, 80)
    Me.btnHash.TabIndex = 0
    Me.btnHash.Text = "Hashing"
    '
    'btnEncrypt
    '
    Me.btnEncrypt.Location = New System.Drawing.Point(280, 8)
    Me.btnEncrypt.Name = "btnEncrypt"
    Me.btnEncrypt.Size = New System.Drawing.Size(136, 80)
    Me.btnEncrypt.TabIndex = 1
    Me.btnEncrypt.Text = "Encryption and Decryption"
    '
    'Button1
    '
    Me.Button1.Location = New System.Drawing.Point(144, 8)
    Me.Button1.Name = "Button1"
    Me.Button1.Size = New System.Drawing.Size(128, 80)
    Me.Button1.TabIndex = 2
    Me.Button1.Text = "Hash With Salt"
    '
    'frmMain
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
    Me.ClientSize = New System.Drawing.Size(424, 98)
    Me.Controls.Add(Me.Button1)
    Me.Controls.Add(Me.btnEncrypt)
    Me.Controls.Add(Me.btnHash)
    Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Name = "frmMain"
    Me.Text = "Crypto Samples"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub btnHash_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHash.Click
    Dim frm As frmHash

    frm = New frmHash

    frm.Show()
  End Sub

  Private Sub btnEncrypt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEncrypt.Click
    Dim frm As frmEncrypt

    frm = New frmEncrypt

    frm.Show()
  End Sub

  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
    Dim frm As frmHashWithSalt

    frm = New frmHashWithSalt

    frm.Show()
  End Sub
End Class
