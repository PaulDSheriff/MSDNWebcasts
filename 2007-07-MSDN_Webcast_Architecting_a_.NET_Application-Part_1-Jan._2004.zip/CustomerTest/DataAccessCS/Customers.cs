using System;

using System.Data;
using DataLayerCS;
using WebCommonCS;

namespace DataAccessCS
{
	/// <summary>
	/// Summary description for Customers.
	/// </summary>
	public class Customers
	{
		public Customers()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public DataSet GetAllCustomers()
		{
			string strSQL;

			strSQL = "SELECT CustomerID, CompanyName FROM Customers";

			return DAL.GetDataSet(strSQL, WebAppConfig.ConnectString);
		}

		public DataSet GetCustomerByID(string CustID)
		{
			string strSQL;

			strSQL ="SELECT * FROM Customers ";
			strSQL += " WHERE CustomerID = {0}";

			strSQL = String.Format(strSQL, DAL.QuoteString(CustID));

			return DAL.GetDataSet(strSQL, WebAppConfig.ConnectString);
		}

		public void Update(string CustID, string CompanyName, 
			string ContactName, string ContactTitle)
		{
			string strSQL;

			strSQL = "UPDATE Customers SET ";
			strSQL += "CompanyName = {0},  ";
			strSQL += "ContactName = {1}, ";
			strSQL += "ContactTitle = {2} ";
			strSQL += " WHERE CustomerID = {3} ";

			try
			{
				// Validate Business Rules
				Validate(CustID, CompanyName, ContactName, ContactTitle);

				strSQL = String.Format(strSQL, DAL.QuoteString(CompanyName), 
					DAL.QuoteString(ContactName),
					DAL.QuoteString(ContactTitle),
					DAL.QuoteString(CustID));

				DAL.ExecuteSQL(strSQL, WebAppConfig.ConnectString);
			}
			catch
			{
				throw;
			}
		}

		public void Validate(string CustID, string CompanyName, 
			string ContactName, string ContactTitle)
		{
			string strMsg = String.Empty;

			if (CustID.Trim().Length == 0)
				strMsg += "Customer ID must be filled in";
      
			if (CompanyName.Trim().Length == 0)
				strMsg += "Company Name must be filled in";

			if (strMsg.Length > 0)
				throw new ApplicationException(strMsg);
		}
	}
}
