Imports DataLayer

<Serializable()> Public Class Customers
   Public Function GetAllCustomers() As DataSet
      Dim strSQL As String

      strSQL = "SELECT CustomerID, CompanyName FROM Customers"

      Return DAL.GetDataSet(strSQL, WebCommon.WebAppConfig.ConnectString)
   End Function

   Public Function GetCustomerByID(ByVal CustID As String) As DataSet
      Dim strSQL As String

      strSQL = "SELECT * FROM Customers "
      strSQL &= " WHERE CustomerID = {0}"

      strSQL = String.Format(strSQL, DAL.QuoteString(CustID))

      Return DAL.GetDataSet(strSQL, WebCommon.WebAppConfig.ConnectString)
   End Function

   Public Sub Update(ByVal CustID As String, _
     ByVal CompanyName As String, _
     ByVal ContactName As String, _
     ByVal ContactTitle As String)
      Dim strSQL As String

      strSQL = "UPDATE Customers SET "
      strSQL &= "CompanyName = {0},  "
      strSQL &= "ContactName = {1}, "
      strSQL &= "ContactTitle = {2} "
      strSQL &= " WHERE CustomerID = {3} "

      Try
         ' Validate Business Rules
         Validate(CustID, CompanyName, ContactName, ContactTitle)

         strSQL = String.Format(strSQL, _
           DAL.QuoteString(CompanyName), _
           DAL.QuoteString(ContactName), _
           DAL.QuoteString(ContactTitle), _
           DAL.QuoteString(CustID))

         DAL.ExecuteSQL(strSQL, WebCommon.WebAppConfig.ConnectString)

      Catch
         Throw

      End Try
   End Sub

   Public Sub Validate(ByVal CustID As String, _
     ByVal CompanyName As String, _
     ByVal ContactName As String, _
     ByVal ContactTitle As String)
      Dim strMsg As String = String.Empty

      If CustID.Trim().Length = 0 Then
         strMsg &= "Customer ID must be filled in"
      End If

      If CompanyName.Trim().Length = 0 Then
         strMsg &= "Company Name must be filled in"
      End If

      If strMsg.Length > 0 Then
         Throw New ApplicationException(strMsg)
      End If
   End Sub
End Class
