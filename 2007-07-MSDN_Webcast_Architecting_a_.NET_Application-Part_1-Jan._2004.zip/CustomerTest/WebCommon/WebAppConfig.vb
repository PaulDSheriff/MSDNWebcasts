Imports System.Configuration

Public Class WebAppConfig
   Public Shared ReadOnly Property ConnectString() As String
      Get
         Return ConfigurationSettings.AppSettings("ConnectString")
      End Get
   End Property
End Class
