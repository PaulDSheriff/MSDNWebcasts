using System;

using System.Data;
using System.Data.SqlClient;

namespace DataLayerCS
{
	/// <summary>
	/// Summary description for DAL.
	/// </summary>
	public class DAL
	{
		public DAL()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static IDataReader GetDataReader(string SQL, string ConnectString)
		{
			SqlCommand cmd = new SqlCommand();

			try
			{
				cmd.CommandText = SQL;
				cmd.Connection = new SqlConnection(ConnectString);
				cmd.Connection.Open();

				return cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
			}
			catch (Exception ex)
			{
				if (cmd.Connection != null)
				{
					if (cmd.Connection.State != ConnectionState.Closed)
					{
						cmd.Connection.Close();
					}
				}
				throw ex;
			}
		}

		public static DataSet GetDataSet(string SQL, string ConnectString)
		{
			DataSet ds = new DataSet();
			SqlDataAdapter da;

			try
			{
				da = new SqlDataAdapter(SQL, ConnectString);
				da.Fill(ds);

				return ds;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public static int ExecuteSQL(string SQL, string ConnectString)
		{
			SqlCommand cmd = new SqlCommand();

			try
			{
				cmd.CommandText = SQL;
				cmd.Connection = new SqlConnection(ConnectString);
				cmd.Connection.Open();

				return cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				if (cmd.Connection != null)
				{
					if (cmd.Connection.State != ConnectionState.Closed)
					{
						cmd.Connection.Close();
					}
				}
			}
		}

		public static object ExecuteScalar(string SQL, string ConnectString)
		{
			SqlCommand cmd = new SqlCommand();

			try
			{
				cmd.CommandText = SQL;
				cmd.Connection = new SqlConnection(ConnectString);
				cmd.Connection.Open();

				return cmd.ExecuteScalar();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				if (cmd.Connection != null)
				{
					if (cmd.Connection.State != ConnectionState.Closed)
					{
						cmd.Connection.Close();
					}
				}
			}
		}

		public static string QuoteString(string value)
		{
			return string.Format("'{0}'", value.Replace("'", "''"));
		}
	}
}
