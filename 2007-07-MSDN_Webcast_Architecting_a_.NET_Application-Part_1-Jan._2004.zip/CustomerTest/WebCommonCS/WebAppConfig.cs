using System;
using System.Configuration;

namespace WebCommonCS
{
	/// <summary>
	/// Summary description for WebAppConfig.
	/// </summary>
	public class WebAppConfig
	{
		public WebAppConfig()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static string ConnectString
		{
			get { return ConfigurationSettings.AppSettings["ConnectString"]; }
		}

	}
}
