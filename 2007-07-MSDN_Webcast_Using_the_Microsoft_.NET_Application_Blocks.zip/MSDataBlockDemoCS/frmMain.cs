using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace MSDataBlockDemoCS
{
	/// <summary>
	/// Summary description for frmMain.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Button btnTrans;
		internal System.Windows.Forms.Button btnSP;
		internal System.Windows.Forms.Button btnTSQL;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnTrans = new System.Windows.Forms.Button();
			this.btnSP = new System.Windows.Forms.Button();
			this.btnTSQL = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnTrans
			// 
			this.btnTrans.Location = new System.Drawing.Point(280, 8);
			this.btnTrans.Name = "btnTrans";
			this.btnTrans.Size = new System.Drawing.Size(136, 56);
			this.btnTrans.TabIndex = 6;
			this.btnTrans.Text = "Transactions";
			this.btnTrans.Click += new System.EventHandler(this.btnTrans_Click);
			// 
			// btnSP
			// 
			this.btnSP.Location = new System.Drawing.Point(144, 8);
			this.btnSP.Name = "btnSP";
			this.btnSP.Size = new System.Drawing.Size(128, 56);
			this.btnSP.TabIndex = 5;
			this.btnSP.Text = "Stored Procs";
			this.btnSP.Click += new System.EventHandler(this.btnSP_Click);
			// 
			// btnTSQL
			// 
			this.btnTSQL.Location = new System.Drawing.Point(8, 8);
			this.btnTSQL.Name = "btnTSQL";
			this.btnTSQL.Size = new System.Drawing.Size(128, 56);
			this.btnTSQL.TabIndex = 4;
			this.btnTSQL.Text = "T-SQL";
			this.btnTSQL.Click += new System.EventHandler(this.btnTSQL_Click);
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
			this.ClientSize = new System.Drawing.Size(424, 74);
			this.Controls.Add(this.btnTrans);
			this.Controls.Add(this.btnSP);
			this.Controls.Add(this.btnTSQL);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "frmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "MS Data Access Blocks";
			this.ResumeLayout(false);

		}
		#endregion

		private void btnTSQL_Click(object sender, System.EventArgs e)
		{
			frmTSQL frm = new frmTSQL();

			frm.Show();
		}

		private void btnSP_Click(object sender, System.EventArgs e)
		{
			frmStoredProc frm = new frmStoredProc();

			frm.Show();
		}

		private void btnTrans_Click(object sender, System.EventArgs e)
		{
			frmTrans frm = new frmTrans();

			frm.Show();
		}
	}
}
