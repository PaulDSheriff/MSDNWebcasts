using System;

namespace MSDataBlockDemoCS
{
	/// <summary>
	/// Summary description for SQLExInfo.
	/// </summary>
	public class SQLExInfo
	{
		public SQLExInfo()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static string GetSQLExceptionInfo(Exception ex)
		{
			string strMsg = String.Empty;

			return strMsg;
		}
	}
}
