using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace MSDataBlockDemoCS
{
	/// <summary>
	/// Summary description for frmTrans.
	/// </summary>
	public class frmTrans : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Button btnSqlTrans;
		internal System.Windows.Forms.Button btnTransSql;
		internal System.Windows.Forms.Button btnADOTrans;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmTrans()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnSqlTrans = new System.Windows.Forms.Button();
			this.btnTransSql = new System.Windows.Forms.Button();
			this.btnADOTrans = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnSqlTrans
			// 
			this.btnSqlTrans.Location = new System.Drawing.Point(328, 8);
			this.btnSqlTrans.Name = "btnSqlTrans";
			this.btnSqlTrans.Size = new System.Drawing.Size(144, 64);
			this.btnSqlTrans.TabIndex = 8;
			this.btnSqlTrans.Text = "Transaction using SqlTrans";
			this.btnSqlTrans.Click += new System.EventHandler(this.btnSqlTrans_Click);
			// 
			// btnTransSql
			// 
			this.btnTransSql.Location = new System.Drawing.Point(168, 8);
			this.btnTransSql.Name = "btnTransSql";
			this.btnTransSql.Size = new System.Drawing.Size(144, 64);
			this.btnTransSql.TabIndex = 7;
			this.btnTransSql.Text = "Transaction using SqlHelper";
			this.btnTransSql.Click += new System.EventHandler(this.btnTransSql_Click);
			// 
			// btnADOTrans
			// 
			this.btnADOTrans.Location = new System.Drawing.Point(8, 8);
			this.btnADOTrans.Name = "btnADOTrans";
			this.btnADOTrans.Size = new System.Drawing.Size(144, 64);
			this.btnADOTrans.TabIndex = 6;
			this.btnADOTrans.Text = "Transaction using ADO.NET";
			this.btnADOTrans.Click += new System.EventHandler(this.btnADOTrans_Click);
			// 
			// frmTrans
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
			this.ClientSize = new System.Drawing.Size(480, 74);
			this.Controls.Add(this.btnSqlTrans);
			this.Controls.Add(this.btnTransSql);
			this.Controls.Add(this.btnADOTrans);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "frmTrans";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Transaction Example";
			this.ResumeLayout(false);

		}
		#endregion

		private void btnADOTrans_Click(object sender, System.EventArgs e)
		{
			ADONetTrans();
		}

		private void ADONetTrans()
		{
			SqlCommand cmd = null;
			SqlTransaction tr = null;
			string strSQL;
			int intRows;

			try
			{
				// Create a new Command Object
				cmd = new SqlCommand();
				// Create a new Connection Object
				cmd.Connection = new 
					SqlConnection(AppConfig.ConnectString);
				// Open the Connection
				cmd.Connection.Open();

				// Start Transaction
				tr = cmd.Connection.BeginTransaction();
				// Put Transaction Object into Command Object
				cmd.Transaction = tr;

				strSQL = "UPDATE Products ";
				strSQL += " SET ProductName = 'Chai 2' ";
				strSQL += " WHERE ProductID = 1";

				// Fill in Command Object
				cmd.CommandText = strSQL;
				cmd.CommandType = CommandType.Text;
				// Execute the Query
				intRows = cmd.ExecuteNonQuery();

				strSQL = "UPDATE Categories ";
				strSQL += " SET CategoryName = 'Beverages 2' ";
				strSQL += " WHERE CategoryID = 1";

				// Fill in Command Object
				cmd.CommandText = strSQL;
				cmd.CommandType = CommandType.Text;
				// Execute the Query
				intRows = cmd.ExecuteNonQuery();

				// Commit the Transaction
				tr.Commit();

				MessageBox.Show("Transaction Successful");
			}
			catch (SqlException ex)
			{
				// Rollback the Transaction
				tr.Rollback();

				MessageBox.Show("Transaction Aborted");
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				// Rollback the Transaction
				tr.Rollback();

				MessageBox.Show("Transaction Aborted: " + ex.Message);
			}

			finally
			{
				if (cmd.Connection.State != ConnectionState.Closed)
				{
					cmd.Connection.Close();
					cmd.Connection.Dispose();
				}
			}
		}

		private void btnTransSql_Click(object sender, System.EventArgs e)
		{
			SqlHelperTrans();
		}

		private void SqlHelperTrans()
		{
			SqlConnection cnn = null;
			SqlTransaction tr = null;
			string strSQL;
			int intRows;

			try
			{
				// Create Connect Object
				cnn = new SqlConnection(AppConfig.ConnectString);
				// Open the Connection
				cnn.Open();

				// Start Transaction
				tr = cnn.BeginTransaction();

				strSQL = "UPDATE Products ";
				strSQL += " SET ProductName = 'Chai 2' ";
				strSQL += " WHERE ProductID = 1";
				// Execute the SQL
				intRows = SqlHelper.ExecuteNonQuery(tr, 
					CommandType.Text, strSQL);

				strSQL = "UPDATE Categories ";
				strSQL += " SET CategoryName = 'Beverages 2' ";
				strSQL += " WHERE CategoryID = 1";
				// Execute the SQL
				intRows = SqlHelper.ExecuteNonQuery(tr, 
					CommandType.Text, strSQL);

				// Commit the Transaction
				tr.Commit();
				// Close the Connection
				cnn.Close();

				MessageBox.Show("Transaction Successful");
			}
			catch (SqlException ex)
			{
				// Rollback the Transaction
				tr.Rollback();

				MessageBox.Show("Transaction Aborted");
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				// Rollback the Transaction
				tr.Rollback();

				MessageBox.Show("Transaction Aborted: " + ex.Message);
			}

			finally
			{
				if (cnn.State != ConnectionState.Closed)
				{
					cnn.Close();
					cnn.Dispose();
				}
			}
		}

		private void btnSqlTrans_Click(object sender, System.EventArgs e)
		{
			SqlTrans();
		}

		private void SqlTrans()
		{
			string[] astrSQL = new string[2];
			string strSQL;
         
			strSQL = "UPDATE Products ";
			strSQL += " SET ProductName = 'Chai 2' ";
			strSQL += " WHERE ProductID = 1";
			astrSQL[0] = strSQL;

			strSQL = "UPDATE Categories ";
			strSQL += " SET CategoryName = 'Beverages 2' ";
			strSQL += " WHERE CategoryID = 1";
			astrSQL[1] = strSQL;

			try
			{
				// Pass array of SQL to ExecuteTrans
				SQLTransHelper.ExecuteTrans( 
					AppConfig.ConnectString, astrSQL);

				MessageBox.Show("Transaction Successful");
			}
			catch (Exception ex)
			{
				MessageBox.Show("Transaction Aborted: " + ex.Message);
			}
		}
	}
}
