using System;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace MSDataBlockDemoCS
{
	/// <summary>
	/// Summary description for SQLTransHelper.
	/// </summary>
	public class SQLTransHelper
	{
		public SQLTransHelper()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static void ExecuteTrans(string ConnectString, params string[] SQLStatements)
		{
			SqlConnection cnn = null;
			SqlTransaction tr = null;

			try
			{
				// Create Connect Object
				cnn = new SqlConnection(ConnectString);
				// Open the Connection
				cnn.Open();

				// Start Transaction
				tr = cnn.BeginTransaction();

				foreach(string strSQL in SQLStatements)
				{
					// Execute the SQL
					SqlHelper.ExecuteNonQuery(tr, 
						CommandType.Text, strSQL);
				}

				// Commit the Transaction
				tr.Commit();
			}
			catch (Exception ex)
			{
				// Rollback the Transaction
				tr.Rollback();

					// Throw an exception back to caller
					throw ex;
					}
			finally
			{
				if (cnn.State != ConnectionState.Closed)
				{
					cnn.Close();
					cnn.Dispose();
				}

			}
		}
	}
}
