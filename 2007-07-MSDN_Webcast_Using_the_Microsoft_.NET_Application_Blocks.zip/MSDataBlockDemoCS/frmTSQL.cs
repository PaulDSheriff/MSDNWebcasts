using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using System.Xml;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace MSDataBlockDemoCS
{
	/// <summary>
	/// Summary description for frmTSQL.
	/// </summary>
	public class frmTSQL : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.ListBox lstProducts;
		internal System.Windows.Forms.TextBox txtXML;
		internal System.Windows.Forms.Button btnXMLADO;
		internal System.Windows.Forms.Button btnXMLSqlHelper;
		internal System.Windows.Forms.Button btnADOScalar;
		internal System.Windows.Forms.Button btnSqlHelperScalar;
		internal System.Windows.Forms.Button btnADONetDR;
		internal System.Windows.Forms.Button btnDRSqlHelper;
		internal System.Windows.Forms.Button btnUpdate;
		internal System.Windows.Forms.Button btnUpdateADO;
		internal System.Windows.Forms.Button btnADO;
		internal System.Windows.Forms.Button btnRetrieve;
		internal System.Windows.Forms.DataGrid grdProducts;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmTSQL()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lstProducts = new System.Windows.Forms.ListBox();
			this.txtXML = new System.Windows.Forms.TextBox();
			this.btnXMLADO = new System.Windows.Forms.Button();
			this.btnXMLSqlHelper = new System.Windows.Forms.Button();
			this.btnADOScalar = new System.Windows.Forms.Button();
			this.btnSqlHelperScalar = new System.Windows.Forms.Button();
			this.btnADONetDR = new System.Windows.Forms.Button();
			this.btnDRSqlHelper = new System.Windows.Forms.Button();
			this.btnUpdate = new System.Windows.Forms.Button();
			this.btnUpdateADO = new System.Windows.Forms.Button();
			this.btnADO = new System.Windows.Forms.Button();
			this.btnRetrieve = new System.Windows.Forms.Button();
			this.grdProducts = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.grdProducts)).BeginInit();
			this.SuspendLayout();
			// 
			// lstProducts
			// 
			this.lstProducts.ItemHeight = 20;
			this.lstProducts.Location = new System.Drawing.Point(328, 192);
			this.lstProducts.Name = "lstProducts";
			this.lstProducts.Size = new System.Drawing.Size(376, 144);
			this.lstProducts.TabIndex = 25;
			// 
			// txtXML
			// 
			this.txtXML.Location = new System.Drawing.Point(328, 352);
			this.txtXML.Multiline = true;
			this.txtXML.Name = "txtXML";
			this.txtXML.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtXML.Size = new System.Drawing.Size(376, 184);
			this.txtXML.TabIndex = 24;
			this.txtXML.Text = "";
			// 
			// btnXMLADO
			// 
			this.btnXMLADO.Location = new System.Drawing.Point(16, 472);
			this.btnXMLADO.Name = "btnXMLADO";
			this.btnXMLADO.Size = new System.Drawing.Size(144, 64);
			this.btnXMLADO.TabIndex = 23;
			this.btnXMLADO.Text = "XMLReader using ADO.NET";
			this.btnXMLADO.Click += new System.EventHandler(this.btnXMLADO_Click);
			// 
			// btnXMLSqlHelper
			// 
			this.btnXMLSqlHelper.Location = new System.Drawing.Point(168, 472);
			this.btnXMLSqlHelper.Name = "btnXMLSqlHelper";
			this.btnXMLSqlHelper.Size = new System.Drawing.Size(144, 64);
			this.btnXMLSqlHelper.TabIndex = 22;
			this.btnXMLSqlHelper.Text = "XMLReader using SqlHelper";
			this.btnXMLSqlHelper.Click += new System.EventHandler(this.btnXMLSqlHelper_Click);
			// 
			// btnADOScalar
			// 
			this.btnADOScalar.Location = new System.Drawing.Point(16, 400);
			this.btnADOScalar.Name = "btnADOScalar";
			this.btnADOScalar.Size = new System.Drawing.Size(144, 64);
			this.btnADOScalar.TabIndex = 21;
			this.btnADOScalar.Text = "Scalar using ADO.NET";
			this.btnADOScalar.Click += new System.EventHandler(this.btnADOScalar_Click);
			// 
			// btnSqlHelperScalar
			// 
			this.btnSqlHelperScalar.Location = new System.Drawing.Point(168, 400);
			this.btnSqlHelperScalar.Name = "btnSqlHelperScalar";
			this.btnSqlHelperScalar.Size = new System.Drawing.Size(144, 64);
			this.btnSqlHelperScalar.TabIndex = 20;
			this.btnSqlHelperScalar.Text = "Scalar using SqlHelper";
			this.btnSqlHelperScalar.Click += new System.EventHandler(this.btnSqlHelperScalar_Click);
			// 
			// btnADONetDR
			// 
			this.btnADONetDR.Location = new System.Drawing.Point(16, 328);
			this.btnADONetDR.Name = "btnADONetDR";
			this.btnADONetDR.Size = new System.Drawing.Size(144, 64);
			this.btnADONetDR.TabIndex = 19;
			this.btnADONetDR.Text = "DataReader using ADO.NET";
			this.btnADONetDR.Click += new System.EventHandler(this.btnADONetDR_Click);
			// 
			// btnDRSqlHelper
			// 
			this.btnDRSqlHelper.Location = new System.Drawing.Point(168, 328);
			this.btnDRSqlHelper.Name = "btnDRSqlHelper";
			this.btnDRSqlHelper.Size = new System.Drawing.Size(144, 64);
			this.btnDRSqlHelper.TabIndex = 18;
			this.btnDRSqlHelper.Text = "DataReader using SqlHelper";
			this.btnDRSqlHelper.Click += new System.EventHandler(this.btnDRSqlHelper_Click);
			// 
			// btnUpdate
			// 
			this.btnUpdate.Location = new System.Drawing.Point(168, 256);
			this.btnUpdate.Name = "btnUpdate";
			this.btnUpdate.Size = new System.Drawing.Size(144, 64);
			this.btnUpdate.TabIndex = 17;
			this.btnUpdate.Text = "Update Data using SqlHelper";
			this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
			// 
			// btnUpdateADO
			// 
			this.btnUpdateADO.Location = new System.Drawing.Point(16, 256);
			this.btnUpdateADO.Name = "btnUpdateADO";
			this.btnUpdateADO.Size = new System.Drawing.Size(144, 64);
			this.btnUpdateADO.TabIndex = 16;
			this.btnUpdateADO.Text = "Update Data using ADO.NET";
			this.btnUpdateADO.Click += new System.EventHandler(this.btnUpdateADO_Click);
			// 
			// btnADO
			// 
			this.btnADO.Location = new System.Drawing.Point(16, 184);
			this.btnADO.Name = "btnADO";
			this.btnADO.Size = new System.Drawing.Size(144, 64);
			this.btnADO.TabIndex = 15;
			this.btnADO.Text = "DataSet using ADO.NET";
			this.btnADO.Click += new System.EventHandler(this.btnADO_Click);
			// 
			// btnRetrieve
			// 
			this.btnRetrieve.Location = new System.Drawing.Point(168, 184);
			this.btnRetrieve.Name = "btnRetrieve";
			this.btnRetrieve.Size = new System.Drawing.Size(144, 64);
			this.btnRetrieve.TabIndex = 14;
			this.btnRetrieve.Text = "DataSet using SqlHelper";
			this.btnRetrieve.Click += new System.EventHandler(this.btnRetrieve_Click);
			// 
			// grdProducts
			// 
			this.grdProducts.DataMember = "";
			this.grdProducts.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.grdProducts.Location = new System.Drawing.Point(8, 8);
			this.grdProducts.Name = "grdProducts";
			this.grdProducts.Size = new System.Drawing.Size(696, 168);
			this.grdProducts.TabIndex = 13;
			// 
			// frmTSQL
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
			this.ClientSize = new System.Drawing.Size(712, 538);
			this.Controls.Add(this.lstProducts);
			this.Controls.Add(this.txtXML);
			this.Controls.Add(this.btnXMLADO);
			this.Controls.Add(this.btnXMLSqlHelper);
			this.Controls.Add(this.btnADOScalar);
			this.Controls.Add(this.btnSqlHelperScalar);
			this.Controls.Add(this.btnADONetDR);
			this.Controls.Add(this.btnDRSqlHelper);
			this.Controls.Add(this.btnUpdate);
			this.Controls.Add(this.btnUpdateADO);
			this.Controls.Add(this.btnADO);
			this.Controls.Add(this.btnRetrieve);
			this.Controls.Add(this.grdProducts);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "frmTSQL";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "T-SQL Samples";
			((System.ComponentModel.ISupportInitialize)(this.grdProducts)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void btnADO_Click(object sender, System.EventArgs e)
		{
			ADONetRetrieve();
		}

		private void ADONetRetrieve()
		{
			DataSet ds = new DataSet();
			SqlDataAdapter da;
			string strSQL;

			strSQL = "SELECT * FROM Products";

			try
			{
				// Create a DataAdapter Object
				da = new SqlDataAdapter(strSQL, 
					AppConfig.ConnectString);
				// Fill the DataSet
				da.Fill(ds);

				grdProducts.DataSource = ds.Tables[0];
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnUpdateADO_Click(object sender, System.EventArgs e)
		{
			ADONetUpdate();
		}

		private void ADONetUpdate()
		{
			SqlCommand cmd;
			string strSQL;
			int intRows;

			strSQL = "UPDATE Products ";
			strSQL += " SET ProductName = 'Chai 2' ";
			strSQL += " WHERE ProductID = 1";

			try
			{
				// Create a new Command Object
				cmd = new SqlCommand(strSQL);
				// Create a new Connection Object
				cmd.Connection = new
					SqlConnection(AppConfig.ConnectString);
				// Open the Connection
				cmd.Connection.Open();
				// Set the CommandType to Text
				cmd.CommandType = CommandType.Text;
				// Execute the Query
				intRows = cmd.ExecuteNonQuery();
				// Close the Connection
				cmd.Connection.Close();

				MessageBox.Show("Rows Affected: " + intRows.ToString());
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnADONetDR_Click(object sender, System.EventArgs e)
		{
			ADONetDataReader();
		}

		private void ADONetDataReader()
		{
			SqlDataReader dr;
			SqlCommand cmd;
			string strSQL;

			strSQL = "SELECT ProductName FROM Products ";

			try
			{
				// Create a new Command Object
				cmd = new SqlCommand(strSQL);
				// Create a new Connection Object
				cmd.Connection = new 
					SqlConnection(AppConfig.ConnectString);
				// Open the Connection
				cmd.Connection.Open();
				// Set the CommandType to Text
				cmd.CommandType = CommandType.Text;
				// Get the DataReader
				dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

				lstProducts.Items.Clear();
				while (dr.Read())
				{
					lstProducts.Items.Add(dr["ProductName"]);
				}
				// Close the DataReader & Connection
				dr.Close();
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnADOScalar_Click(object sender, System.EventArgs e)
		{
			ADONetScalar();
		}

		private void ADONetScalar()
		{
			SqlCommand cmd;
			string strSQL;
			int intRows;

			strSQL = "SELECT Count(*) FROM Products ";

			try
			{
				// Create a new Command Object
				cmd = new SqlCommand(strSQL);
				// Create a new Connection Object
				cmd.Connection = new 
					SqlConnection(AppConfig.ConnectString);
				// Open the Connection
				cmd.Connection.Open();
				// Set the CommandType to Text
				cmd.CommandType = CommandType.Text;
				// Execute the Scalar Function
				intRows = Convert.ToInt32(cmd.ExecuteScalar());

				MessageBox.Show("Total Products=" + intRows.ToString());
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnXMLADO_Click(object sender, System.EventArgs e)
		{
			ADONetXMLReader();
		}

		private void ADONetXMLReader()
		{
			SqlCommand cmd;
			SqlConnection cnn;
			XmlReader xr;
			string strSQL;

			strSQL = "SELECT CategoryID, CategoryName FROM Categories FOR XML AUTO";

			try
			{
				cnn = new SqlConnection(AppConfig.ConnectString);
				cnn.Open();
				cmd = new SqlCommand(strSQL, cnn);

				xr = cmd.ExecuteXmlReader();

				txtXML.Text = "";
				while (xr.Read())
				{
					txtXML.Text += xr.ReadOuterXml() + Environment.NewLine;
				}
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnRetrieve_Click(object sender, System.EventArgs e)
		{
			SqlHelperRetrieve();
		}

		private void SqlHelperRetrieve()
		{
			DataSet ds;
			string strSQL;

			strSQL = "SELECT * FROM Products";

			try
			{
				// Call the SqlHelper Class to create the DataSet
				ds = SqlHelper.ExecuteDataset(AppConfig.ConnectString, 
					CommandType.Text, strSQL);

				grdProducts.DataSource = ds.Tables[0];
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnUpdate_Click(object sender, System.EventArgs e)
		{
			SqlHelperUpdate();
		}

		private void SqlHelperUpdate()
		{
			string strSQL;
			int intRows;

			strSQL = "UPDATE Products ";
			strSQL += " SET ProductName = 'Chai 2' ";
			strSQL += " WHERE ProductID = 1";

			try
			{
				// Execute the Query and Return Result
				intRows = SqlHelper.ExecuteNonQuery(AppConfig.ConnectString, 
					CommandType.Text, strSQL);

				MessageBox.Show("Rows Affected: " + intRows.ToString());
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnDRSqlHelper_Click(object sender, System.EventArgs e)
		{
			SqlHelperDataReader();
		}

		private void SqlHelperDataReader()
		{
			SqlDataReader dr;
			string strSQL;

			strSQL = "SELECT ProductName FROM Products ";

			try
			{
				dr = SqlHelper.ExecuteReader(AppConfig.ConnectString, 
					CommandType.Text, strSQL);

				lstProducts.Items.Clear();
				while (dr.Read())
				{
					lstProducts.Items.Add(dr["ProductName"]);
				}
				// Closes the DataReader & Connection
				dr.Close();
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnSqlHelperScalar_Click(object sender, System.EventArgs e)
		{
			SqlHelperScalar();
		}

		private void SqlHelperScalar()
		{
			string strSQL;
			int intRows;

			strSQL = "SELECT Count(*) FROM Products ";

			try
			{
				// Execute the Scalar function
				intRows = Convert.ToInt32( 
					SqlHelper.ExecuteScalar(AppConfig.ConnectString, 
					CommandType.Text, strSQL));

				MessageBox.Show("Total Products=" + intRows.ToString());
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnXMLSqlHelper_Click(object sender, System.EventArgs e)
		{
			SqlHelperXML();
		}

		private void SqlHelperXML()
		{
			string strSQL;
			XmlReader xr;
			SqlConnection cnn;

			strSQL = "SELECT CategoryID, CategoryName FROM Categories FOR XML AUTO";

			try
			{
				cnn = new SqlConnection(AppConfig.ConnectString);
				cnn.Open();
				xr = SqlHelper.ExecuteXmlReader(cnn, CommandType.Text, strSQL);

				txtXML.Text = "";
				while (xr.Read())
				{
					txtXML.Text += xr.ReadOuterXml() + Environment.NewLine;
				}
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
	}  // End of Class
}  // End of Namespace
