using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace MSDataBlockDemoCS
{
	/// <summary>
	/// Summary description for frmStoredProc.
	/// </summary>
	public class frmStoredProc : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Button btnOutput;
		internal System.Windows.Forms.Button btnSqlHelperParams;
		internal System.Windows.Forms.Button btnADOParams;
		internal System.Windows.Forms.Button btnUpdate;
		internal System.Windows.Forms.Button btnUpdateADO;
		internal System.Windows.Forms.Button btnADO;
		internal System.Windows.Forms.Button btnRetrieve;
		internal System.Windows.Forms.DataGrid grdProducts;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmStoredProc()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnOutput = new System.Windows.Forms.Button();
			this.btnSqlHelperParams = new System.Windows.Forms.Button();
			this.btnADOParams = new System.Windows.Forms.Button();
			this.btnUpdate = new System.Windows.Forms.Button();
			this.btnUpdateADO = new System.Windows.Forms.Button();
			this.btnADO = new System.Windows.Forms.Button();
			this.btnRetrieve = new System.Windows.Forms.Button();
			this.grdProducts = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.grdProducts)).BeginInit();
			this.SuspendLayout();
			// 
			// btnOutput
			// 
			this.btnOutput.Location = new System.Drawing.Point(320, 328);
			this.btnOutput.Name = "btnOutput";
			this.btnOutput.Size = new System.Drawing.Size(144, 64);
			this.btnOutput.TabIndex = 28;
			this.btnOutput.Text = "OUTPUT Params";
			this.btnOutput.Click += new System.EventHandler(this.btnOutput_Click);
			// 
			// btnSqlHelperParams
			// 
			this.btnSqlHelperParams.Location = new System.Drawing.Point(168, 328);
			this.btnSqlHelperParams.Name = "btnSqlHelperParams";
			this.btnSqlHelperParams.Size = new System.Drawing.Size(144, 64);
			this.btnSqlHelperParams.TabIndex = 27;
			this.btnSqlHelperParams.Text = "Update using SqlHelper / Params";
			this.btnSqlHelperParams.Click += new System.EventHandler(this.btnSqlHelperParams_Click);
			// 
			// btnADOParams
			// 
			this.btnADOParams.Location = new System.Drawing.Point(16, 328);
			this.btnADOParams.Name = "btnADOParams";
			this.btnADOParams.Size = new System.Drawing.Size(144, 64);
			this.btnADOParams.TabIndex = 26;
			this.btnADOParams.Text = "Update using ADO.NET / Params";
			this.btnADOParams.Click += new System.EventHandler(this.btnADOParams_Click);
			// 
			// btnUpdate
			// 
			this.btnUpdate.Location = new System.Drawing.Point(168, 256);
			this.btnUpdate.Name = "btnUpdate";
			this.btnUpdate.Size = new System.Drawing.Size(144, 64);
			this.btnUpdate.TabIndex = 25;
			this.btnUpdate.Text = "Update Data using SqlHelper";
			this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
			// 
			// btnUpdateADO
			// 
			this.btnUpdateADO.Location = new System.Drawing.Point(16, 256);
			this.btnUpdateADO.Name = "btnUpdateADO";
			this.btnUpdateADO.Size = new System.Drawing.Size(144, 64);
			this.btnUpdateADO.TabIndex = 24;
			this.btnUpdateADO.Text = "Update Data using ADO.NET";
			this.btnUpdateADO.Click += new System.EventHandler(this.btnUpdateADO_Click);
			// 
			// btnADO
			// 
			this.btnADO.Location = new System.Drawing.Point(16, 184);
			this.btnADO.Name = "btnADO";
			this.btnADO.Size = new System.Drawing.Size(144, 64);
			this.btnADO.TabIndex = 23;
			this.btnADO.Text = "DataSet using ADO.NET";
			this.btnADO.Click += new System.EventHandler(this.btnADO_Click);
			// 
			// btnRetrieve
			// 
			this.btnRetrieve.Location = new System.Drawing.Point(168, 184);
			this.btnRetrieve.Name = "btnRetrieve";
			this.btnRetrieve.Size = new System.Drawing.Size(144, 64);
			this.btnRetrieve.TabIndex = 22;
			this.btnRetrieve.Text = "DataSet using SqlHelper";
			this.btnRetrieve.Click += new System.EventHandler(this.btnRetrieve_Click);
			// 
			// grdProducts
			// 
			this.grdProducts.DataMember = "";
			this.grdProducts.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.grdProducts.Location = new System.Drawing.Point(8, 8);
			this.grdProducts.Name = "grdProducts";
			this.grdProducts.Size = new System.Drawing.Size(448, 168);
			this.grdProducts.TabIndex = 21;
			// 
			// frmStoredProc
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
			this.ClientSize = new System.Drawing.Size(472, 402);
			this.Controls.Add(this.btnOutput);
			this.Controls.Add(this.btnSqlHelperParams);
			this.Controls.Add(this.btnADOParams);
			this.Controls.Add(this.btnUpdate);
			this.Controls.Add(this.btnUpdateADO);
			this.Controls.Add(this.btnADO);
			this.Controls.Add(this.btnRetrieve);
			this.Controls.Add(this.grdProducts);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "frmStoredProc";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Stored Procedure Examples";
			((System.ComponentModel.ISupportInitialize)(this.grdProducts)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void btnADO_Click(object sender, System.EventArgs e)
		{
			ADONETRetrieve();
		}

		private void ADONETRetrieve()
		{
			DataSet ds = new DataSet();
			SqlDataAdapter da = new SqlDataAdapter();

			try
			{
				// Create a DataAdapter Object
				da = new SqlDataAdapter("procProductsAll", AppConfig.ConnectString);

				// Fill the DataSet
				da.Fill(ds);

				// Fill the Grid
				grdProducts.DataSource = ds.Tables[0];
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnUpdateADO_Click(object sender, System.EventArgs e)
		{
			ADONETUpdate();
		}

		private void ADONETUpdate()
		{
			SqlCommand cmd;
			string strSQL;
			int intRows;

			strSQL = "procProductsUpdate 'Chai 2', 1";

			try
			{
				// Create a new Command Object
				cmd = new SqlCommand(strSQL);
				// Create a new Connection Object
				cmd.Connection = new SqlConnection(AppConfig.ConnectString);
				// Open the Connection
				cmd.Connection.Open();

				// Must use Text command type 
				// when not using parameters
				cmd.CommandType = CommandType.Text;

				// Execute the Query
				intRows = cmd.ExecuteNonQuery();
	
				// Close the Connection
				cmd.Connection.Close();

				MessageBox.Show("Rows Affected: " + intRows.ToString());
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnADOParams_Click(object sender, System.EventArgs e)
		{
			ADONETParms();
		}

		private void ADONETParms()
		{
			SqlCommand cmd;
			SqlParameter param;
			string strSQL;
			int intRows;

			strSQL = "procProductsUpdate";

			try
			{
				// Create a new Command Object
				cmd = new SqlCommand(strSQL);
				// Create a new Connection Object
				cmd.Connection = new
					SqlConnection(AppConfig.ConnectString);

				// Create the Parameters
				param = new SqlParameter( 
					"@ProductName", "Chai 2");
				cmd.Parameters.Add(param);

				param = new SqlParameter( 
					"@ProductID", 1);
					cmd.Parameters.Add(param);

				// Open the Connection
				cmd.Connection.Open();
				// Set CommandType to Stored procedure
				cmd.CommandType = CommandType.StoredProcedure;
				// Execute the Stored Procedure
				intRows = cmd.ExecuteNonQuery();
				// Close the Connection
				cmd.Connection.Close();

				MessageBox.Show("Rows Affected: " + intRows.ToString());

			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnRetrieve_Click(object sender, System.EventArgs e)
		{
			SqlHelperRetrieve();
		}

		private void SqlHelperRetrieve()
		{
			DataSet ds;

			try
			{
				// Call the SqlHelper Class to create the DataSet
				ds = SqlHelper.ExecuteDataset(AppConfig.ConnectString, 
					CommandType.StoredProcedure, "procProductsAll");

				grdProducts.DataSource = ds.Tables[0];

			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnUpdate_Click(object sender, System.EventArgs e)
		{
			SqlHelperUpdate();
		}

		private void SqlHelperUpdate()
		{
			int intRows;

			try
			{
				// Execute the Query
				intRows = SqlHelper.ExecuteNonQuery(AppConfig.ConnectString, 
					"procProductsUpdate", "Chai 2", 1);

				MessageBox.Show("Rows Affected: " + intRows.ToString());
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnSqlHelperParams_Click(object sender, System.EventArgs e)
		{
			SqlHelperParams();
		}

		private void SqlHelperParams()
		{
			SqlParameter[] aParams = new SqlParameter[1];
			int intRows;

			try
			{
				// Create the Parameters
				aParams[0] = new SqlParameter( 
					"@ProductName", "Chai 2");

				aParams[1] = new SqlParameter( 
					"@ProductID", 1);

				// Execute the Stored Procedure
				intRows = SqlHelper.ExecuteNonQuery( 
					AppConfig.ConnectString, CommandType.StoredProcedure, 
					"procProductsUpdate", aParams);

				MessageBox.Show("Rows Affected: " + intRows.ToString());
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnOutput_Click(object sender, System.EventArgs e)
		{
			OutputParams();
		}

		private void OutputParams()
		{
			SqlParameter[] aParams = new SqlParameter[1];
			int intRows;

			try
			{
				aParams[0] = new SqlParameter("@UserID", "Paul");
				aParams[1] = new SqlParameter("@NewGUID", "");
				aParams[1].SqlDbType = SqlDbType.UniqueIdentifier;
				aParams[1].Direction = ParameterDirection.Output;

				intRows = SqlHelper.ExecuteNonQuery(AppConfig.ConnectString, 
					CommandType.StoredProcedure, 
					"procTicketCreate", aParams);

				MessageBox.Show(aParams[1].Value.ToString());
			}
			catch (SqlException ex)
			{
				MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
	}
}
