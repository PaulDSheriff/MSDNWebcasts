Imports System.Collections.Specialized

Public Class emInfo
   Public Shared Function AdditionalInfo( _
    ByVal FormName As String, _
    ByVal ApplicationName As String) As _
     NameValueCollection
      Dim nvc As New NameValueCollection

      nvc.Add("FormName", FormName)
      nvc.Add("ApplicationName", ApplicationName)

      Return nvc
   End Function
End Class
