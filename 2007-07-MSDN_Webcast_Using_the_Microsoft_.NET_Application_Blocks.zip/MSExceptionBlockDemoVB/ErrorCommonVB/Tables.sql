CREATE TABLE ErrorLog
(
lError_id int IDENTITY (1, 1) NOT NULL PRIMARY KEY,
szUser_nm varchar(50) NULL, 
szForm_nm varchar(50) NULL, 
dtError_dt datetime NULL,
szAppl_nm varchar(50) NULL,
szError_tx varchar(2500) NULL
)
GO