Imports Microsoft.ApplicationBlocks.ExceptionManagement
Imports Microsoft.ApplicationBlocks.Data
Imports System.Collections.Specialized
Imports ErrorCommonVB

Public Class frmMain
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents btnCreate As System.Windows.Forms.Button
   Friend WithEvents btnNameValue As System.Windows.Forms.Button
   Friend WithEvents btnNameValue2 As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnCreate = New System.Windows.Forms.Button()
      Me.btnNameValue = New System.Windows.Forms.Button()
      Me.btnNameValue2 = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnCreate
      '
      Me.btnCreate.Location = New System.Drawing.Point(8, 8)
      Me.btnCreate.Name = "btnCreate"
      Me.btnCreate.Size = New System.Drawing.Size(136, 80)
      Me.btnCreate.TabIndex = 0
      Me.btnCreate.Text = "Create Exception"
      '
      'btnNameValue
      '
      Me.btnNameValue.Location = New System.Drawing.Point(152, 8)
      Me.btnNameValue.Name = "btnNameValue"
      Me.btnNameValue.Size = New System.Drawing.Size(136, 80)
      Me.btnNameValue.TabIndex = 1
      Me.btnNameValue.Text = "Exception With NameValue"
      '
      'btnNameValue2
      '
      Me.btnNameValue2.Location = New System.Drawing.Point(296, 8)
      Me.btnNameValue2.Name = "btnNameValue2"
      Me.btnNameValue2.Size = New System.Drawing.Size(136, 80)
      Me.btnNameValue2.TabIndex = 2
      Me.btnNameValue2.Text = "Exception With NameValue 2"
      '
      'frmMain
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(9, 22)
      Me.ClientSize = New System.Drawing.Size(440, 98)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnNameValue2, Me.btnNameValue, Me.btnCreate})
      Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.Name = "frmMain"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
      Me.Text = "Exception Management"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreate.Click
      Dim ds As New DataSet()
      Dim strSQL As String

      strSQL = "SELECT * FROM Prodcts"

      Try
         ds = SqlHelper.ExecuteDataset(AppConfig.ConnectString, _
            CommandType.Text, strSQL)

         ' Do something with the DataSet

      Catch exp As Exception
         ExceptionManager.Publish(exp)

         MessageBox.Show(exp.Message)
      End Try
   End Sub

   Private Sub btnNameValue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNameValue.Click
      Dim ds As New DataSet()
      Dim strSQL As String

      strSQL = "SELECT * FROM Prodcts"

      Try
         ds = SqlHelper.ExecuteDataset(AppConfig.ConnectString, _
            CommandType.Text, strSQL)

         ' Do something with the DataSet

      Catch exp As Exception
         Dim nvc As New NameValueCollection

         nvc.Add("FormName", "frmMain")
         nvc.Add("ApplicationName", "MSExceptionBlockDemoVB")

         ExceptionManager.Publish(exp, nvc)

         MessageBox.Show(exp.Message)
      End Try
   End Sub

   Private Sub btnNameValue2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNameValue2.Click
      Dim ds As New DataSet()
      Dim strSQL As String

      strSQL = "SELECT * FROM Prodcts"

      Try
         ds = SqlHelper.ExecuteDataset(AppConfig.ConnectString, _
            CommandType.Text, strSQL)

         ' Do something with the DataSet

      Catch exp As Exception
         ExceptionManager.Publish(exp, _
            EMInfo.AdditionalInfo( _
            "frmMain", "MSExceptionBlockDemoVB"))

         MessageBox.Show(exp.Message)
      End Try
   End Sub
End Class