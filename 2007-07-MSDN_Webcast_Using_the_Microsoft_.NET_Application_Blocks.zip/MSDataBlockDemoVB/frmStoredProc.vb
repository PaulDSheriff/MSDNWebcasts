Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data

Public Class frmStoredProc
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents btnUpdate As System.Windows.Forms.Button
   Friend WithEvents btnUpdateADO As System.Windows.Forms.Button
   Friend WithEvents btnADO As System.Windows.Forms.Button
   Friend WithEvents btnRetrieve As System.Windows.Forms.Button
   Friend WithEvents grdProducts As System.Windows.Forms.DataGrid
   Friend WithEvents btnSqlHelperParams As System.Windows.Forms.Button
   Friend WithEvents btnADOParams As System.Windows.Forms.Button
   Friend WithEvents btnOutput As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnUpdate = New System.Windows.Forms.Button
      Me.btnUpdateADO = New System.Windows.Forms.Button
      Me.btnADO = New System.Windows.Forms.Button
      Me.btnRetrieve = New System.Windows.Forms.Button
      Me.grdProducts = New System.Windows.Forms.DataGrid
      Me.btnSqlHelperParams = New System.Windows.Forms.Button
      Me.btnADOParams = New System.Windows.Forms.Button
      Me.btnOutput = New System.Windows.Forms.Button
      CType(Me.grdProducts, System.ComponentModel.ISupportInitialize).BeginInit()
      Me.SuspendLayout()
      '
      'btnUpdate
      '
      Me.btnUpdate.Location = New System.Drawing.Point(168, 256)
      Me.btnUpdate.Name = "btnUpdate"
      Me.btnUpdate.Size = New System.Drawing.Size(144, 64)
      Me.btnUpdate.TabIndex = 13
      Me.btnUpdate.Text = "Update Data using SqlHelper"
      '
      'btnUpdateADO
      '
      Me.btnUpdateADO.Location = New System.Drawing.Point(16, 256)
      Me.btnUpdateADO.Name = "btnUpdateADO"
      Me.btnUpdateADO.Size = New System.Drawing.Size(144, 64)
      Me.btnUpdateADO.TabIndex = 12
      Me.btnUpdateADO.Text = "Update Data using ADO.NET"
      '
      'btnADO
      '
      Me.btnADO.Location = New System.Drawing.Point(16, 184)
      Me.btnADO.Name = "btnADO"
      Me.btnADO.Size = New System.Drawing.Size(144, 64)
      Me.btnADO.TabIndex = 11
      Me.btnADO.Text = "DataSet using ADO.NET"
      '
      'btnRetrieve
      '
      Me.btnRetrieve.Location = New System.Drawing.Point(168, 184)
      Me.btnRetrieve.Name = "btnRetrieve"
      Me.btnRetrieve.Size = New System.Drawing.Size(144, 64)
      Me.btnRetrieve.TabIndex = 10
      Me.btnRetrieve.Text = "DataSet using SqlHelper"
      '
      'grdProducts
      '
      Me.grdProducts.DataMember = ""
      Me.grdProducts.HeaderForeColor = System.Drawing.SystemColors.ControlText
      Me.grdProducts.Location = New System.Drawing.Point(8, 8)
      Me.grdProducts.Name = "grdProducts"
      Me.grdProducts.Size = New System.Drawing.Size(456, 168)
      Me.grdProducts.TabIndex = 9
      '
      'btnSqlHelperParams
      '
      Me.btnSqlHelperParams.Location = New System.Drawing.Point(168, 328)
      Me.btnSqlHelperParams.Name = "btnSqlHelperParams"
      Me.btnSqlHelperParams.Size = New System.Drawing.Size(144, 64)
      Me.btnSqlHelperParams.TabIndex = 19
      Me.btnSqlHelperParams.Text = "Update using SqlHelper / Params"
      '
      'btnADOParams
      '
      Me.btnADOParams.Location = New System.Drawing.Point(16, 328)
      Me.btnADOParams.Name = "btnADOParams"
      Me.btnADOParams.Size = New System.Drawing.Size(144, 64)
      Me.btnADOParams.TabIndex = 18
      Me.btnADOParams.Text = "Update using ADO.NET / Params"
      '
      'btnOutput
      '
      Me.btnOutput.Location = New System.Drawing.Point(320, 328)
      Me.btnOutput.Name = "btnOutput"
      Me.btnOutput.Size = New System.Drawing.Size(144, 64)
      Me.btnOutput.TabIndex = 20
      Me.btnOutput.Text = "OUTPUT Params"
      '
      'frmStoredProc
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
      Me.ClientSize = New System.Drawing.Size(472, 402)
      Me.Controls.Add(Me.btnOutput)
      Me.Controls.Add(Me.btnSqlHelperParams)
      Me.Controls.Add(Me.btnADOParams)
      Me.Controls.Add(Me.btnUpdate)
      Me.Controls.Add(Me.btnUpdateADO)
      Me.Controls.Add(Me.btnADO)
      Me.Controls.Add(Me.btnRetrieve)
      Me.Controls.Add(Me.grdProducts)
      Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.Name = "frmStoredProc"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
      Me.Text = "Stored Procedure Examples"
      CType(Me.grdProducts, System.ComponentModel.ISupportInitialize).EndInit()
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnADO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnADO.Click
      ADONetRetrieve()
   End Sub

   Private Sub ADONetRetrieve()
      Dim ds As New DataSet()
      Dim da As SqlDataAdapter

      Try
         ' Create a DataAdapter Object
         da = New SqlDataAdapter( _
               "procProductsAll", AppConfig.ConnectString)
         ' Fill the Dataset
         da.Fill(ds)

         grdProducts.DataSource = ds.Tables(0)

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnRetrieve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetrieve.Click
      SqlHelperRetrieve()
   End Sub

   Private Sub SqlHelperRetrieve()
      Dim ds As DataSet

      Try
         ' Call the SqlHelper Class to create the DataSet
         ds = SqlHelper.ExecuteDataset(AppConfig.ConnectString, _
               CommandType.StoredProcedure, "procProductsAll")

         grdProducts.DataSource = ds.Tables(0)

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnUpdateADO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateADO.Click
      ADONetUpdate()
   End Sub

   Private Sub ADONetUpdate()
      Dim cmd As SqlCommand
      Dim strSQL As String
      Dim intRows As Integer

      strSQL = "procProductsUpdate 'Chai 2', 1"

      Try
         ' Create a new Command Object
         cmd = New SqlCommand(strSQL)
         ' Create a new Connection Object
         cmd.Connection = New _
               SqlConnection(AppConfig.ConnectString)
         ' Open the Connection
         cmd.Connection.Open()

         ' Must use Text command type 
         ' when not using parameters
         cmd.CommandType = CommandType.Text

         ' Execute the Query
         intRows = cmd.ExecuteNonQuery()
         
         ' Close the Connection
         cmd.Connection.Close()

         MessageBox.Show("Rows Affected: " & intRows.ToString())

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
      SqlHelperUpdate()
   End Sub

   Private Sub SqlHelperUpdate()
      Dim intRows As Integer

      Try
         ' Execute the Query
         intRows = SqlHelper.ExecuteNonQuery(AppConfig.ConnectString, _
         "procProductsUpdate", "Chai 2", 1)

         MessageBox.Show("Rows Affected: " & intRows.ToString())

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnADOParams_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnADOParams.Click
      ADONetParams()
   End Sub

   Private Sub ADONetParams()
      Dim cmd As SqlCommand
      Dim param As SqlParameter
      Dim strSQL As String
      Dim intRows As Integer

      strSQL = "procProductsUpdate"

      Try
         ' Create a new Command Object
         cmd = New SqlCommand(strSQL)
         ' Create a new Connection Object
         cmd.Connection = New _
               SqlConnection(AppConfig.ConnectString)

         ' Create the Parameters
         param = New SqlParameter( _
               "@ProductName", "Chai 2")
         cmd.Parameters.Add(param)

         param = New SqlParameter( _
               "@ProductID", 1)
         cmd.Parameters.Add(param)

         ' Open the Connection
         cmd.Connection.Open()
         ' Set CommandType to Stored procedure
         cmd.CommandType = CommandType.StoredProcedure
         ' Execute the Stored Procedure
         intRows = cmd.ExecuteNonQuery()
         ' Close the Connection
         cmd.Connection.Close()

         MessageBox.Show("Rows Affected: " & intRows.ToString())

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnSqlHelperParams_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSqlHelperParams.Click
      SqlHelperParams()
   End Sub

   Private Sub SqlHelperParams()
      Dim aParams(1) As SqlParameter
      Dim intRows As Integer

      Try
         ' Create the Parameters
         aParams(0) = New SqlParameter( _
               "@ProductName", "Chai 2")

         aParams(1) = New SqlParameter( _
               "@ProductID", 1)

         ' Execute the Stored Procedure
         intRows = SqlHelper.ExecuteNonQuery( _
               AppConfig.ConnectString, CommandType.StoredProcedure, _
               "procProductsUpdate", aParams)

         MessageBox.Show("Rows Affected: " & intRows.ToString())

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnOutput_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOutput.Click
      OutputParams()
   End Sub

   Private Sub OutputParams()
      ' This method will create a new ticket and set the exiration date
      Dim aParams(1) As SqlParameter
      Dim intRows As Integer

      Try
         aParams(0) = New SqlParameter("@UserID", "Paul")
         aParams(1) = New SqlParameter("@NewGUID", "")
         With aParams(1)
            .SqlDbType = SqlDbType.UniqueIdentifier
            .Direction = ParameterDirection.Output
         End With

         intRows = SqlHelper.ExecuteNonQuery(AppConfig.ConnectString, _
               CommandType.StoredProcedure, _
               "procTicketCreate", aParams)

         MessageBox.Show(aParams(1).Value.ToString())

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub
End Class
