Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data

Public Class SQLTransHelper
   Public Shared Sub ExecuteTrans(ByVal ConnectString As String, _
     ByVal ParamArray SQLStatements() As String)
      Dim cnn As SqlConnection
      Dim tr As SqlTransaction
      Dim strSQL As String

      Try
         ' Create Connect Object
         cnn = New SqlConnection(ConnectString)
         ' Open the Connection
         cnn.Open()

         ' Start Transaction
         tr = cnn.BeginTransaction()

         For Each strSQL In SQLStatements
            ' Execute the SQL
            SqlHelper.ExecuteNonQuery(tr, _
               CommandType.Text, strSQL)
         Next

         ' Commit the Transaction
         tr.Commit()
        
      Catch ex As Exception
         ' Rollback the Transaction
         tr.Rollback()

         ' Throw an exception back to caller
         Throw ex

      Finally
         If cnn.State <> ConnectionState.Closed Then
            cnn.Close()
            cnn.Dispose()
         End If

      End Try
   End Sub
End Class