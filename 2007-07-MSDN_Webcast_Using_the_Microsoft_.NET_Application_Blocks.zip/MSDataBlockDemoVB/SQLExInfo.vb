Public Class SQLExInfo
   Public Shared Function GetSQLExceptionInfo(ByVal ex As Exception) As String
      Dim sxp As SqlClient.SqlException
      Dim intLoop As Integer
      Dim strMsg As String = ""

      sxp = DirectCast(ex, SqlClient.SqlException)

      For intLoop = 0 To sxp.Errors.Count - 1
         strMsg &= "Index #" & intLoop & ControlChars.CrLf & _
                   "Source: " & sxp.Errors(intLoop).Source & ControlChars.CrLf & _
                   "Number: " & sxp.Errors(intLoop).Number.ToString() & ControlChars.CrLf & _
                   "State: " & sxp.Errors(intLoop).State.ToString() & ControlChars.CrLf & _
                   "Class: " & sxp.Errors(intLoop).Class.ToString() & ControlChars.CrLf & _
                   "Server: " & sxp.Errors(intLoop).Server & ControlChars.CrLf & _
                   "Message: " & sxp.Errors(intLoop).Message & ControlChars.CrLf & _
                   "Procedure: " & sxp.Errors(intLoop).Procedure & ControlChars.CrLf & _
                   "LineNumber: " & sxp.Errors(intLoop).LineNumber.ToString() & ControlChars.CrLf
      Next intLoop

      Return strMsg
   End Function
End Class
