Imports System.Data.SqlClient
Imports System.Xml
Imports Microsoft.ApplicationBlocks.Data

Public Class frmTSQL
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents grdProducts As System.Windows.Forms.DataGrid
   Friend WithEvents btnRetrieve As System.Windows.Forms.Button
   Friend WithEvents btnADO As System.Windows.Forms.Button
   Friend WithEvents btnUpdateADO As System.Windows.Forms.Button
   Friend WithEvents btnUpdate As System.Windows.Forms.Button
   Friend WithEvents btnADONetDR As System.Windows.Forms.Button
   Friend WithEvents btnDRSqlHelper As System.Windows.Forms.Button
   Friend WithEvents btnADOScalar As System.Windows.Forms.Button
   Friend WithEvents btnSqlHelperScalar As System.Windows.Forms.Button
   Friend WithEvents btnXMLADO As System.Windows.Forms.Button
   Friend WithEvents btnXMLSqlHelper As System.Windows.Forms.Button
   Friend WithEvents txtXML As System.Windows.Forms.TextBox
   Friend WithEvents lstProducts As System.Windows.Forms.ListBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.grdProducts = New System.Windows.Forms.DataGrid()
      Me.btnRetrieve = New System.Windows.Forms.Button()
      Me.btnADO = New System.Windows.Forms.Button()
      Me.btnUpdateADO = New System.Windows.Forms.Button()
      Me.btnUpdate = New System.Windows.Forms.Button()
      Me.btnADONetDR = New System.Windows.Forms.Button()
      Me.btnDRSqlHelper = New System.Windows.Forms.Button()
      Me.btnADOScalar = New System.Windows.Forms.Button()
      Me.btnSqlHelperScalar = New System.Windows.Forms.Button()
      Me.btnXMLADO = New System.Windows.Forms.Button()
      Me.btnXMLSqlHelper = New System.Windows.Forms.Button()
      Me.txtXML = New System.Windows.Forms.TextBox()
      Me.lstProducts = New System.Windows.Forms.ListBox()
      CType(Me.grdProducts, System.ComponentModel.ISupportInitialize).BeginInit()
      Me.SuspendLayout()
      '
      'grdProducts
      '
      Me.grdProducts.DataMember = ""
      Me.grdProducts.HeaderForeColor = System.Drawing.SystemColors.ControlText
      Me.grdProducts.Location = New System.Drawing.Point(8, 8)
      Me.grdProducts.Name = "grdProducts"
      Me.grdProducts.Size = New System.Drawing.Size(696, 168)
      Me.grdProducts.TabIndex = 0
      '
      'btnRetrieve
      '
      Me.btnRetrieve.Location = New System.Drawing.Point(168, 184)
      Me.btnRetrieve.Name = "btnRetrieve"
      Me.btnRetrieve.Size = New System.Drawing.Size(144, 64)
      Me.btnRetrieve.TabIndex = 1
      Me.btnRetrieve.Text = "DataSet using SqlHelper"
      '
      'btnADO
      '
      Me.btnADO.Location = New System.Drawing.Point(16, 184)
      Me.btnADO.Name = "btnADO"
      Me.btnADO.Size = New System.Drawing.Size(144, 64)
      Me.btnADO.TabIndex = 2
      Me.btnADO.Text = "DataSet using ADO.NET"
      '
      'btnUpdateADO
      '
      Me.btnUpdateADO.Location = New System.Drawing.Point(16, 256)
      Me.btnUpdateADO.Name = "btnUpdateADO"
      Me.btnUpdateADO.Size = New System.Drawing.Size(144, 64)
      Me.btnUpdateADO.TabIndex = 3
      Me.btnUpdateADO.Text = "Update Data using ADO.NET"
      '
      'btnUpdate
      '
      Me.btnUpdate.Location = New System.Drawing.Point(168, 256)
      Me.btnUpdate.Name = "btnUpdate"
      Me.btnUpdate.Size = New System.Drawing.Size(144, 64)
      Me.btnUpdate.TabIndex = 4
      Me.btnUpdate.Text = "Update Data using SqlHelper"
      '
      'btnADONetDR
      '
      Me.btnADONetDR.Location = New System.Drawing.Point(16, 328)
      Me.btnADONetDR.Name = "btnADONetDR"
      Me.btnADONetDR.Size = New System.Drawing.Size(144, 64)
      Me.btnADONetDR.TabIndex = 6
      Me.btnADONetDR.Text = "DataReader using ADO.NET"
      '
      'btnDRSqlHelper
      '
      Me.btnDRSqlHelper.Location = New System.Drawing.Point(168, 328)
      Me.btnDRSqlHelper.Name = "btnDRSqlHelper"
      Me.btnDRSqlHelper.Size = New System.Drawing.Size(144, 64)
      Me.btnDRSqlHelper.TabIndex = 5
      Me.btnDRSqlHelper.Text = "DataReader using SqlHelper"
      '
      'btnADOScalar
      '
      Me.btnADOScalar.Location = New System.Drawing.Point(16, 400)
      Me.btnADOScalar.Name = "btnADOScalar"
      Me.btnADOScalar.Size = New System.Drawing.Size(144, 64)
      Me.btnADOScalar.TabIndex = 8
      Me.btnADOScalar.Text = "Scalar using ADO.NET"
      '
      'btnSqlHelperScalar
      '
      Me.btnSqlHelperScalar.Location = New System.Drawing.Point(168, 400)
      Me.btnSqlHelperScalar.Name = "btnSqlHelperScalar"
      Me.btnSqlHelperScalar.Size = New System.Drawing.Size(144, 64)
      Me.btnSqlHelperScalar.TabIndex = 7
      Me.btnSqlHelperScalar.Text = "Scalar using SqlHelper"
      '
      'btnXMLADO
      '
      Me.btnXMLADO.Location = New System.Drawing.Point(16, 472)
      Me.btnXMLADO.Name = "btnXMLADO"
      Me.btnXMLADO.Size = New System.Drawing.Size(144, 64)
      Me.btnXMLADO.TabIndex = 10
      Me.btnXMLADO.Text = "XMLReader using ADO.NET"
      '
      'btnXMLSqlHelper
      '
      Me.btnXMLSqlHelper.Location = New System.Drawing.Point(168, 472)
      Me.btnXMLSqlHelper.Name = "btnXMLSqlHelper"
      Me.btnXMLSqlHelper.Size = New System.Drawing.Size(144, 64)
      Me.btnXMLSqlHelper.TabIndex = 9
      Me.btnXMLSqlHelper.Text = "XMLReader using SqlHelper"
      '
      'txtXML
      '
      Me.txtXML.Location = New System.Drawing.Point(328, 352)
      Me.txtXML.Multiline = True
      Me.txtXML.Name = "txtXML"
      Me.txtXML.ScrollBars = System.Windows.Forms.ScrollBars.Both
      Me.txtXML.Size = New System.Drawing.Size(384, 184)
      Me.txtXML.TabIndex = 11
      Me.txtXML.Text = ""
      '
      'lstProducts
      '
      Me.lstProducts.ItemHeight = 20
      Me.lstProducts.Location = New System.Drawing.Point(328, 192)
      Me.lstProducts.Name = "lstProducts"
      Me.lstProducts.Size = New System.Drawing.Size(376, 144)
      Me.lstProducts.TabIndex = 12
      '
      'frmTSQL
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
      Me.ClientSize = New System.Drawing.Size(720, 546)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstProducts, Me.txtXML, Me.btnXMLADO, Me.btnXMLSqlHelper, Me.btnADOScalar, Me.btnSqlHelperScalar, Me.btnADONetDR, Me.btnDRSqlHelper, Me.btnUpdate, Me.btnUpdateADO, Me.btnADO, Me.btnRetrieve, Me.grdProducts})
      Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.Name = "frmTSQL"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
      Me.Text = "T-SQL Samples"
      CType(Me.grdProducts, System.ComponentModel.ISupportInitialize).EndInit()
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnADO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnADO.Click
      ADONetRetrieve()
   End Sub

   Private Sub ADONetRetrieve()
      Dim ds As New DataSet()
      Dim da As SqlDataAdapter
      Dim strSQL As String

      strSQL = "SELECT * FROM Products"

      Try
         ' Create a DataAdapter Object
         da = New SqlDataAdapter(strSQL, _
            AppConfig.ConnectString)
         ' Fill the DataSet
         da.Fill(ds)

         grdProducts.DataSource = ds.Tables(0)

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnRetrieve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetrieve.Click
      SqlHelperRetrieve()
   End Sub

   Private Sub SqlHelperRetrieve()
      Dim ds As DataSet
      Dim strSQL As String

      strSQL = "SELECT * FROM Products"

      Try
         ' Call the SqlHelper Class to create the DataSet
         ds = SqlHelper.ExecuteDataset(AppConfig.ConnectString, _
            CommandType.Text, strSQL)

         grdProducts.DataSource = ds.Tables(0)

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnUpdateADO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateADO.Click
      ADONetUpdate()
   End Sub

   Private Sub ADONetUpdate()
      Dim cmd As SqlCommand
      Dim strSQL As String
      Dim intRows As Integer

      strSQL = "UPDATE Products "
      strSQL &= " SET ProductName = 'Chai 2' "
      strSQL &= " WHERE ProductID = 1"

      Try
         ' Create a new Command Object
         cmd = New SqlCommand(strSQL)
         ' Create a new Connection Object
         cmd.Connection = New _
            SqlConnection(AppConfig.ConnectString)
         ' Open the Connection
         cmd.Connection.Open()
         ' Set the CommandType to Text
         cmd.CommandType = CommandType.Text
         ' Execute the Query
         intRows = cmd.ExecuteNonQuery()
         ' Close the Connection
         cmd.Connection.Close()

         MessageBox.Show("Rows Affected: " & intRows.ToString())

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
      SqlHelperUpdate()
   End Sub

   Private Sub SqlHelperUpdate()
      Dim strSQL As String
      Dim intRows As Integer

      strSQL = "UPDATE Products "
      strSQL &= " SET ProductName = 'Chai 2' "
      strSQL &= " WHERE ProductID = 1"

      Try
         ' Execute the Query and Return Result
         intRows = SqlHelper.ExecuteNonQuery(AppConfig.ConnectString, _
            CommandType.Text, strSQL)

         MessageBox.Show("Rows Affected: " & intRows.ToString())

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnADONetDR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnADONetDR.Click
      ADONetDataReader()
   End Sub

   Private Sub ADONetDataReader()
      Dim dr As SqlDataReader
      Dim cmd As SqlCommand
      Dim strSQL As String

      strSQL = "SELECT ProductName FROM Products "

      Try
         ' Create a new Command Object
         cmd = New SqlCommand(strSQL)
         ' Create a new Connection Object
         cmd.Connection = New _
            SqlConnection(AppConfig.ConnectString)
         ' Open the Connection
         cmd.Connection.Open()
         ' Set the CommandType to Text
         cmd.CommandType = CommandType.Text
         ' Get the DataReader
         dr = cmd.ExecuteReader( _
            CommandBehavior.CloseConnection)

         lstProducts.Items.Clear()
         Do While dr.Read
            lstProducts.Items.Add(dr.Item("ProductName"))
         Loop
         ' Close the DataReader & Connection
         dr.Close()

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnDRSqlHelper_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDRSqlHelper.Click
      SqlHelperDataReader()
   End Sub

   Private Sub SqlHelperDataReader()
      Dim dr As SqlDataReader
      Dim strSQL As String

      strSQL = "SELECT ProductName FROM Products "

      Try
         dr = SqlHelper.ExecuteReader(AppConfig.ConnectString, _
            CommandType.Text, strSQL)

         lstProducts.Items.Clear()
         Do While dr.Read
            lstProducts.Items.Add(dr.Item("ProductName"))
         Loop
         ' Closes the DataReader & Connection
         dr.Close()

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnADOScalar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnADOScalar.Click
      ADONetScalar()
   End Sub

   Private Sub ADONetScalar()
      Dim cmd As SqlCommand
      Dim strSQL As String
      Dim intRows As Integer

      strSQL = "SELECT Count(*) FROM Products "

      Try
         ' Create a new Command Object
         cmd = New SqlCommand(strSQL)
         ' Create a new Connection Object
         cmd.Connection = New _
            SqlConnection(AppConfig.ConnectString)
         ' Open the Connection
         cmd.Connection.Open()
         ' Set the CommandType to Text
         cmd.CommandType = CommandType.Text
         ' Execute the Scalar Function
         intRows = Convert.ToInt32(cmd.ExecuteScalar())

         MessageBox.Show("Total Products=" & intRows.ToString())

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      Finally
         If cmd.Connection.State <> ConnectionState.Closed Then
            cmd.Connection.Close()
            cmd.Connection.Dispose()
         End If
      End Try
   End Sub

   Private Sub btnSqlHelperScalar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSqlHelperScalar.Click
      SqlHelperScalar()
   End Sub

   Private Sub SqlHelperScalar()
      Dim strSQL As String
      Dim intRows As Integer

      strSQL = "SELECT Count(*) FROM Products "

      Try
         ' Execute the Scalar function
         intRows = Convert.ToInt32( _
            SqlHelper.ExecuteScalar(AppConfig.ConnectString, _
            CommandType.Text, strSQL))

         MessageBox.Show("Total Products=" & intRows.ToString())

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      End Try
   End Sub

   Private Sub btnXMLSqlHelper_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXMLSqlHelper.Click
      SqlHelperXML()
   End Sub

   Private Sub SqlHelperXML()
      Dim strSQL As String
      Dim xr As XmlReader
      Dim cnn As SqlConnection

      strSQL = "SELECT CategoryID, CategoryName FROM Categories FOR XML AUTO"

      Try
         cnn = New SqlConnection(AppConfig.ConnectString)
         cnn.Open()
         xr = SqlHelper.ExecuteXmlReader(cnn, CommandType.Text, strSQL)

         txtXML.Text = ""
         Do While xr.Read()
            txtXML.Text &= xr.ReadOuterXml() & Environment.NewLine
         Loop

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      Finally
         If cnn.State <> ConnectionState.Closed Then
            cnn.Close()
            cnn.Dispose()
         End If

      End Try
   End Sub

   Private Sub btnXMLADO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXMLADO.Click
      ADONetXMLReader()
   End Sub

   Private Sub ADONetXMLReader()
      Dim strSQL As String
      Dim xr As XmlReader
      Dim cnn As SqlConnection
      Dim cmd As SqlCommand

      strSQL = "SELECT CategoryID, CategoryName FROM Categories FOR XML AUTO"

      Try
         cnn = New SqlConnection(AppConfig.ConnectString)
         cnn.Open()
         cmd = New SqlCommand(strSQL, cnn)

         xr = cmd.ExecuteXmlReader()

         txtXML.Text = ""
         Do While xr.Read()
            txtXML.Text &= xr.ReadOuterXml() & Environment.NewLine
         Loop

      Catch ex As SqlException
         MessageBox.Show(SQLExInfo.GetSQLExceptionInfo(ex))

      Catch ex As Exception
         MessageBox.Show(ex.Message)

      Finally
         If cnn.State <> ConnectionState.Closed Then
            cnn.Close()
            cnn.Dispose()
         End If

      End Try
   End Sub
End Class
