using System;

namespace MSExceptionBlockDemoCS
{
	/// <summary>
	/// Summary description for AppConfig.
	/// </summary>
	public class AppConfig
	{
		public AppConfig()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static string ConnectString
		{
			get{ return System.Configuration.ConfigurationSettings.AppSettings["ConnectString"]; }
		}
	}
}
