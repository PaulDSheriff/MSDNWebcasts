using System;

using System.Data;
using System.Web.Mail;
using System.Security.Principal;
using System.Collections.Specialized;
using Microsoft.ApplicationBlocks.ExceptionManagement;
using Microsoft.ApplicationBlocks.Data;

namespace ErrorCommonCS
{
	/// <summary>
	/// Summary description for emSQL.
	/// </summary>
	public class emEmail : IExceptionPublisher
	{
		public emEmail()
		{
		}

		void IExceptionPublisher.Publish(Exception ex, 
			NameValueCollection additionalInfo, 
			NameValueCollection configSettings)
		{
			string strFromEmail = string.Empty;
			string strToEmail = string.Empty;
			string strSubject = string.Empty;
			string strSMTP = string.Empty;
			string strFormName = string.Empty;
			string strAppName = string.Empty;
		
			if (additionalInfo != null)
			{
				// Retrieve Additional Info
				strFormName = additionalInfo["FormName"];
				strAppName = additionalInfo["ApplicationName"];
			}

			if (configSettings != null)
			{
				// Get Information from <Publisher> element
				strFromEmail = configSettings["FromEMail"];
				strToEmail = configSettings["ToEMail"];
				strSubject = configSettings["Subject"];
				strSMTP = configSettings["SMTPServer"];
			}

			strSubject += " - " + strFormName + " - " + strAppName;

			try
			{
				// Send Exception via Email
				SmtpMail.SmtpServer = strSMTP;
				SmtpMail.Send(strFromEmail, strToEmail, 
					strSubject, ex.ToString());

			}
			catch (Exception exp)
			{
				throw exp;
			}
		}
	}
}
