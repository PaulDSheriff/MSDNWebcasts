using System;
using System.Data;
using System.Security.Principal;
using System.Collections.Specialized;
using Microsoft.ApplicationBlocks.ExceptionManagement;
using Microsoft.ApplicationBlocks.Data;

namespace ErrorCommonCS
{
	/// <summary>
	/// Summary description for emSQL.
	/// </summary>
	public class emSql : IExceptionPublisher
	{
		public emSql()
		{
		}

		void IExceptionPublisher.Publish(Exception ex, 
			NameValueCollection additionalInfo, 
			NameValueCollection configSettings)
		{
			string strConn = string.Empty;
			string strSQL = string.Empty;
			string strFormName = string.Empty;
			string strAppName = string.Empty;
		
			if (additionalInfo != null)
			{
				// Retrieve Additional Info
				strFormName = additionalInfo["FormName"];
				strAppName = additionalInfo["ApplicationName"];
			}

			if (configSettings != null)
			{
				// Get Information from <Publisher> element
				strConn = configSettings["SQLConnect"];
			}

			strSQL = "INSERT INTO ErrorLog(";
			strSQL += "szUser_nm, szForm_nm, ";
			strSQL += "dtError_dt, szAppl_nm, szError_tx )";
			strSQL += " VALUES('{0}', '{1}', '{2}', '{3}', '{4}')";

			strSQL = String.Format(strSQL, 
				WindowsIdentity.GetCurrent().Name,
				strFormName, DateTime.Now.ToString(), 
				strAppName, 
				ex.ToString().Replace("'", "''"));

			try
			{
				SqlHelper.ExecuteNonQuery(strConn, 
					CommandType.Text, strSQL);
			}
			catch (Exception exp)
			{
				throw exp;
			}
		}
	}
}
