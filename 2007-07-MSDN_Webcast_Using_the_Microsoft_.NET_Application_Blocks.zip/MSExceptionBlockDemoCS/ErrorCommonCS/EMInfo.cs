using System;
using System.Collections.Specialized;

namespace ErrorCommonCS
{
	/// <summary>
	/// Summary description for EMInfo.
	/// </summary>
	public class EMInfo
	{
		public EMInfo()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static NameValueCollection AdditionalInfo(string FormName, string ApplicationName)
		{
			NameValueCollection nvc = new NameValueCollection();

			nvc.Add("FormName", FormName);
			nvc.Add("ApplicationName", ApplicationName);

			return nvc;
		}
	}
}
