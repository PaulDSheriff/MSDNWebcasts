using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using System.Data;
using ErrorCommonCS;
using System.Collections.Specialized;
using Microsoft.ApplicationBlocks.Data;
using Microsoft.ApplicationBlocks.ExceptionManagement;

namespace MSExceptionBlockDemoCS
{
	/// <summary>
	/// Summary description for frmMain.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Button btnNameValue2;
		internal System.Windows.Forms.Button btnNameValue;
		internal System.Windows.Forms.Button btnCreate;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnNameValue2 = new System.Windows.Forms.Button();
			this.btnNameValue = new System.Windows.Forms.Button();
			this.btnCreate = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnNameValue2
			// 
			this.btnNameValue2.Location = new System.Drawing.Point(296, 8);
			this.btnNameValue2.Name = "btnNameValue2";
			this.btnNameValue2.Size = new System.Drawing.Size(136, 80);
			this.btnNameValue2.TabIndex = 5;
			this.btnNameValue2.Text = "Exception With NameValue 2";
			this.btnNameValue2.Click += new System.EventHandler(this.btnNameValue2_Click);
			// 
			// btnNameValue
			// 
			this.btnNameValue.Location = new System.Drawing.Point(152, 8);
			this.btnNameValue.Name = "btnNameValue";
			this.btnNameValue.Size = new System.Drawing.Size(136, 80);
			this.btnNameValue.TabIndex = 4;
			this.btnNameValue.Text = "Exception With NameValue";
			this.btnNameValue.Click += new System.EventHandler(this.btnNameValue_Click);
			// 
			// btnCreate
			// 
			this.btnCreate.Location = new System.Drawing.Point(8, 8);
			this.btnCreate.Name = "btnCreate";
			this.btnCreate.Size = new System.Drawing.Size(136, 80);
			this.btnCreate.TabIndex = 3;
			this.btnCreate.Text = "Create Exception";
			this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(9, 22);
			this.ClientSize = new System.Drawing.Size(440, 98);
			this.Controls.Add(this.btnNameValue2);
			this.Controls.Add(this.btnNameValue);
			this.Controls.Add(this.btnCreate);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "frmMain";
			this.Text = "Exception Management";
			this.ResumeLayout(false);

		}
		#endregion

		private void btnCreate_Click(object sender, System.EventArgs e)
		{
			DataSet ds = new DataSet();
			string strSQL;

			strSQL = "SELECT * FROM Prodcts";

			try
			{
				ds = SqlHelper.ExecuteDataset(AppConfig.ConnectString,
					CommandType.Text, strSQL);

				// Do something with the DataSet
			}
			catch (Exception ex)
			{
				ExceptionManager.Publish(ex);

				MessageBox.Show(ex.Message);
			}
		}

		private void btnNameValue_Click(object sender, System.EventArgs e)
		{
			DataSet ds = new DataSet();
			string strSQL;

			strSQL = "SELECT * FROM Prodcts";

			try
			{
				ds = SqlHelper.ExecuteDataset(AppConfig.ConnectString,
					CommandType.Text, strSQL);

				// Do something with the DataSet
			}
			catch (Exception ex)
			{
				NameValueCollection nvc = new NameValueCollection();

				nvc.Add("FormName", "frmMain");
				nvc.Add("ApplicationName", "MSExceptionBlockDemoCS");

				ExceptionManager.Publish(ex, nvc);

				MessageBox.Show(ex.Message);
			}
		}

		private void btnNameValue2_Click(object sender, System.EventArgs e)
		{
			DataSet ds = new DataSet();
			string strSQL;

			strSQL = "SELECT * FROM Prodcts";

			try
			{
				ds = SqlHelper.ExecuteDataset(AppConfig.ConnectString,
					CommandType.Text, strSQL);

				// Do something with the DataSet
			}
			catch (Exception ex)
			{
				ExceptionManager.Publish(ex, 
					EMInfo.AdditionalInfo("frmMain", "MSExceptionBlockDemoCS"));

				MessageBox.Show(ex.Message);
			}		
		}
	}
}
