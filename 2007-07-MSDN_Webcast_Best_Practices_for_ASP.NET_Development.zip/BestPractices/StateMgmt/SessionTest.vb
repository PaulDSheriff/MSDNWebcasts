Public Class SessionTest
    Inherits System.Web.UI.Page

    Protected WithEvents btnSubmit As System.Web.UI.WebControls.Button
    Protected WithEvents txtEmail As System.Web.UI.WebControls.TextBox

#Region " Web Forms Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        Session("Email") = txtEmail.Text
        Response.Redirect("Main.aspx")
    End Sub

    Private Sub Page_Load(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Session("Email") Is Nothing Then
        Else
            txtEmail.Text = Session("Email").ToString()
        End If
    End Sub

End Class
