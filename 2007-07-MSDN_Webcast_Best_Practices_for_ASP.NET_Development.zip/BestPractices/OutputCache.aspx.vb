Imports DataLayer

Public Class OutputCache
  Inherits System.Web.UI.Page

  Protected WithEvents lblError As System.Web.UI.WebControls.Label
  Protected WithEvents lblTime As System.Web.UI.WebControls.Label
  Protected WithEvents grdProducts As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    If Not Page.IsPostBack Then
      GridLoad()
    End If
  End Sub

  Private Sub GridLoad()
    Dim prod As ProductsData
    Dim dr As IDataReader

    Try
      prod = New ProductsData()

      dr = prod.GetProductsByCategory(Request.QueryString("CatID").ToString())
      grdProducts.DataSource = dr
      grdProducts.DataBind()
      dr.Close()

    Catch exp As Exception
      lblError.Text = exp.Message

    End Try

    lblTime.Text = Now.ToString()
  End Sub
End Class
