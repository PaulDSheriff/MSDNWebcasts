Option Strict Off

Public Class ComASPCompat
  Inherits System.Web.UI.Page
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents lblResult As System.Web.UI.WebControls.Label

  Private mathtest As STATest.MathClass

#Region " Web Form Designer Generated Code "
  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Public Sub New()
    mathtest = New STATest.MathClass()
  End Sub

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    'Put user code to initialize the page here
    Dim t1 As DateTime, t2 As DateTime
    Dim i As Integer
    Dim a, b As Long
    Dim res As Long
    Dim ts As TimeSpan

    'mathtest = New STATest.MathClass()

    t1 = DateTime.Now
    res = 0
    For i = 1 To 10000
      a = i
      b = i
      res = res + mathtest.Multiply(a, b)
    Next i
    t2 = DateTime.Now
    ts = t2.Subtract(t1)

    lblResult.Text = "Sum of squares of 1 to 10000 is: " & res & " Computatuion time: " & ts.ToString()
  End Sub

End Class
