Option Strict Off

Public Class WebForm1
  Inherits System.Web.UI.Page
  Protected WithEvents lblEarlyBind As System.Web.UI.WebControls.Label
  Protected WithEvents lblLateBind As System.Web.UI.WebControls.Label
  Protected WithEvents BtnMeasure As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    'Put user code to initialize the page here

  End Sub

  Private Sub ComputeLateBound()
    ' VB late Binding Example
    Dim ts As TimeSpan
    Dim t1, t2
    Dim Count
    Dim i
    Dim j
    Dim k
    Dim l
    Dim obj

    t1 = DateTime.Now
    For Count = 0 To 50
      i = Count * 2
      For j = 0 To i
        k = Count * 0.75 + i * 0.5
        obj = New System.Collections.ArrayList()
        For l = 0 To Count
          obj.Add(l)
        Next
      Next
      'Response.Write("Count = " & Count & " i = " & i)
    Next Count

    t2 = DateTime.Now
    ts = t2.Subtract(t1)
    lblLateBind.Text = lblLateBind.Text + ts.ToString()
  End Sub



  Private Sub ComputeEarlyBound()
    ' VB Early Binding Example
    Dim t1 As DateTime, t2 As DateTime
    Dim Count As Integer
    Dim i As Integer
    Dim j As Integer
    Dim k As Double
    Dim l As Integer
    Dim m As Double
    Dim obj As ArrayList = New ArrayList()
    Dim ts As TimeSpan

    t1 = DateTime.Now
    For Count = 0 To 50
      i = Count * 2
      For j = 0 To i
        k = Count * 0.75 + i * 0.5
        For l = 0 To Count
          obj.Add(l)
        Next
      Next
      'Response.Write("Count = " & Count & " i = " & i)
    Next Count

    t2 = DateTime.Now
    ts = t2.Subtract(t1)
    lblEarlyBind.Text = lblEarlyBind.Text + ts.ToString()
  End Sub

  Private Sub BtnMeasure_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMeasure.Click
    ComputeLateBound()
    ComputeEarlyBound()
  End Sub
End Class
