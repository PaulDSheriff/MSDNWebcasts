Imports DataLayer

Public MustInherit Class Fragment
  Inherits System.Web.UI.UserControl
  Protected WithEvents lblError As System.Web.UI.WebControls.Label
  Protected WithEvents grdProducts As System.Web.UI.WebControls.DataGrid
  Protected WithEvents lblTime As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    GridLoad()
  End Sub

  Private Sub GridLoad()
    Dim prod As ProductsData
    Dim dr As IDataReader

    Try
      prod = New ProductsData()


      dr = prod.GetSomeProductsAsDataReader()
      grdProducts.DataSource = dr
      grdProducts.DataBind()
      dr.Close()

      lblTime.Text = Now.ToString()

    Catch exp As Exception
      lblError.Text = exp.Message

    End Try
  End Sub
End Class
