Imports DataLayer

Public Class BufferedResponse
  Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ProductsLoad()
  End Sub

  Private Sub ProductsLoad()
    Dim sb As System.Text.StringBuilder
    Dim prod As ProductsData
    Dim dr As IDataReader

    Try
      prod = New ProductsData()
      sb = New System.Text.StringBuilder(2000)

      sb.Append("<table bordercolor=""Silver"" border=""1"" style=""border-color:Silver;border-width:1px;border-style:Outset;border-collapse:collapse;Z-INDEX: 102; LEFT: 91px;"">")
      sb.Append("<tr Style=""color:White;background-color:Navy;font-family:Verdana;font-size:X-Small;"">")
      sb.Append("<td>ProductID</td>")
      sb.Append("<td>ProductName</td>")
      sb.Append("<td>UnitsInStock</td>")
      sb.Append("<td>UnitPrice</td>")

      dr = prod.GetSomeProductsAsDataReader()
      Do While dr.Read()
        sb.Append("<tr style=""background-color:#E0E0E0;border-style:Inset;font-family:Tahoma;font-size:X-Small;"">")

        sb.Append("<td>")
        sb.Append(dr.Item("ProductID"))
        sb.Append("</td>")
        sb.Append("<td>")
        sb.Append(dr.Item("ProductName"))
        sb.Append("</td>")
        sb.Append("<td>")
        sb.Append(dr.Item("UnitsInStock"))
        sb.Append("</td>")
        sb.Append("<td>")
        sb.Append(dr.Item("UnitPrice"))
        sb.Append("</td>")

        sb.Append("</tr>")
      Loop
      dr.Close()
      sb.Append("</table>")

      Response.Write(sb.ToString())

    Catch exp As Exception
      Response.Write(exp.Message)
    End Try
  End Sub

End Class
