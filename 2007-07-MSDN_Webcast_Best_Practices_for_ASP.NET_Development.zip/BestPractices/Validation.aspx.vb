Public Class Validation
  Inherits System.Web.UI.Page
  Protected WithEvents lblLast As System.Web.UI.WebControls.Label
  Protected WithEvents txtLast As System.Web.UI.WebControls.TextBox
  Protected WithEvents txtBirthDate As System.Web.UI.WebControls.TextBox
  Protected WithEvents lblBirthDate As System.Web.UI.WebControls.Label
  Protected WithEvents txtHireDate As System.Web.UI.WebControls.TextBox
  Protected WithEvents lblHireDate As System.Web.UI.WebControls.Label
  Protected WithEvents txtCity As System.Web.UI.WebControls.TextBox
  Protected WithEvents lblCity As System.Web.UI.WebControls.Label
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents lblPostal As System.Web.UI.WebControls.Label
  Protected WithEvents lblFirst As System.Web.UI.WebControls.Label
  Protected WithEvents txtHomePhone As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label2 As System.Web.UI.WebControls.Label
  Protected WithEvents lblEmpMaint As System.Web.UI.WebControls.Label
  Protected WithEvents btnSave As System.Web.UI.WebControls.Button
  Protected WithEvents txtZipCode As System.Web.UI.WebControls.TextBox
  Protected WithEvents txtState As System.Web.UI.WebControls.TextBox
  Protected WithEvents RequiredFieldValidator1 As System.Web.UI.WebControls.RequiredFieldValidator
  Protected WithEvents RequiredFieldValidator2 As System.Web.UI.WebControls.RequiredFieldValidator
  Protected WithEvents RequiredFieldValidator3 As System.Web.UI.WebControls.RequiredFieldValidator
  Protected WithEvents RequiredFieldValidator4 As System.Web.UI.WebControls.RequiredFieldValidator
  Protected WithEvents rvalBirthDate As System.Web.UI.WebControls.RangeValidator
  Protected WithEvents RegularExpressionValidator1 As System.Web.UI.WebControls.RegularExpressionValidator
  Protected WithEvents RegularExpressionValidator2 As System.Web.UI.WebControls.RegularExpressionValidator
  Protected WithEvents cvalState As System.Web.UI.WebControls.CustomValidator
  Protected WithEvents ValidationSummary1 As System.Web.UI.WebControls.ValidationSummary
  Protected WithEvents txtFirst As System.Web.UI.WebControls.TextBox

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load( _
    ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles MyBase.Load

    If Not Page.IsPostBack Then
      With rvalBirthDate
        .MinimumValue = CStr(Today.AddYears(-70))
        .MaximumValue = CStr(Today.AddYears(-17))
        .ErrorMessage = String.Format( _
          "Enter a date between {0} and {1}", _
          .MinimumValue, .MaximumValue)
      End With
    End If
  End Sub

  Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
    Server.Transfer("Default.aspx")
  End Sub

  Private Sub cvalState_ServerValidate(ByVal source As System.Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles cvalState.ServerValidate

    Select Case args.Value
      Case "CA", "NV", "AZ"
        args.IsValid = True
      Case Else
        args.IsValid = False
    End Select
  End Sub
End Class
