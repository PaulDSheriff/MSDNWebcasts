Public Class CacheTest
  Inherits System.Web.UI.Page

  Protected WithEvents btnInsert As System.Web.UI.WebControls.Button
  Protected WithEvents btnInsertTime As System.Web.UI.WebControls.Button
  Protected WithEvents btnSliding As System.Web.UI.WebControls.Button
  Protected WithEvents btnRetrieve As System.Web.UI.WebControls.Button
  Protected WithEvents txtValue As System.Web.UI.WebControls.TextBox
  Protected WithEvents btnInsCallback As System.Web.UI.WebControls.Button
  Protected WithEvents btnAdd As System.Web.UI.WebControls.Button
  Protected WithEvents lblReason As System.Web.UI.WebControls.Label

  Private onRemove As New System.Web.Caching.CacheItemRemovedCallback(AddressOf RemovedCallback)
  Private reason As System.Web.Caching.CacheItemRemovedReason

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    'Put user code to initialize the page here
  End Sub

  Private Sub btnInsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsert.Click
    Cache.Insert("GlobalValue", "42")
  End Sub

  Private Sub btnInsertTime_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsertTime.Click
    Cache.Insert("GlobalValue", "42", Nothing, DateTime.Now.AddMinutes(2), TimeSpan.Zero)
  End Sub

  Private Sub btnSliding_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSliding.Click
    Cache.Insert("GlobalValue", "42", Nothing, DateTime.MaxValue, TimeSpan.FromSeconds(10))
  End Sub

  Private Sub btnRetrieve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetrieve.Click
    Try
      txtValue.Text = Cache.Item("GlobalValue").ToString()
    Catch
      txtValue.Text = "Cache Item (GlobalValue) does not exist"
    End Try
  End Sub

  Private Sub btnInsCallback_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsCallback.Click
    Cache.Insert("GlobalValue", "42", Nothing, DateTime.MaxValue, TimeSpan.FromSeconds(10), Caching.CacheItemPriority.High, onRemove)
  End Sub

  Public Sub RemovedCallback(ByVal key As String, ByVal value As Object, ByVal r As System.Web.Caching.CacheItemRemovedReason)
    reason = r

    Select Case reason
      Case Caching.CacheItemRemovedReason.DependencyChanged
      Case Caching.CacheItemRemovedReason.Expired
      Case Caching.CacheItemRemovedReason.Removed
      Case Caching.CacheItemRemovedReason.Underused
    End Select

    ' NOTE: You can't interact with user, since they are gone!
    ' Response.Redirect("CacheExpired.aspx")
  End Sub
End Class
