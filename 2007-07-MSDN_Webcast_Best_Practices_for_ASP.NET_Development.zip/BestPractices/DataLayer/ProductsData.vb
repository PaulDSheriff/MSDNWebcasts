Imports Microsoft.ApplicationBlocks.Data
Imports WebCommon

Public Class ProductsData
  Public Function GetProductsAsDataSet() As DataSet
    Dim strSQL As String

    strSQL = "SELECT * FROM Products"

    Try
      Return SqlHelper.ExecuteDataset(ConfigInfo.ConnectString, CommandType.Text, strSQL)

    Catch exp As Exception
      Throw exp

    End Try
  End Function

  Public Function GetProductsAsDataReader() As IDataReader
    Dim strSQL As String

    strSQL = "SELECT * FROM Products"

    Try
      Return SqlHelper.ExecuteReader(ConfigInfo.ConnectString, CommandType.Text, strSQL)

    Catch exp As Exception
      Throw exp

    End Try
  End Function

  Public Function GetProductsByCategory(ByVal CatID As String) As IDataReader
    Dim strSQL As String

    strSQL = "SELECT * FROM Products "
    strSQL &= " WHERE CategoryID = {0}"

    strSQL = String.Format(strSQL, CatID)

    Try
      Return SqlHelper.ExecuteReader(ConfigInfo.ConnectString, CommandType.Text, strSQL)

    Catch exp As Exception
      Throw exp

    End Try
  End Function

  Public Function GetSomeProductsAsDataReader() As IDataReader
    Dim strSQL As String

    strSQL = "SELECT TOP 15 ProductID, ProductName, UnitsInStock, UnitPrice FROM Products"

    Try
      Return SqlHelper.ExecuteReader(ConfigInfo.ConnectString, CommandType.Text, strSQL)

    Catch exp As Exception
      Throw exp

    End Try
  End Function

End Class