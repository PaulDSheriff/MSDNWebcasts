Imports DataLayer

Public Class ViewState
  Inherits System.Web.UI.Page
  Protected WithEvents lblError As System.Web.UI.WebControls.Label
  Protected WithEvents grdProducts As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    If Not Page.IsPostBack Then
      ViewState("SortField") = ""

      ' If GridLoad is in the PostBack, 
      ' then you need ViewState enabled
      GridLoad()
    End If

    ' If GridLoad is NOT in the PostBack, 
    ' then you DO NOT need ViewState enabled
    ' GridLoad()
  End Sub

  Private Sub GridLoad()
    Dim prod As ProductsData
    Dim dv As DataView

    Try
      prod = New ProductsData()

      dv = prod.GetProductsAsDataSet().Tables(0).DefaultView
      dv.Sort = ViewState("SortField").ToString()

      grdProducts.DataSource = dv
      grdProducts.DataBind()

    Catch exp As Exception
      lblError.Text = exp.Message

    End Try
  End Sub

  Private Sub grdProducts_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles grdProducts.SortCommand
    ViewState("SortField") = e.SortExpression
    GridLoad()
  End Sub
End Class
