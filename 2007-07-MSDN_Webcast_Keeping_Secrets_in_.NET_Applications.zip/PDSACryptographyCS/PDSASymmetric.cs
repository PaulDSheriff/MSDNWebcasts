using System;
using System.Security.Cryptography;
using System.Text;
using System.IO;

namespace PDSACryptographyCS
{
	/// <summary>
	/// Summary description for PDSASymmetric.
	/// </summary>
	public class PDSASymmetric
	{
    /***********************************************
      Private Variables
    ***********************************************/
    private PDSAEncryptionType mbytEncryptionType;
    private string mstrOriginalString;
    private string mstrEncryptedString;
    private SymmetricAlgorithm mCSP;

    public enum PDSAEncryptionType : byte
    {
      DES,
      RC2,
      Rijndael,
      TripleDES
    }

    #region "Constructors"
    public PDSASymmetric()
    {
      mbytEncryptionType = PDSAEncryptionType.DES;

        this.SetEncryptor();
    }

    public PDSASymmetric(PDSAEncryptionType EncryptionType)
    {
      mbytEncryptionType = EncryptionType;

      this.SetEncryptor();
    }

    public PDSASymmetric(PDSAEncryptionType EncryptionType, string OriginalString)
    {
      mbytEncryptionType = EncryptionType;
      mstrOriginalString = OriginalString;

      this.SetEncryptor();
    }
    #endregion

    #region "Public Properties"
    public PDSAEncryptionType EncryptionType
    {
      get {return mbytEncryptionType;}
      set
      {
        if (mbytEncryptionType != value) 
        {
          mbytEncryptionType = value;
          mstrOriginalString = String.Empty;
          mstrEncryptedString = String.Empty;

          this.SetEncryptor();
        }
      }
    }

    public SymmetricAlgorithm CryptoProvider
    {
      get {return mCSP;}
      set {mCSP = value;}
    }

    public string OriginalString
    {
      get {return mstrOriginalString;}
      set {mstrOriginalString = value;}
    }

    public string EncryptedString
    {
      get {return mstrEncryptedString;}
      set {mstrEncryptedString = value;}
    }

    public byte[] key
    {
      get {return mCSP.Key;}
      set {mCSP.Key = value;}
    }

    public string KeyString
    {
      get {return Convert.ToBase64String(mCSP.Key);}
      set {mCSP.Key = Convert.FromBase64String(value);}
    }

    public byte[] IV
    {
      get {return mCSP.IV;}
      set {mCSP.IV = value;}
    }

    public string IVString
    {
      get {return Convert.ToBase64String(mCSP.IV);}
      set {mCSP.IV = Convert.FromBase64String(value);}
    }
    #endregion

    #region "Encrypt() Methods"
    public string Encrypt()
    {
      ICryptoTransform ct;
      MemoryStream ms;
      CryptoStream cs;
      byte[] byt;

      ct = mCSP.CreateEncryptor(mCSP.Key, mCSP.IV);

      byt = Encoding.UTF8.GetBytes(mstrOriginalString);

      ms = new MemoryStream();
      cs = new CryptoStream(ms, ct, CryptoStreamMode.Write);
      cs.Write(byt, 0, byt.Length);
      cs.FlushFinalBlock();
      cs.Close();

      mstrEncryptedString = Convert.ToBase64String(ms.ToArray());

      return mstrEncryptedString;
    }

    public string Encrypt(string OriginalString)
    {
      mstrOriginalString = OriginalString;
      
      return this.Encrypt();
    }

    public string Encrypt(string OriginalString, PDSAEncryptionType EncryptionType)
    {
      mstrOriginalString = OriginalString;
      mbytEncryptionType = EncryptionType;

      return this.Encrypt();
    }
    #endregion

    #region "Decrypt() Methods"

    public string Decrypt()
    {
      ICryptoTransform ct;
      MemoryStream ms;
      CryptoStream cs;
      byte[] byt;

      ct = mCSP.CreateDecryptor(mCSP.Key, mCSP.IV);

      byt = Convert.FromBase64String(mstrEncryptedString);

      ms = new MemoryStream();
      cs = new CryptoStream(ms, ct, CryptoStreamMode.Write);
      cs.Write(byt, 0, byt.Length);
      cs.FlushFinalBlock();
      cs.Close();

      mstrOriginalString = Encoding.UTF8.GetString(ms.ToArray());

      return mstrOriginalString;
    }

    public string Decrypt(string EncryptedString)
    {
      mstrEncryptedString = EncryptedString;

      return this.Decrypt();
    }

    public string Decrypt(string EncryptedString, PDSAEncryptionType EncryptionType)
    {
      mstrEncryptedString = EncryptedString;
      mbytEncryptionType = EncryptionType;

      return this.Decrypt();
    }

    #endregion

    #region "SetEncryptor() Method"

    private void SetEncryptor()
    {
      switch(mbytEncryptionType)
      {
        case PDSAEncryptionType.DES:
          mCSP = new DESCryptoServiceProvider();
          break;
        case PDSAEncryptionType.RC2:
          mCSP = new RC2CryptoServiceProvider();
          break;
        case PDSAEncryptionType.Rijndael:
          mCSP = new RijndaelManaged();
          break;
        case PDSAEncryptionType.TripleDES:
          mCSP = new TripleDESCryptoServiceProvider();
          break;
      }
      
      // Generate Key
      mCSP.GenerateKey();

      // Generate IV
      mCSP.GenerateIV();
    }
    #endregion

    #region "Misc Public Methods"

    public string GenerateKey()
    {
      mCSP.GenerateKey();

      return Convert.ToBase64String(mCSP.Key);
    }

    public string GenerateIV()
    {
      mCSP.GenerateIV();

      return Convert.ToBase64String(mCSP.IV);
    }

    #endregion
  }
}
