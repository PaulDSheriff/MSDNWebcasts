Imports System.Security.Cryptography
Imports System.Text
Imports System.IO

Public Class PDSASymmetric
  '***********************************************
  ' Private Variables
  '***********************************************
  Private mbytEncryptionType As PDSAEncryptionType
  Private mstrOriginalString As String
  Private mstrEncryptedString As String
  Private mCSP As SymmetricAlgorithm

  '***********************************************
  ' Enumeration for Encryption Type
  ' NOTE: If you change the order of these enums
  ' you will need to also change the NumberToEncryption routine
  '***********************************************
  Public Enum PDSAEncryptionType As Byte
    DES
    RC2
    Rijndael
    TripleDES
  End Enum

#Region "Public Properties"
  Property EncryptionType() As PDSAEncryptionType
    Get
      Return mbytEncryptionType
    End Get
    Set(ByVal Value As PDSAEncryptionType)
      If mbytEncryptionType <> Value Then
        mbytEncryptionType = Value
        mstrOriginalString = String.Empty
        mstrEncryptedString = String.Empty

        Me.SetEncryptor()
      End If
    End Set
  End Property

  Property CryptoProvider() As SymmetricAlgorithm
    Get
      Return mCSP
    End Get
    Set(ByVal Value As SymmetricAlgorithm)
      mCSP = Value
    End Set
  End Property

  Property OriginalString() As String
    Get
      Return mstrOriginalString
    End Get
    Set(ByVal Value As String)
      mstrOriginalString = Value
    End Set
  End Property

  Property EncryptedString() As String
    Get
      Return mstrEncryptedString
    End Get
    Set(ByVal Value As String)
      mstrEncryptedString = Value
    End Set
  End Property

  Property Key() As Byte()
    Get
      Return mCSP.Key
    End Get
    Set(ByVal Value As Byte())
      mCSP.Key = Value
    End Set
  End Property

  Property KeyString() As String
    Get
      Return Convert.ToBase64String(mCSP.Key)
    End Get
    Set(ByVal Value As String)
      mCSP.Key = Convert.FromBase64String(Value)
    End Set
  End Property

  Property IV() As Byte()
    Get
      Return mCSP.IV
    End Get
    Set(ByVal Value As Byte())
      mCSP.IV = Value
    End Set
  End Property

  Property IVString() As String
    Get
      Return Convert.ToBase64String(mCSP.IV)
    End Get
    Set(ByVal Value As String)
      mCSP.IV = Convert.FromBase64String(Value)
    End Set
  End Property
#End Region

#Region "Constructors"
  Public Sub New()
    ' Hard code the default Encryption Type
    mbytEncryptionType = PDSAEncryptionType.DES

    ' Initialize the Encryptor
    Me.SetEncryptor()
  End Sub

  Public Sub New(ByVal EncryptionType As PDSAEncryptionType)
    mbytEncryptionType = EncryptionType

    ' Initialize the Encryptor
    Me.SetEncryptor()
  End Sub

  Public Sub New(ByVal EncryptionType As PDSAEncryptionType, ByVal OriginalString As String)
    mbytEncryptionType = EncryptionType
    mstrOriginalString = OriginalString

    ' Initialize the Encryptor
    Me.SetEncryptor()
  End Sub
#End Region

#Region "Encrypt() Methods"
  Public Function Encrypt() As String
    Dim ct As ICryptoTransform
    Dim ms As MemoryStream
    Dim cs As CryptoStream
    Dim byt() As Byte

    ct = mCSP.CreateEncryptor(mCSP.Key, mCSP.IV)

    byt = Encoding.UTF8.GetBytes(mstrOriginalString)

    ms = New MemoryStream
    cs = New CryptoStream(ms, ct, CryptoStreamMode.Write)
    cs.Write(byt, 0, byt.Length)
    cs.FlushFinalBlock()
    cs.Close()

    mstrEncryptedString = Convert.ToBase64String(ms.ToArray())

    Return mstrEncryptedString
  End Function

  Public Function Encrypt(ByVal OriginalString As String) As String
    mstrOriginalString = OriginalString

    Return Me.Encrypt()
  End Function

  Public Function Encrypt(ByVal OriginalString As String, ByVal EncryptionType As PDSAEncryptionType) As String
    mstrOriginalString = OriginalString
    mbytEncryptionType = EncryptionType

    Return Me.Encrypt()
  End Function
#End Region

#Region "Decrypt() Methods"
  Public Function Decrypt() As String
    Dim ct As ICryptoTransform
    Dim ms As MemoryStream
    Dim cs As CryptoStream
    Dim byt() As Byte

    ct = mCSP.CreateDecryptor(mCSP.Key, mCSP.IV)

    byt = Convert.FromBase64String(mstrEncryptedString)

    ms = New MemoryStream
    cs = New CryptoStream(ms, ct, CryptoStreamMode.Write)
    cs.Write(byt, 0, byt.Length)
    cs.FlushFinalBlock()
    cs.Close()

    mstrOriginalString = Encoding.UTF8.GetString(ms.ToArray())

    Return mstrOriginalString
  End Function

  Public Function Decrypt(ByVal EncryptedString As String) As String
    mstrEncryptedString = EncryptedString

    Return Me.Decrypt()
  End Function

  Public Function Decrypt(ByVal EncryptedString As String, ByVal EncryptionType As PDSAEncryptionType) As String
    mstrEncryptedString = EncryptedString
    mbytEncryptionType = EncryptionType

    Return Me.Decrypt()
  End Function
#End Region

#Region "Misc Public Methods"
  Public Function GenerateKey() As String
    mCSP.GenerateKey()

    Return Convert.ToBase64String(mCSP.Key)
  End Function

  Public Function GenerateIV() As String
    mCSP.GenerateIV()

    Return Convert.ToBase64String(mCSP.IV)
  End Function
#End Region

#Region "SetEncryptor Method"
  Private Sub SetEncryptor()
    Select Case mbytEncryptionType
      Case PDSAEncryptionType.DES
        mCSP = New DESCryptoServiceProvider

      Case PDSAEncryptionType.RC2
        mCSP = New RC2CryptoServiceProvider

      Case PDSAEncryptionType.Rijndael
        mCSP = New RijndaelManaged

      Case PDSAEncryptionType.TripleDES
        mCSP = New TripleDESCryptoServiceProvider

    End Select

    ' Generate Key
    mCSP.GenerateKey()

    ' Generate IV
    mCSP.GenerateIV()
  End Sub
#End Region
End Class
