Imports System.Security.Cryptography
Imports Microsoft.Win32
Imports System.Text
Imports System.IO

Imports PDSA.PDSACryptography

Public Class AppConfig
   Private Shared mstrConnectString As String

   Shared Sub New()
      Dim ph As New PDSASymmetric(PDSASymmetric.PDSAEncryptionType.DES)

      ph.KeyString = GetEncKey()
      ph.IVString = GetEncIV()
      mstrConnectString = ph.Decrypt(GetConnectString())
   End Sub

   Public Shared ReadOnly Property ConnectString() As String
      Get
         Return mstrConnectString
      End Get
   End Property

#Region "Registry Methods"
   Const CONNECTION_KEY As String = "Software\MyApp\Data"

   Private Shared Function GetRegData(ByVal Key As String, ByVal SubKey As String) As String
      Dim rk As RegistryKey

      Try
         rk = Registry.CurrentUser.OpenSubKey(Key)

         If Not (rk Is Nothing) Then
            Return rk.GetValue(SubKey).ToString()
         End If

      Catch exp As Exception

      Finally
         If Not (rk Is Nothing) Then
            rk.Close()
         End If

      End Try
   End Function

   Public Shared Function GetConnectString() As String
      Return GetRegData(CONNECTION_KEY, "EncString")
   End Function

   Public Shared Function GetEncKey() As String
      Return GetRegData(CONNECTION_KEY, "EncKey")
   End Function

   Public Shared Function GetEncIV() As String
      Return GetRegData(CONNECTION_KEY, "EncIV")
   End Function
#End Region
End Class
