Imports PDSA.PDSACryptography

Public Class frmHash
  Inherits System.Windows.Forms.Form

  Private mph As PDSAHash

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  Friend WithEvents txtOriginal As System.Windows.Forms.TextBox
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents Label4 As System.Windows.Forms.Label
  Friend WithEvents cmdHash As System.Windows.Forms.Button
  Friend WithEvents txtHashed As System.Windows.Forms.TextBox
  Friend WithEvents lstHash As System.Windows.Forms.ListBox
  Friend WithEvents Label2 As System.Windows.Forms.Label
  Friend WithEvents btnHardCoded As System.Windows.Forms.Button
  Friend WithEvents btnSalt As System.Windows.Forms.Button
  Friend WithEvents rdoSalt As System.Windows.Forms.RadioButton
  Friend WithEvents Label3 As System.Windows.Forms.Label
  Friend WithEvents txtSalt As System.Windows.Forms.TextBox
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.txtOriginal = New System.Windows.Forms.TextBox
      Me.cmdHash = New System.Windows.Forms.Button
      Me.txtHashed = New System.Windows.Forms.TextBox
      Me.Label1 = New System.Windows.Forms.Label
      Me.Label4 = New System.Windows.Forms.Label
      Me.lstHash = New System.Windows.Forms.ListBox
      Me.Label2 = New System.Windows.Forms.Label
      Me.btnHardCoded = New System.Windows.Forms.Button
      Me.btnSalt = New System.Windows.Forms.Button
      Me.rdoSalt = New System.Windows.Forms.RadioButton
      Me.Label3 = New System.Windows.Forms.Label
      Me.txtSalt = New System.Windows.Forms.TextBox
      Me.SuspendLayout()
      '
      'txtOriginal
      '
      Me.txtOriginal.Location = New System.Drawing.Point(96, 120)
      Me.txtOriginal.Multiline = True
      Me.txtOriginal.Name = "txtOriginal"
      Me.txtOriginal.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtOriginal.Size = New System.Drawing.Size(392, 64)
      Me.txtOriginal.TabIndex = 3
      Me.txtOriginal.Text = "Password"
      '
      'cmdHash
      '
      Me.cmdHash.Location = New System.Drawing.Point(96, 232)
      Me.cmdHash.Name = "cmdHash"
      Me.cmdHash.Size = New System.Drawing.Size(120, 24)
      Me.cmdHash.TabIndex = 5
      Me.cmdHash.Text = "Hash"
      '
      'txtHashed
      '
      Me.txtHashed.Location = New System.Drawing.Point(96, 264)
      Me.txtHashed.Multiline = True
      Me.txtHashed.Name = "txtHashed"
      Me.txtHashed.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtHashed.Size = New System.Drawing.Size(392, 64)
      Me.txtHashed.TabIndex = 9
      Me.txtHashed.Text = ""
      '
      'Label1
      '
      Me.Label1.Location = New System.Drawing.Point(8, 120)
      Me.Label1.Name = "Label1"
      Me.Label1.Size = New System.Drawing.Size(72, 48)
      Me.Label1.TabIndex = 2
      Me.Label1.Text = "Original String"
      '
      'Label4
      '
      Me.Label4.Location = New System.Drawing.Point(8, 272)
      Me.Label4.Name = "Label4"
      Me.Label4.Size = New System.Drawing.Size(80, 48)
      Me.Label4.TabIndex = 8
      Me.Label4.Text = "Hashed String"
      '
      'lstHash
      '
      Me.lstHash.ItemHeight = 20
      Me.lstHash.Location = New System.Drawing.Point(96, 8)
      Me.lstHash.Name = "lstHash"
      Me.lstHash.Size = New System.Drawing.Size(280, 104)
      Me.lstHash.TabIndex = 1
      '
      'Label2
      '
      Me.Label2.Location = New System.Drawing.Point(8, 8)
      Me.Label2.Name = "Label2"
      Me.Label2.Size = New System.Drawing.Size(80, 72)
      Me.Label2.TabIndex = 0
      Me.Label2.Text = "Choose Hash Algorithm"
      '
      'btnHardCoded
      '
      Me.btnHardCoded.Location = New System.Drawing.Point(296, 232)
      Me.btnHardCoded.Name = "btnHardCoded"
      Me.btnHardCoded.Size = New System.Drawing.Size(192, 24)
      Me.btnHardCoded.TabIndex = 7
      Me.btnHardCoded.Text = "Hard Coded Sample"
      '
      'btnSalt
      '
      Me.btnSalt.Location = New System.Drawing.Point(296, 200)
      Me.btnSalt.Name = "btnSalt"
      Me.btnSalt.Size = New System.Drawing.Size(192, 24)
      Me.btnSalt.TabIndex = 6
      Me.btnSalt.Text = "Create Salt"
      '
      'rdoSalt
      '
      Me.rdoSalt.Location = New System.Drawing.Point(96, 200)
      Me.rdoSalt.Name = "rdoSalt"
      Me.rdoSalt.Size = New System.Drawing.Size(120, 24)
      Me.rdoSalt.TabIndex = 4
      Me.rdoSalt.Text = "Use Salt"
      '
      'Label3
      '
      Me.Label3.Location = New System.Drawing.Point(8, 336)
      Me.Label3.Name = "Label3"
      Me.Label3.Size = New System.Drawing.Size(88, 24)
      Me.Label3.TabIndex = 10
      Me.Label3.Text = "Salt Value"
      '
      'txtSalt
      '
      Me.txtSalt.Location = New System.Drawing.Point(96, 336)
      Me.txtSalt.Name = "txtSalt"
      Me.txtSalt.Size = New System.Drawing.Size(392, 26)
      Me.txtSalt.TabIndex = 11
      Me.txtSalt.Text = ""
      '
      'frmHash
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
      Me.ClientSize = New System.Drawing.Size(496, 370)
      Me.Controls.Add(Me.Label3)
      Me.Controls.Add(Me.txtSalt)
      Me.Controls.Add(Me.rdoSalt)
      Me.Controls.Add(Me.btnSalt)
      Me.Controls.Add(Me.btnHardCoded)
      Me.Controls.Add(Me.Label2)
      Me.Controls.Add(Me.lstHash)
      Me.Controls.Add(Me.Label4)
      Me.Controls.Add(Me.Label1)
      Me.Controls.Add(Me.txtHashed)
      Me.Controls.Add(Me.txtOriginal)
      Me.Controls.Add(Me.cmdHash)
      Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.Name = "frmHash"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
      Me.Text = "Hashing"
      Me.ResumeLayout(False)

   End Sub

#End Region

  Private Sub cmdHash_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHash.Click
    txtHashed.Text = mph.CreateHash(txtOriginal.Text, rdoSalt.Checked)
    txtSalt.Text = mph.SaltValue
  End Sub

  Private Sub frmHash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    lstHash.DataSource = _
     System.Enum.GetValues(GetType(PDSAHash.PDSAHashType))

    mph = New PDSAHash
  End Sub

  Private Sub lstHash_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstHash.SelectedIndexChanged
    ' Clear all Hash Properties
    mph.Reset()
    ' Set the Hash Type
    mph.HashType = CType(lstHash.SelectedIndex, PDSA.PDSACryptography.PDSAHash.PDSAHashType)
    ' Reset Controls
    rdoSalt.Checked = False
    txtHashed.Text = String.Empty
    txtSalt.Text = String.Empty
  End Sub

  Private Sub btnHardCoded_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHardCoded.Click
    Dim ph As New PDSAHash(PDSAHash.PDSAHashType.MD5)

    MessageBox.Show(ph.CreateHash("Password"))
  End Sub

  Private Sub btnSalt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalt.Click
    Dim ph As New PDSAHash(PDSAHash.PDSAHashType.MD5)

    MessageBox.Show(ph.CreateSalt())
  End Sub

End Class
