Imports PDSA.PDSACryptography

Public Class frmEncrypt
  Inherits System.Windows.Forms.Form

  Private mph As PDSASymmetric

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  Friend WithEvents cmdEncrypt As System.Windows.Forms.Button
  Friend WithEvents cmdDecrypt As System.Windows.Forms.Button
  Friend WithEvents txtKey As System.Windows.Forms.TextBox
  Friend WithEvents Label2 As System.Windows.Forms.Label
  Friend WithEvents Label3 As System.Windows.Forms.Label
  Friend WithEvents btnKeyGen As System.Windows.Forms.Button
  Friend WithEvents btnIVGen As System.Windows.Forms.Button
  Friend WithEvents txtIV As System.Windows.Forms.TextBox
  Friend WithEvents txtOriginal As System.Windows.Forms.TextBox
  Friend WithEvents txtEncrypted As System.Windows.Forms.TextBox
  Friend WithEvents Label4 As System.Windows.Forms.Label
  Friend WithEvents Label5 As System.Windows.Forms.Label
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents lstEncryption As System.Windows.Forms.ListBox
  Friend WithEvents btnHardCoded As System.Windows.Forms.Button
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.txtOriginal = New System.Windows.Forms.TextBox
      Me.cmdEncrypt = New System.Windows.Forms.Button
      Me.cmdDecrypt = New System.Windows.Forms.Button
      Me.txtKey = New System.Windows.Forms.TextBox
      Me.Label2 = New System.Windows.Forms.Label
      Me.Label3 = New System.Windows.Forms.Label
      Me.txtIV = New System.Windows.Forms.TextBox
      Me.btnKeyGen = New System.Windows.Forms.Button
      Me.btnIVGen = New System.Windows.Forms.Button
      Me.txtEncrypted = New System.Windows.Forms.TextBox
      Me.Label4 = New System.Windows.Forms.Label
      Me.Label5 = New System.Windows.Forms.Label
      Me.Label1 = New System.Windows.Forms.Label
      Me.lstEncryption = New System.Windows.Forms.ListBox
      Me.btnHardCoded = New System.Windows.Forms.Button
      Me.SuspendLayout()
      '
      'txtOriginal
      '
      Me.txtOriginal.Location = New System.Drawing.Point(104, 184)
      Me.txtOriginal.Multiline = True
      Me.txtOriginal.Name = "txtOriginal"
      Me.txtOriginal.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtOriginal.Size = New System.Drawing.Size(384, 64)
      Me.txtOriginal.TabIndex = 9
      Me.txtOriginal.Text = "Server=localhost;Database=Northwind;UID=sa;PWD=sa"
      '
      'cmdEncrypt
      '
      Me.cmdEncrypt.Location = New System.Drawing.Point(104, 256)
      Me.cmdEncrypt.Name = "cmdEncrypt"
      Me.cmdEncrypt.Size = New System.Drawing.Size(120, 24)
      Me.cmdEncrypt.TabIndex = 10
      Me.cmdEncrypt.Text = "Encrypt"
      '
      'cmdDecrypt
      '
      Me.cmdDecrypt.Location = New System.Drawing.Point(232, 256)
      Me.cmdDecrypt.Name = "cmdDecrypt"
      Me.cmdDecrypt.Size = New System.Drawing.Size(120, 24)
      Me.cmdDecrypt.TabIndex = 11
      Me.cmdDecrypt.Text = "Decrypt"
      '
      'txtKey
      '
      Me.txtKey.Location = New System.Drawing.Point(104, 120)
      Me.txtKey.Name = "txtKey"
      Me.txtKey.Size = New System.Drawing.Size(280, 26)
      Me.txtKey.TabIndex = 3
      Me.txtKey.Text = ""
      '
      'Label2
      '
      Me.Label2.Location = New System.Drawing.Point(8, 128)
      Me.Label2.Name = "Label2"
      Me.Label2.Size = New System.Drawing.Size(72, 16)
      Me.Label2.TabIndex = 2
      Me.Label2.Text = "Key"
      '
      'Label3
      '
      Me.Label3.Location = New System.Drawing.Point(8, 152)
      Me.Label3.Name = "Label3"
      Me.Label3.Size = New System.Drawing.Size(48, 16)
      Me.Label3.TabIndex = 5
      Me.Label3.Text = "IV"
      '
      'txtIV
      '
      Me.txtIV.Location = New System.Drawing.Point(104, 152)
      Me.txtIV.Name = "txtIV"
      Me.txtIV.Size = New System.Drawing.Size(280, 26)
      Me.txtIV.TabIndex = 6
      Me.txtIV.Text = ""
      '
      'btnKeyGen
      '
      Me.btnKeyGen.Location = New System.Drawing.Point(392, 120)
      Me.btnKeyGen.Name = "btnKeyGen"
      Me.btnKeyGen.Size = New System.Drawing.Size(96, 24)
      Me.btnKeyGen.TabIndex = 4
      Me.btnKeyGen.Text = "Gen Key"
      '
      'btnIVGen
      '
      Me.btnIVGen.Location = New System.Drawing.Point(392, 152)
      Me.btnIVGen.Name = "btnIVGen"
      Me.btnIVGen.Size = New System.Drawing.Size(96, 24)
      Me.btnIVGen.TabIndex = 7
      Me.btnIVGen.Text = "Gen IV"
      '
      'txtEncrypted
      '
      Me.txtEncrypted.Location = New System.Drawing.Point(104, 288)
      Me.txtEncrypted.Multiline = True
      Me.txtEncrypted.Name = "txtEncrypted"
      Me.txtEncrypted.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtEncrypted.Size = New System.Drawing.Size(384, 64)
      Me.txtEncrypted.TabIndex = 14
      Me.txtEncrypted.Text = ""
      '
      'Label4
      '
      Me.Label4.Location = New System.Drawing.Point(8, 184)
      Me.Label4.Name = "Label4"
      Me.Label4.Size = New System.Drawing.Size(80, 40)
      Me.Label4.TabIndex = 8
      Me.Label4.Text = "Original String"
      '
      'Label5
      '
      Me.Label5.Location = New System.Drawing.Point(8, 280)
      Me.Label5.Name = "Label5"
      Me.Label5.Size = New System.Drawing.Size(88, 48)
      Me.Label5.TabIndex = 13
      Me.Label5.Text = "Encrypted String"
      '
      'Label1
      '
      Me.Label1.Location = New System.Drawing.Point(8, 8)
      Me.Label1.Name = "Label1"
      Me.Label1.Size = New System.Drawing.Size(88, 64)
      Me.Label1.TabIndex = 0
      Me.Label1.Text = "Choose Encryption Algorithm"
      '
      'lstEncryption
      '
      Me.lstEncryption.ItemHeight = 20
      Me.lstEncryption.Location = New System.Drawing.Point(104, 8)
      Me.lstEncryption.Name = "lstEncryption"
      Me.lstEncryption.Size = New System.Drawing.Size(280, 104)
      Me.lstEncryption.TabIndex = 1
      '
      'btnHardCoded
      '
      Me.btnHardCoded.Location = New System.Drawing.Point(368, 256)
      Me.btnHardCoded.Name = "btnHardCoded"
      Me.btnHardCoded.Size = New System.Drawing.Size(120, 24)
      Me.btnHardCoded.TabIndex = 12
      Me.btnHardCoded.Text = "Hard Coded"
      '
      'frmEncrypt
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
      Me.ClientSize = New System.Drawing.Size(496, 354)
      Me.Controls.Add(Me.btnHardCoded)
      Me.Controls.Add(Me.Label1)
      Me.Controls.Add(Me.lstEncryption)
      Me.Controls.Add(Me.Label5)
      Me.Controls.Add(Me.Label4)
      Me.Controls.Add(Me.txtEncrypted)
      Me.Controls.Add(Me.txtIV)
      Me.Controls.Add(Me.txtKey)
      Me.Controls.Add(Me.txtOriginal)
      Me.Controls.Add(Me.btnIVGen)
      Me.Controls.Add(Me.btnKeyGen)
      Me.Controls.Add(Me.Label3)
      Me.Controls.Add(Me.Label2)
      Me.Controls.Add(Me.cmdDecrypt)
      Me.Controls.Add(Me.cmdEncrypt)
      Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.Name = "frmEncrypt"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
      Me.Text = "Encryption"
      Me.ResumeLayout(False)

   End Sub

#End Region

  Private Sub cmdEncrypt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdEncrypt.Click
    txtEncrypted.Text = mph.Encrypt(txtOriginal.Text)
    txtKey.Text = mph.KeyString
    txtIV.Text = mph.IVString
  End Sub

  Private Sub cmdDecrypt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDecrypt.Click
    txtOriginal.Text = mph.Decrypt(txtEncrypted.Text)
  End Sub

  Private Sub btnKeyGen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeyGen.Click
    mph.GenerateKey()

    txtKey.Text = mph.KeyString
  End Sub

  Private Sub btnIVGen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIVGen.Click
    mph.GenerateIV()

    txtIV.Text = mph.IVString
  End Sub

  Private Sub frmEncrypt_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    lstEncryption.DataSource = System.Enum.GetValues(GetType(PDSASymmetric.PDSAEncryptionType))

    mph = New PDSASymmetric
  End Sub

  Private Sub lstEncryption_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstEncryption.SelectedIndexChanged
    mph.EncryptionType = CType(lstEncryption.SelectedIndex, PDSA.PDSACryptography.PDSASymmetric.PDSAEncryptionType)
    txtEncrypted.Text = String.Empty
    txtKey.Text = String.Empty
    txtIV.Text = String.Empty
  End Sub

  Private Sub btnHardCoded_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHardCoded.Click
    Dim ps As New PDSASymmetric(PDSASymmetric.PDSAEncryptionType.TripleDES)

    MessageBox.Show(ps.Encrypt("Server=localhost;Database=Northwind;uid=sa;pwd=sa"))
  End Sub
End Class
