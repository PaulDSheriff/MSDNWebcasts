using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PDSACryptoSampleCS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
    internal System.Windows.Forms.Button btnEncrypt;
    internal System.Windows.Forms.Button btnHash;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.btnEncrypt = new System.Windows.Forms.Button();
      this.btnHash = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // btnEncrypt
      // 
      this.btnEncrypt.Location = new System.Drawing.Point(144, 8);
      this.btnEncrypt.Name = "btnEncrypt";
      this.btnEncrypt.Size = new System.Drawing.Size(136, 80);
      this.btnEncrypt.TabIndex = 1;
      this.btnEncrypt.Text = "Encryption and Decryption";
      this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
      // 
      // btnHash
      // 
      this.btnHash.Location = new System.Drawing.Point(8, 8);
      this.btnHash.Name = "btnHash";
      this.btnHash.Size = new System.Drawing.Size(128, 80);
      this.btnHash.TabIndex = 0;
      this.btnHash.Text = "Hashing";
      this.btnHash.Click += new System.EventHandler(this.btnHash_Click);
      // 
      // frmMain
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
      this.ClientSize = new System.Drawing.Size(288, 90);
      this.Controls.Add(this.btnEncrypt);
      this.Controls.Add(this.btnHash);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "frmMain";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Crypto Samples";
      this.ResumeLayout(false);

    }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

    private void btnHash_Click(object sender, System.EventArgs e)
    {
      frmHash frm;

      this.Cursor = Cursors.WaitCursor;
      frm = new frmHash();

      frm.Show();
      this.Cursor = Cursors.Default;
    }

    private void btnEncrypt_Click(object sender, System.EventArgs e)
    {
      frmEncrypt frm;

      this.Cursor = Cursors.WaitCursor;
      frm = new frmEncrypt();

      frm.Show();
      this.Cursor = Cursors.Default;
    }
	}
}
