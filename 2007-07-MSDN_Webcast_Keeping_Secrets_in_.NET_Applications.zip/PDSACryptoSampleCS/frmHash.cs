using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using PDSACryptographyCS;

namespace PDSACryptoSampleCS
{
	/// <summary>
	/// Summary description for frmHash.
	/// </summary>
	public class frmHash : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label Label3;
    internal System.Windows.Forms.TextBox txtSalt;
    internal System.Windows.Forms.RadioButton rdoSalt;
    internal System.Windows.Forms.Button btnSalt;
    internal System.Windows.Forms.Button btnHardCoded;
    internal System.Windows.Forms.Label Label2;
    internal System.Windows.Forms.ListBox lstHash;
    internal System.Windows.Forms.Label Label4;
    internal System.Windows.Forms.Label Label1;
    internal System.Windows.Forms.TextBox txtHashed;
    internal System.Windows.Forms.TextBox txtOriginal;
    internal System.Windows.Forms.Button cmdHash;

    private PDSAHash mph;

		public frmHash()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.Label3 = new System.Windows.Forms.Label();
      this.txtSalt = new System.Windows.Forms.TextBox();
      this.rdoSalt = new System.Windows.Forms.RadioButton();
      this.btnSalt = new System.Windows.Forms.Button();
      this.btnHardCoded = new System.Windows.Forms.Button();
      this.Label2 = new System.Windows.Forms.Label();
      this.lstHash = new System.Windows.Forms.ListBox();
      this.Label4 = new System.Windows.Forms.Label();
      this.Label1 = new System.Windows.Forms.Label();
      this.txtHashed = new System.Windows.Forms.TextBox();
      this.txtOriginal = new System.Windows.Forms.TextBox();
      this.cmdHash = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // Label3
      // 
      this.Label3.Location = new System.Drawing.Point(8, 336);
      this.Label3.Name = "Label3";
      this.Label3.Size = new System.Drawing.Size(88, 24);
      this.Label3.TabIndex = 10;
      this.Label3.Text = "Salt Value";
      // 
      // txtSalt
      // 
      this.txtSalt.Location = new System.Drawing.Point(96, 336);
      this.txtSalt.Name = "txtSalt";
      this.txtSalt.Size = new System.Drawing.Size(392, 26);
      this.txtSalt.TabIndex = 11;
      this.txtSalt.Text = "";
      // 
      // rdoSalt
      // 
      this.rdoSalt.Location = new System.Drawing.Point(96, 200);
      this.rdoSalt.Name = "rdoSalt";
      this.rdoSalt.Size = new System.Drawing.Size(120, 24);
      this.rdoSalt.TabIndex = 4;
      this.rdoSalt.Text = "Use Salt";
      // 
      // btnSalt
      // 
      this.btnSalt.Location = new System.Drawing.Point(296, 200);
      this.btnSalt.Name = "btnSalt";
      this.btnSalt.Size = new System.Drawing.Size(192, 24);
      this.btnSalt.TabIndex = 6;
      this.btnSalt.Text = "Create Salt";
      this.btnSalt.Click += new System.EventHandler(this.btnSalt_Click);
      // 
      // btnHardCoded
      // 
      this.btnHardCoded.Location = new System.Drawing.Point(296, 232);
      this.btnHardCoded.Name = "btnHardCoded";
      this.btnHardCoded.Size = new System.Drawing.Size(192, 24);
      this.btnHardCoded.TabIndex = 7;
      this.btnHardCoded.Text = "Hard Coded Sample";
      this.btnHardCoded.Click += new System.EventHandler(this.btnHardCoded_Click);
      // 
      // Label2
      // 
      this.Label2.Location = new System.Drawing.Point(8, 8);
      this.Label2.Name = "Label2";
      this.Label2.Size = new System.Drawing.Size(80, 72);
      this.Label2.TabIndex = 0;
      this.Label2.Text = "Choose Hash Algorithm";
      // 
      // lstHash
      // 
      this.lstHash.ItemHeight = 20;
      this.lstHash.Location = new System.Drawing.Point(96, 8);
      this.lstHash.Name = "lstHash";
      this.lstHash.Size = new System.Drawing.Size(280, 104);
      this.lstHash.TabIndex = 1;
      this.lstHash.SelectedIndexChanged += new System.EventHandler(this.lstHash_SelectedIndexChanged);
      // 
      // Label4
      // 
      this.Label4.Location = new System.Drawing.Point(8, 272);
      this.Label4.Name = "Label4";
      this.Label4.Size = new System.Drawing.Size(80, 48);
      this.Label4.TabIndex = 8;
      this.Label4.Text = "Hashed String";
      // 
      // Label1
      // 
      this.Label1.Location = new System.Drawing.Point(8, 120);
      this.Label1.Name = "Label1";
      this.Label1.Size = new System.Drawing.Size(72, 48);
      this.Label1.TabIndex = 2;
      this.Label1.Text = "Original String";
      // 
      // txtHashed
      // 
      this.txtHashed.Location = new System.Drawing.Point(96, 264);
      this.txtHashed.Multiline = true;
      this.txtHashed.Name = "txtHashed";
      this.txtHashed.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtHashed.Size = new System.Drawing.Size(392, 64);
      this.txtHashed.TabIndex = 9;
      this.txtHashed.Text = "";
      // 
      // txtOriginal
      // 
      this.txtOriginal.Location = new System.Drawing.Point(96, 120);
      this.txtOriginal.Multiline = true;
      this.txtOriginal.Name = "txtOriginal";
      this.txtOriginal.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtOriginal.Size = new System.Drawing.Size(392, 64);
      this.txtOriginal.TabIndex = 3;
      this.txtOriginal.Text = "Password";
      // 
      // cmdHash
      // 
      this.cmdHash.Location = new System.Drawing.Point(96, 232);
      this.cmdHash.Name = "cmdHash";
      this.cmdHash.Size = new System.Drawing.Size(120, 24);
      this.cmdHash.TabIndex = 5;
      this.cmdHash.Text = "Hash";
      this.cmdHash.Click += new System.EventHandler(this.cmdHash_Click);
      // 
      // frmHash
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
      this.ClientSize = new System.Drawing.Size(496, 370);
      this.Controls.Add(this.Label3);
      this.Controls.Add(this.txtSalt);
      this.Controls.Add(this.rdoSalt);
      this.Controls.Add(this.btnSalt);
      this.Controls.Add(this.btnHardCoded);
      this.Controls.Add(this.Label2);
      this.Controls.Add(this.lstHash);
      this.Controls.Add(this.Label4);
      this.Controls.Add(this.Label1);
      this.Controls.Add(this.txtHashed);
      this.Controls.Add(this.txtOriginal);
      this.Controls.Add(this.cmdHash);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "frmHash";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Hashing";
      this.Load += new System.EventHandler(this.frmHash_Load);
      this.ResumeLayout(false);

    }
		#endregion

    private void frmHash_Load(object sender, System.EventArgs e)
    {
     lstHash.DataSource = 
       System.Enum.GetValues(typeof(PDSAHash.PDSAHashType));

      mph = new PDSAHash();
    }

    private void cmdHash_Click(object sender, System.EventArgs e)
    {
      txtHashed.Text = mph.CreateHash(txtOriginal.Text, rdoSalt.Checked);
      txtSalt.Text = mph.SaltValue;
    }

    private void lstHash_SelectedIndexChanged(object sender, System.EventArgs e)
    {
      // Reset all Hash Variables
      mph.Reset();
      // Set new Hash algorithm
      mph.HashType = (PDSAHash.PDSAHashType) lstHash.SelectedIndex;
      // Reset controls
      rdoSalt.Checked = false;
      txtHashed.Text = String.Empty;
      txtSalt.Text = String.Empty;
    }

    private void btnSalt_Click(object sender, System.EventArgs e)
    {
     PDSAHash ph = new PDSAHash(PDSAHash.PDSAHashType.MD5);

     MessageBox.Show(ph.CreateSalt());
    }

    private void btnHardCoded_Click(object sender, System.EventArgs e)
    {
      PDSAHash ph = new PDSAHash(PDSAHash.PDSAHashType.MD5);

      MessageBox.Show(ph.CreateHash("Password"));
    }
	}
}
