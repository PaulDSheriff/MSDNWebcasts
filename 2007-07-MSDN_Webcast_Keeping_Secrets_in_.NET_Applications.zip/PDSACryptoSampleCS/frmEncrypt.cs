using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using PDSACryptographyCS;

namespace PDSACryptoSampleCS
{
	/// <summary>
	/// Summary description for frmEncrypt.
	/// </summary>
	public class frmEncrypt : System.Windows.Forms.Form
	{
    internal System.Windows.Forms.Label Label1;
    internal System.Windows.Forms.ListBox lstEncryption;
    internal System.Windows.Forms.Label Label5;
    internal System.Windows.Forms.Label Label4;
    internal System.Windows.Forms.TextBox txtEncrypted;
    internal System.Windows.Forms.TextBox txtIV;
    internal System.Windows.Forms.TextBox txtKey;
    internal System.Windows.Forms.TextBox txtOriginal;
    internal System.Windows.Forms.Button btnIVGen;
    internal System.Windows.Forms.Button btnKeyGen;
    internal System.Windows.Forms.Label Label3;
    internal System.Windows.Forms.Label Label2;
    internal System.Windows.Forms.Button cmdDecrypt;
    internal System.Windows.Forms.Button cmdEncrypt;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button btnHardCoded;

    PDSASymmetric mph;

		public frmEncrypt()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.Label1 = new System.Windows.Forms.Label();
      this.lstEncryption = new System.Windows.Forms.ListBox();
      this.Label5 = new System.Windows.Forms.Label();
      this.Label4 = new System.Windows.Forms.Label();
      this.txtEncrypted = new System.Windows.Forms.TextBox();
      this.txtIV = new System.Windows.Forms.TextBox();
      this.txtKey = new System.Windows.Forms.TextBox();
      this.txtOriginal = new System.Windows.Forms.TextBox();
      this.btnIVGen = new System.Windows.Forms.Button();
      this.btnKeyGen = new System.Windows.Forms.Button();
      this.Label3 = new System.Windows.Forms.Label();
      this.Label2 = new System.Windows.Forms.Label();
      this.cmdDecrypt = new System.Windows.Forms.Button();
      this.cmdEncrypt = new System.Windows.Forms.Button();
      this.btnHardCoded = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // Label1
      // 
      this.Label1.Location = new System.Drawing.Point(8, 8);
      this.Label1.Name = "Label1";
      this.Label1.Size = new System.Drawing.Size(88, 64);
      this.Label1.TabIndex = 0;
      this.Label1.Text = "Choose Encryption Algorithm";
      // 
      // lstEncryption
      // 
      this.lstEncryption.ItemHeight = 20;
      this.lstEncryption.Location = new System.Drawing.Point(104, 8);
      this.lstEncryption.Name = "lstEncryption";
      this.lstEncryption.Size = new System.Drawing.Size(280, 104);
      this.lstEncryption.TabIndex = 1;
      this.lstEncryption.SelectedIndexChanged += new System.EventHandler(this.lstEncryption_SelectedIndexChanged);
      // 
      // Label5
      // 
      this.Label5.Location = new System.Drawing.Point(8, 280);
      this.Label5.Name = "Label5";
      this.Label5.Size = new System.Drawing.Size(88, 48);
      this.Label5.TabIndex = 12;
      this.Label5.Text = "Encrypted String";
      // 
      // Label4
      // 
      this.Label4.Location = new System.Drawing.Point(8, 184);
      this.Label4.Name = "Label4";
      this.Label4.Size = new System.Drawing.Size(80, 40);
      this.Label4.TabIndex = 8;
      this.Label4.Text = "Original String";
      // 
      // txtEncrypted
      // 
      this.txtEncrypted.Location = new System.Drawing.Point(104, 288);
      this.txtEncrypted.Multiline = true;
      this.txtEncrypted.Name = "txtEncrypted";
      this.txtEncrypted.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtEncrypted.Size = new System.Drawing.Size(384, 64);
      this.txtEncrypted.TabIndex = 13;
      this.txtEncrypted.Text = "";
      // 
      // txtIV
      // 
      this.txtIV.Location = new System.Drawing.Point(104, 152);
      this.txtIV.Name = "txtIV";
      this.txtIV.Size = new System.Drawing.Size(280, 26);
      this.txtIV.TabIndex = 6;
      this.txtIV.Text = "";
      // 
      // txtKey
      // 
      this.txtKey.Location = new System.Drawing.Point(104, 120);
      this.txtKey.Name = "txtKey";
      this.txtKey.Size = new System.Drawing.Size(280, 26);
      this.txtKey.TabIndex = 3;
      this.txtKey.Text = "";
      // 
      // txtOriginal
      // 
      this.txtOriginal.Location = new System.Drawing.Point(104, 184);
      this.txtOriginal.Multiline = true;
      this.txtOriginal.Name = "txtOriginal";
      this.txtOriginal.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtOriginal.Size = new System.Drawing.Size(384, 64);
      this.txtOriginal.TabIndex = 9;
      this.txtOriginal.Text = "Server=localhost;Database=Northwind;UID=sa;PWD=sa";
      // 
      // btnIVGen
      // 
      this.btnIVGen.Location = new System.Drawing.Point(392, 152);
      this.btnIVGen.Name = "btnIVGen";
      this.btnIVGen.Size = new System.Drawing.Size(96, 24);
      this.btnIVGen.TabIndex = 7;
      this.btnIVGen.Text = "Gen IV";
      this.btnIVGen.Click += new System.EventHandler(this.btnIVGen_Click);
      // 
      // btnKeyGen
      // 
      this.btnKeyGen.Location = new System.Drawing.Point(392, 120);
      this.btnKeyGen.Name = "btnKeyGen";
      this.btnKeyGen.Size = new System.Drawing.Size(96, 24);
      this.btnKeyGen.TabIndex = 4;
      this.btnKeyGen.Text = "Gen Key";
      this.btnKeyGen.Click += new System.EventHandler(this.btnKeyGen_Click);
      // 
      // Label3
      // 
      this.Label3.Location = new System.Drawing.Point(8, 152);
      this.Label3.Name = "Label3";
      this.Label3.Size = new System.Drawing.Size(48, 16);
      this.Label3.TabIndex = 5;
      this.Label3.Text = "IV";
      // 
      // Label2
      // 
      this.Label2.Location = new System.Drawing.Point(8, 128);
      this.Label2.Name = "Label2";
      this.Label2.Size = new System.Drawing.Size(72, 16);
      this.Label2.TabIndex = 2;
      this.Label2.Text = "Key";
      // 
      // cmdDecrypt
      // 
      this.cmdDecrypt.Location = new System.Drawing.Point(240, 256);
      this.cmdDecrypt.Name = "cmdDecrypt";
      this.cmdDecrypt.Size = new System.Drawing.Size(120, 24);
      this.cmdDecrypt.TabIndex = 11;
      this.cmdDecrypt.Text = "Decrypt";
      this.cmdDecrypt.Click += new System.EventHandler(this.cmdDecrypt_Click);
      // 
      // cmdEncrypt
      // 
      this.cmdEncrypt.Location = new System.Drawing.Point(104, 256);
      this.cmdEncrypt.Name = "cmdEncrypt";
      this.cmdEncrypt.Size = new System.Drawing.Size(120, 24);
      this.cmdEncrypt.TabIndex = 10;
      this.cmdEncrypt.Text = "Encrypt";
      this.cmdEncrypt.Click += new System.EventHandler(this.cmdEncrypt_Click);
      // 
      // btnHardCoded
      // 
      this.btnHardCoded.Location = new System.Drawing.Point(368, 256);
      this.btnHardCoded.Name = "btnHardCoded";
      this.btnHardCoded.Size = new System.Drawing.Size(120, 24);
      this.btnHardCoded.TabIndex = 14;
      this.btnHardCoded.Text = "Hard Coded";
      this.btnHardCoded.Click += new System.EventHandler(this.btnHardCoded_Click);
      // 
      // frmEncrypt
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
      this.ClientSize = new System.Drawing.Size(496, 354);
      this.Controls.Add(this.btnHardCoded);
      this.Controls.Add(this.Label1);
      this.Controls.Add(this.lstEncryption);
      this.Controls.Add(this.Label5);
      this.Controls.Add(this.Label4);
      this.Controls.Add(this.txtEncrypted);
      this.Controls.Add(this.txtIV);
      this.Controls.Add(this.txtKey);
      this.Controls.Add(this.txtOriginal);
      this.Controls.Add(this.btnIVGen);
      this.Controls.Add(this.btnKeyGen);
      this.Controls.Add(this.Label3);
      this.Controls.Add(this.Label2);
      this.Controls.Add(this.cmdDecrypt);
      this.Controls.Add(this.cmdEncrypt);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "frmEncrypt";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Encryption";
      this.Load += new System.EventHandler(this.frmEncrypt_Load);
      this.ResumeLayout(false);

    }
		#endregion

    private void btnKeyGen_Click(object sender, System.EventArgs e)
    {
      mph.GenerateKey();

      txtKey.Text = mph.KeyString;
    }

    private void btnIVGen_Click(object sender, System.EventArgs e)
    {
      mph.GenerateIV();

      txtIV.Text = mph.IVString;
    }

    private void frmEncrypt_Load(object sender, System.EventArgs e)
    {
      lstEncryption.DataSource = System.Enum.GetValues(typeof(PDSASymmetric.PDSAEncryptionType));

      mph = new PDSASymmetric();
    }

    private void cmdEncrypt_Click(object sender, System.EventArgs e)
    {
      txtEncrypted.Text = mph.Encrypt(txtOriginal.Text);
      txtKey.Text = mph.KeyString;
      txtIV.Text = mph.IVString;
    }

    private void cmdDecrypt_Click(object sender, System.EventArgs e)
    {
      txtOriginal.Text = mph.Decrypt(txtEncrypted.Text);
    }

    private void lstEncryption_SelectedIndexChanged(object sender, System.EventArgs e)
    {
      mph.EncryptionType = (PDSASymmetric.PDSAEncryptionType) lstEncryption.SelectedIndex;
      txtEncrypted.Text = String.Empty;
      txtKey.Text = String.Empty;
      txtIV.Text = String.Empty;
    }

    private void btnHardCoded_Click(object sender, System.EventArgs e)
    {
      PDSASymmetric ps = new PDSASymmetric(PDSASymmetric.PDSAEncryptionType.TripleDES);

      MessageBox.Show(ps.Encrypt("Server=localhost;Database=Northwind;uid=sa;pwd=sa"));
    }
	}
}
