using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using System.Security.Cryptography;
using System.IO;
using System.Text;

namespace CryptoSampleCS
{
/// <summary>
/// Summary description for frmEncrypt.
/// </summary>
public class frmEncrypt : System.Windows.Forms.Form
{
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public frmEncrypt()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	internal System.Windows.Forms.GroupBox GroupBox1;
	internal System.Windows.Forms.RadioButton optTripleDES;
	internal System.Windows.Forms.RadioButton optDES;
	internal System.Windows.Forms.Label Label5;
	internal System.Windows.Forms.Label Label4;
	internal System.Windows.Forms.TextBox txtEncrypted;
	internal System.Windows.Forms.TextBox txtIV;
	internal System.Windows.Forms.TextBox txtKey;
	internal System.Windows.Forms.TextBox txtOriginal;
	internal System.Windows.Forms.Button btnIVGen;
	internal System.Windows.Forms.Button btnKeyGen;
	internal System.Windows.Forms.Label Label3;
	internal System.Windows.Forms.Label Label2;
	internal System.Windows.Forms.Button cmdDecrypt;
	internal System.Windows.Forms.Button cmdEncrypt;

	// Private Variables for this Form
	private SymmetricAlgorithm mCSP;

	private void cmdEncrypt_Click(object sender, System.EventArgs e)
	{
		txtEncrypted.Text = EncryptString(txtOriginal.Text);
	}

	private void cmdDecrypt_Click(object sender, System.EventArgs e)
	{
		txtOriginal.Text = DecryptString(txtEncrypted.Text);
	}

	private void btnKeyGen_Click(object sender, System.EventArgs e)
	{
		mCSP = SetEnc();

		mCSP.GenerateKey();

		txtKey.Text = Convert.ToBase64String(mCSP.Key);
	}

	private void btnIVGen_Click(object sender, System.EventArgs e)
	{
		mCSP.GenerateIV();

		txtIV.Text = Convert.ToBase64String(mCSP.IV);
	}

	private string EncryptString(string Value)
	{
		ICryptoTransform ct;
		MemoryStream ms;
		CryptoStream cs;
		byte[] byt;

	  ct = mCSP.CreateEncryptor(mCSP.Key, mCSP.IV);

	  byt = Encoding.UTF8.GetBytes(Value);

	  ms = new MemoryStream();
	  cs = new CryptoStream(ms, ct, CryptoStreamMode.Write);
	  cs.Write(byt, 0, byt.Length);
	  cs.FlushFinalBlock();
	
		cs.Close();

		return Convert.ToBase64String(ms.ToArray());
	}

	private string DecryptString(string Value)
	{
		ICryptoTransform ct;
    MemoryStream ms;
    CryptoStream cs;
    byte[] byt;

    ct = mCSP.CreateDecryptor(mCSP.Key, mCSP.IV);

    byt = Convert.FromBase64String(Value);

    ms = new MemoryStream();
    cs = new CryptoStream(ms, ct, CryptoStreamMode.Write);
    cs.Write(byt, 0, byt.Length);
    cs.FlushFinalBlock();

    cs.Close();

    return Encoding.UTF8.GetString(ms.ToArray());
	}

	private SymmetricAlgorithm SetEnc()
	{
		if(optDES.Checked)
			return new DESCryptoServiceProvider();
		else
			return new TripleDESCryptoServiceProvider();
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
    this.GroupBox1 = new System.Windows.Forms.GroupBox();
    this.optTripleDES = new System.Windows.Forms.RadioButton();
    this.optDES = new System.Windows.Forms.RadioButton();
    this.Label5 = new System.Windows.Forms.Label();
    this.Label4 = new System.Windows.Forms.Label();
    this.txtEncrypted = new System.Windows.Forms.TextBox();
    this.txtIV = new System.Windows.Forms.TextBox();
    this.txtKey = new System.Windows.Forms.TextBox();
    this.txtOriginal = new System.Windows.Forms.TextBox();
    this.btnIVGen = new System.Windows.Forms.Button();
    this.btnKeyGen = new System.Windows.Forms.Button();
    this.Label3 = new System.Windows.Forms.Label();
    this.Label2 = new System.Windows.Forms.Label();
    this.cmdDecrypt = new System.Windows.Forms.Button();
    this.cmdEncrypt = new System.Windows.Forms.Button();
    this.GroupBox1.SuspendLayout();
    this.SuspendLayout();
    // 
    // GroupBox1
    // 
    this.GroupBox1.Controls.Add(this.optTripleDES);
    this.GroupBox1.Controls.Add(this.optDES);
    this.GroupBox1.Location = new System.Drawing.Point(8, 8);
    this.GroupBox1.Name = "GroupBox1";
    this.GroupBox1.Size = new System.Drawing.Size(480, 80);
    this.GroupBox1.TabIndex = 0;
    this.GroupBox1.TabStop = false;
    this.GroupBox1.Text = "Select Encryption Type";
    // 
    // optTripleDES
    // 
    this.optTripleDES.Location = new System.Drawing.Point(16, 48);
    this.optTripleDES.Name = "optTripleDES";
    this.optTripleDES.Size = new System.Drawing.Size(160, 24);
    this.optTripleDES.TabIndex = 1;
    this.optTripleDES.Text = "Triple DES";
    // 
    // optDES
    // 
    this.optDES.Checked = true;
    this.optDES.Location = new System.Drawing.Point(16, 24);
    this.optDES.Name = "optDES";
    this.optDES.Size = new System.Drawing.Size(168, 16);
    this.optDES.TabIndex = 0;
    this.optDES.TabStop = true;
    this.optDES.Text = "DES";
    // 
    // Label5
    // 
    this.Label5.Location = new System.Drawing.Point(8, 256);
    this.Label5.Name = "Label5";
    this.Label5.Size = new System.Drawing.Size(88, 48);
    this.Label5.TabIndex = 11;
    this.Label5.Text = "Encrypted String";
    // 
    // Label4
    // 
    this.Label4.Location = new System.Drawing.Point(8, 160);
    this.Label4.Name = "Label4";
    this.Label4.Size = new System.Drawing.Size(80, 40);
    this.Label4.TabIndex = 7;
    this.Label4.Text = "Original String";
    // 
    // txtEncrypted
    // 
    this.txtEncrypted.Location = new System.Drawing.Point(104, 264);
    this.txtEncrypted.Multiline = true;
    this.txtEncrypted.Name = "txtEncrypted";
    this.txtEncrypted.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
    this.txtEncrypted.Size = new System.Drawing.Size(384, 64);
    this.txtEncrypted.TabIndex = 12;
    this.txtEncrypted.Text = "";
    // 
    // txtIV
    // 
    this.txtIV.Location = new System.Drawing.Point(104, 128);
    this.txtIV.Name = "txtIV";
    this.txtIV.Size = new System.Drawing.Size(280, 26);
    this.txtIV.TabIndex = 5;
    this.txtIV.Text = "";
    // 
    // txtKey
    // 
    this.txtKey.Location = new System.Drawing.Point(104, 96);
    this.txtKey.Name = "txtKey";
    this.txtKey.Size = new System.Drawing.Size(280, 26);
    this.txtKey.TabIndex = 2;
    this.txtKey.Text = "";
    // 
    // txtOriginal
    // 
    this.txtOriginal.Location = new System.Drawing.Point(104, 160);
    this.txtOriginal.Multiline = true;
    this.txtOriginal.Name = "txtOriginal";
    this.txtOriginal.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
    this.txtOriginal.Size = new System.Drawing.Size(384, 64);
    this.txtOriginal.TabIndex = 8;
    this.txtOriginal.Text = "Server=localhost;Database=Northwind;UID=sa;PWD=sa";
    // 
    // btnIVGen
    // 
    this.btnIVGen.Location = new System.Drawing.Point(392, 128);
    this.btnIVGen.Name = "btnIVGen";
    this.btnIVGen.Size = new System.Drawing.Size(96, 24);
    this.btnIVGen.TabIndex = 6;
    this.btnIVGen.Text = "Gen IV";
    this.btnIVGen.Click += new System.EventHandler(this.btnIVGen_Click);
    // 
    // btnKeyGen
    // 
    this.btnKeyGen.Location = new System.Drawing.Point(392, 96);
    this.btnKeyGen.Name = "btnKeyGen";
    this.btnKeyGen.Size = new System.Drawing.Size(96, 24);
    this.btnKeyGen.TabIndex = 3;
    this.btnKeyGen.Text = "Gen Key";
    this.btnKeyGen.Click += new System.EventHandler(this.btnKeyGen_Click);
    // 
    // Label3
    // 
    this.Label3.Location = new System.Drawing.Point(8, 128);
    this.Label3.Name = "Label3";
    this.Label3.Size = new System.Drawing.Size(48, 16);
    this.Label3.TabIndex = 4;
    this.Label3.Text = "IV";
    // 
    // Label2
    // 
    this.Label2.Location = new System.Drawing.Point(8, 104);
    this.Label2.Name = "Label2";
    this.Label2.Size = new System.Drawing.Size(72, 16);
    this.Label2.TabIndex = 1;
    this.Label2.Text = "Key";
    // 
    // cmdDecrypt
    // 
    this.cmdDecrypt.Location = new System.Drawing.Point(240, 232);
    this.cmdDecrypt.Name = "cmdDecrypt";
    this.cmdDecrypt.Size = new System.Drawing.Size(120, 24);
    this.cmdDecrypt.TabIndex = 10;
    this.cmdDecrypt.Text = "Decrypt";
    this.cmdDecrypt.Click += new System.EventHandler(this.cmdDecrypt_Click);
    // 
    // cmdEncrypt
    // 
    this.cmdEncrypt.Location = new System.Drawing.Point(104, 232);
    this.cmdEncrypt.Name = "cmdEncrypt";
    this.cmdEncrypt.Size = new System.Drawing.Size(120, 24);
    this.cmdEncrypt.TabIndex = 9;
    this.cmdEncrypt.Text = "Encrypt";
    this.cmdEncrypt.Click += new System.EventHandler(this.cmdEncrypt_Click);
    // 
    // frmEncrypt
    // 
    this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
    this.ClientSize = new System.Drawing.Size(496, 330);
    this.Controls.Add(this.GroupBox1);
    this.Controls.Add(this.Label5);
    this.Controls.Add(this.Label4);
    this.Controls.Add(this.txtEncrypted);
    this.Controls.Add(this.txtIV);
    this.Controls.Add(this.txtKey);
    this.Controls.Add(this.txtOriginal);
    this.Controls.Add(this.btnIVGen);
    this.Controls.Add(this.btnKeyGen);
    this.Controls.Add(this.Label3);
    this.Controls.Add(this.Label2);
    this.Controls.Add(this.cmdDecrypt);
    this.Controls.Add(this.cmdEncrypt);
    this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.Name = "frmEncrypt";
    this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
    this.Text = "Encryption";
    this.GroupBox1.ResumeLayout(false);
    this.ResumeLayout(false);

  }
	#endregion

}
}
