using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CryptoSampleCS
{
	/// <summary>
	/// Summary description for frmMain.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Button btnEncrypt;
		internal System.Windows.Forms.Button btnHash;
    internal System.Windows.Forms.Button btnHashSalt;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.btnEncrypt = new System.Windows.Forms.Button();
      this.btnHash = new System.Windows.Forms.Button();
      this.btnHashSalt = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // btnEncrypt
      // 
      this.btnEncrypt.Location = new System.Drawing.Point(280, 8);
      this.btnEncrypt.Name = "btnEncrypt";
      this.btnEncrypt.Size = new System.Drawing.Size(136, 80);
      this.btnEncrypt.TabIndex = 3;
      this.btnEncrypt.Text = "Encryption and Decryption";
      this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
      // 
      // btnHash
      // 
      this.btnHash.Location = new System.Drawing.Point(8, 8);
      this.btnHash.Name = "btnHash";
      this.btnHash.Size = new System.Drawing.Size(128, 80);
      this.btnHash.TabIndex = 2;
      this.btnHash.Text = "Hashing";
      this.btnHash.Click += new System.EventHandler(this.btnHash_Click);
      // 
      // btnHashSalt
      // 
      this.btnHashSalt.Location = new System.Drawing.Point(144, 8);
      this.btnHashSalt.Name = "btnHashSalt";
      this.btnHashSalt.Size = new System.Drawing.Size(128, 80);
      this.btnHashSalt.TabIndex = 4;
      this.btnHashSalt.Text = "Hashing with Salt";
      this.btnHashSalt.Click += new System.EventHandler(this.btnHashSalt_Click);
      // 
      // frmMain
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
      this.ClientSize = new System.Drawing.Size(424, 90);
      this.Controls.Add(this.btnHashSalt);
      this.Controls.Add(this.btnEncrypt);
      this.Controls.Add(this.btnHash);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "frmMain";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Cryptography Samples";
      this.ResumeLayout(false);

    }
		#endregion

		private void btnHash_Click(object sender, System.EventArgs e)
		{
			Form frm;

			frm = new frmHash();

			frm.Show();
		}

		private void btnEncrypt_Click(object sender, System.EventArgs e)
		{
			Form frm;

			frm = new frmEncrypt();

			frm.Show();
		}

    private void btnHashSalt_Click(object sender, System.EventArgs e)
    {
      Form frm;

      frm = new frmHashWithSalt();

      frm.Show();
    }
	}
}
