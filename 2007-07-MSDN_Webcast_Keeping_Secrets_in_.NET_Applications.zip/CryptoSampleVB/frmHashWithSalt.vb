Imports System.Security.Cryptography

Public Class frmHashWithSalt
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
   Friend WithEvents optMD5 As System.Windows.Forms.RadioButton
   Friend WithEvents optSHA1 As System.Windows.Forms.RadioButton
   Friend WithEvents txtOriginal As System.Windows.Forms.TextBox
   Friend WithEvents Label4 As System.Windows.Forms.Label
   Friend WithEvents Label1 As System.Windows.Forms.Label
   Friend WithEvents txtHashed As System.Windows.Forms.TextBox
   Friend WithEvents btnHash As System.Windows.Forms.Button
   Friend WithEvents Label3 As System.Windows.Forms.Label
   Friend WithEvents txtSalt As System.Windows.Forms.TextBox
   Friend WithEvents btnCreateSalt As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.GroupBox1 = New System.Windows.Forms.GroupBox
      Me.optMD5 = New System.Windows.Forms.RadioButton
      Me.optSHA1 = New System.Windows.Forms.RadioButton
      Me.txtOriginal = New System.Windows.Forms.TextBox
      Me.btnHash = New System.Windows.Forms.Button
      Me.Label4 = New System.Windows.Forms.Label
      Me.Label1 = New System.Windows.Forms.Label
      Me.txtHashed = New System.Windows.Forms.TextBox
      Me.Label3 = New System.Windows.Forms.Label
      Me.txtSalt = New System.Windows.Forms.TextBox
      Me.btnCreateSalt = New System.Windows.Forms.Button
      Me.GroupBox1.SuspendLayout()
      Me.SuspendLayout()
      '
      'GroupBox1
      '
      Me.GroupBox1.Controls.Add(Me.optMD5)
      Me.GroupBox1.Controls.Add(Me.optSHA1)
      Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
      Me.GroupBox1.Name = "GroupBox1"
      Me.GroupBox1.Size = New System.Drawing.Size(456, 64)
      Me.GroupBox1.TabIndex = 0
      Me.GroupBox1.TabStop = False
      Me.GroupBox1.Text = "Select Hashing Type"
      '
      'optMD5
      '
      Me.optMD5.Location = New System.Drawing.Point(16, 40)
      Me.optMD5.Name = "optMD5"
      Me.optMD5.Size = New System.Drawing.Size(160, 16)
      Me.optMD5.TabIndex = 1
      Me.optMD5.Text = "MD5"
      '
      'optSHA1
      '
      Me.optSHA1.Checked = True
      Me.optSHA1.Location = New System.Drawing.Point(16, 24)
      Me.optSHA1.Name = "optSHA1"
      Me.optSHA1.Size = New System.Drawing.Size(168, 16)
      Me.optSHA1.TabIndex = 0
      Me.optSHA1.TabStop = True
      Me.optSHA1.Text = "SHA1"
      '
      'txtOriginal
      '
      Me.txtOriginal.Location = New System.Drawing.Point(96, 88)
      Me.txtOriginal.Multiline = True
      Me.txtOriginal.Name = "txtOriginal"
      Me.txtOriginal.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtOriginal.Size = New System.Drawing.Size(368, 64)
      Me.txtOriginal.TabIndex = 2
      Me.txtOriginal.Text = "Password"
      '
      'btnHash
      '
      Me.btnHash.Location = New System.Drawing.Point(96, 160)
      Me.btnHash.Name = "btnHash"
      Me.btnHash.Size = New System.Drawing.Size(176, 24)
      Me.btnHash.TabIndex = 3
      Me.btnHash.Text = "Hash With Salt"
      '
      'Label4
      '
      Me.Label4.Location = New System.Drawing.Point(8, 192)
      Me.Label4.Name = "Label4"
      Me.Label4.Size = New System.Drawing.Size(64, 40)
      Me.Label4.TabIndex = 4
      Me.Label4.Text = "Hashed String"
      '
      'Label1
      '
      Me.Label1.Location = New System.Drawing.Point(8, 88)
      Me.Label1.Name = "Label1"
      Me.Label1.Size = New System.Drawing.Size(72, 40)
      Me.Label1.TabIndex = 1
      Me.Label1.Text = "Original String"
      '
      'txtHashed
      '
      Me.txtHashed.Location = New System.Drawing.Point(96, 192)
      Me.txtHashed.Multiline = True
      Me.txtHashed.Name = "txtHashed"
      Me.txtHashed.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtHashed.Size = New System.Drawing.Size(368, 64)
      Me.txtHashed.TabIndex = 5
      Me.txtHashed.Text = ""
      '
      'Label3
      '
      Me.Label3.Location = New System.Drawing.Point(8, 264)
      Me.Label3.Name = "Label3"
      Me.Label3.Size = New System.Drawing.Size(88, 24)
      Me.Label3.TabIndex = 37
      Me.Label3.Text = "Salt Value"
      '
      'txtSalt
      '
      Me.txtSalt.Location = New System.Drawing.Point(96, 264)
      Me.txtSalt.Name = "txtSalt"
      Me.txtSalt.Size = New System.Drawing.Size(368, 26)
      Me.txtSalt.TabIndex = 36
      Me.txtSalt.Text = ""
      '
      'btnCreateSalt
      '
      Me.btnCreateSalt.Location = New System.Drawing.Point(280, 160)
      Me.btnCreateSalt.Name = "btnCreateSalt"
      Me.btnCreateSalt.Size = New System.Drawing.Size(176, 24)
      Me.btnCreateSalt.TabIndex = 38
      Me.btnCreateSalt.Text = "Create Salt"
      '
      'frmHashWithSalt
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
      Me.ClientSize = New System.Drawing.Size(472, 298)
      Me.Controls.Add(Me.btnCreateSalt)
      Me.Controls.Add(Me.Label3)
      Me.Controls.Add(Me.txtSalt)
      Me.Controls.Add(Me.GroupBox1)
      Me.Controls.Add(Me.txtOriginal)
      Me.Controls.Add(Me.btnHash)
      Me.Controls.Add(Me.Label4)
      Me.Controls.Add(Me.Label1)
      Me.Controls.Add(Me.txtHashed)
      Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.Name = "frmHashWithSalt"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
      Me.Text = "Hashing Strings with Salt"
      Me.GroupBox1.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private mhash As HashAlgorithm

   Private Sub btnHash_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHash.Click
      txtSalt.Text = "3Bruce"
      txtHashed.Text = HashString(txtSalt.Text & txtOriginal.Text)

      ' Call Hard Coded Routines
      HashPassSHA1()
      HashPassMD5()
   End Sub

   Private Function HashString(ByVal Value As String) As String
      Dim bytValue() As Byte
      Dim bytHash() As Byte

      ' Create New Crypto Service Provider Object
      mhash = SetHash()

      ' Convert the original string to array of Bytes
      bytValue = System.Text.Encoding.UTF8.GetBytes(Value)

      ' Compute the Hash, returns an array of Bytes
      bytHash = mhash.ComputeHash(bytValue)

      mhash.Clear()

      ' Return a base 64 encoded string of the Hash value
      Return Convert.ToBase64String(bytHash)
   End Function

   Private Function SetHash() As HashAlgorithm
      If optSHA1.Checked Then
         Return New SHA1CryptoServiceProvider
      Else
         If optMD5.Checked Then
            Return New MD5CryptoServiceProvider
         End If
      End If
   End Function

   Private Sub btnCreateSalt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateSalt.Click
      txtSalt.Text = CreateSalt()
   End Sub

   Private Function CreateSalt() As String
      Dim bytSalt(8) As Byte
      Dim rng As New RNGCryptoServiceProvider

      rng.GetBytes(bytSalt)

      Return Convert.ToBase64String(bytSalt)
   End Function

#Region "Hard Coded Routines"
   Private Sub HashPassSHA1()
      Dim SHA1 As SHA1CryptoServiceProvider
      Dim bytValue() As Byte
      Dim bytHash() As Byte

      ' Create New Crypto Service Provider Object
      SHA1 = New SHA1CryptoServiceProvider

      ' Convert the original string to array of Bytes
      bytValue = System.Text.Encoding.UTF8.GetBytes("Password")

      ' Compute the Hash, returns an array of Bytes
      bytHash = SHA1.ComputeHash(bytValue)

      SHA1.Clear()

      ' Return a base 64 encoded string of the Hash value
      Debug.WriteLine(Convert.ToBase64String(bytHash))
   End Sub

   Private Sub HashPassMD5()
      Dim md5 As MD5CryptoServiceProvider
      Dim bytValue() As Byte
      Dim bytHash() As Byte

      ' Create New Crypto Service Provider Object
      md5 = New MD5CryptoServiceProvider

      ' Convert the original string to array of Bytes
      bytValue = System.Text.Encoding.UTF8.GetBytes("Password")

      ' Compute the Hash, returns an array of Bytes
      bytHash = md5.ComputeHash(bytValue)

      md5.Clear()

      ' Return a base 64 encoded string of the Hash value
      Debug.WriteLine(Convert.ToBase64String(bytHash))
   End Sub
#End Region
End Class
