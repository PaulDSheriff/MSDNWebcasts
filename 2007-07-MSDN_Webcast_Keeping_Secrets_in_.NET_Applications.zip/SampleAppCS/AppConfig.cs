using System;
using System.Security.Cryptography;
using Microsoft.Win32;
using System.Text;
using System.IO;

using PDSACryptographyCS;

namespace SampleAppCS
{
	/// <summary>
	/// Summary description for AppConfig.
	/// </summary>
	public class AppConfig
	{

    private static string mConnectString;

    // Constructor
		static AppConfig()
		{
      PDSASymmetric ph = new PDSASymmetric(PDSASymmetric.PDSAEncryptionType.DES);

      ph.KeyString = GetEncKey();
      ph.IVString = GetEncIV();
      mConnectString = ph.Decrypt(GetConnectString());
		}

    public static string ConnectString
    {
      get {return mConnectString;}
    }

#region "Registry Methods"
    const string CONNECTION_KEY = @"Software\MyApp\Data";

    private static string GetRegData(string Key, string SubKey)
    {
      RegistryKey rk = null;

      try
      {
        rk = Registry.CurrentUser.OpenSubKey(Key);

        if (rk != null)
          return rk.GetValue(SubKey).ToString();
      }

      catch
      {
        throw;
      }

      finally
      {
        if (rk != null)
          rk.Close();
      }

      return "";
    }

    public static string GetConnectString()
    {
      return GetRegData(CONNECTION_KEY, "EncString");
    }

    public static string GetEncKey()
    {
      return GetRegData(CONNECTION_KEY, "EncKey");
    }

    public static string GetEncIV()
    {
      return GetRegData(CONNECTION_KEY, "EncIV");
    }
	}
  #endregion
}
