Imports System.Configuration

Public Class AppConfig
	Public Shared ReadOnly Property ConnectString() As String
		Get
			Return ConfigurationSettings.AppSettings.Item("ConnectString")
		End Get
	End Property

	Public Shared ReadOnly Property UploadFolder() As String
		Get
			Return ConfigurationSettings.AppSettings.Item("UploadFolder")
		End Get
	End Property

	Public Shared ReadOnly Property WebServiceURL() As String
		Get
			Return ConfigurationSettings.AppSettings.Item("WebServiceURL")
		End Get
	End Property
End Class
