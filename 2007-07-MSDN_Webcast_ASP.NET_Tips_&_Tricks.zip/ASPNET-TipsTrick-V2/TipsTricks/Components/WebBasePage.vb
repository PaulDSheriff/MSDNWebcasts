Imports System.IO

Public Class WebBasePage
	Inherits System.Web.UI.Page

	Public Styles As String = "../Styles/Styles.css"
	Public ViewStateOnServer As Boolean = False

#Region "ViewState Persistence Methods"
	' This method occurs after the Page.Load event
	Protected Overrides Sub SavePageStateToPersistenceMedium(ByVal viewState As Object)
		If ViewStateOnServer Then
			ToSession(viewState)
		Else
			MyBase.SavePageStateToPersistenceMedium(viewState)
		End If
	End Sub

	' This method occurs BEFORE the Page.Load event
	Protected Overrides Function LoadPageStateFromPersistenceMedium() As Object
		If ViewStateOnServer Then
			Return FromSession()
		Else
			Return MyBase.LoadPageStateFromPersistenceMedium()
		End If
	End Function

	Public Sub ToSession(ByVal ViewState As Object)
		Dim ms As New MemoryStream
		Dim lf As LosFormatter
		Dim ctx As HttpContext

		Try
			ctx = HttpContext.Current
			lf = New LosFormatter
			lf.Serialize(ms, ViewState)

			' Insert into Session
			ctx.Session.Add("MyViewState", ms)

		Catch exp As Exception
			Throw exp

		End Try
	End Sub

	'''************************************************************
	'''<VBComments class="PDSAViewState" name="FromSession" type="Function">
	'''<summary>
	'''Call this method to un-serialize the ViewState object from the Session object back into a ViewState object.
	'''</summary>
	'''<example>
	'''Dim pv As New PDSAViewState()
	'''
	'''Page.ViewState = pv.FromSession()
	'''</example>
	'''<param></param>
	'''<returns>Object</returns>
	'''</VBComments>
	'''************************************************************
	Public Function FromSession() As Object
		Dim ViewState As Object
		Dim strView As String
		Dim sr As StreamReader
		Dim lf As LosFormatter
		Dim ctx As HttpContext
		Dim ms As MemoryStream

		Try
			ctx = HttpContext.Current
			ms = DirectCast(ctx.Session.Item("MyViewState"), MemoryStream)
			ms.Position = 0
			sr = New StreamReader(ms)
			strView = sr.ReadToEnd()
			sr.Close()

			lf = New LosFormatter
			ViewState = lf.Deserialize(strView)

			Return ViewState

		Catch exp As Exception
			Throw New ApplicationException("View State is Invalid")

		End Try
	End Function
#End Region

End Class
