CREATE TABLE tblDocuments
(
	iDocID int IDENTITY (1, 1) NOT NULL,
	sDesc varchar(100) NULL ,
	binContent image NULL,
	iSize int NULL ,
	sType varchar(100) NULL 
)