Imports System.Configuration

Public Class AppConfig
	Public Shared ReadOnly Property ConnectString() As String
		Get
			Return ConfigurationSettings.AppSettings.Item("ConnectString")
		End Get
	End Property
End Class
