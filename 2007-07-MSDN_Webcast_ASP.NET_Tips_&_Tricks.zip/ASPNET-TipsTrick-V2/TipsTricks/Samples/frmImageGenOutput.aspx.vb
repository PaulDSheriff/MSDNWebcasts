Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Drawing.Imaging
Imports System.IO
Imports System

Public Class BarChart
	Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

	'This call is required by the Web Form Designer.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

	End Sub

	Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
		'CODEGEN: This method call is required by the Web Form Designer
		'Do not modify it using the code editor.
		InitializeComponent()
	End Sub

#End Region

	Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		Dim Stocks As New System.Collections.ArrayList
		Dim Profits As New System.Collections.ArrayList

		Stocks.Add("SUNW")
		Stocks.Add("MSFT")
		Stocks.Add("IBM")
		Stocks.Add("INSP")
		Stocks.Add("ORCL")

		Profits.Add(5)
		Profits.Add(140)
		Profits.Add(35)
		Profits.Add(3)
		Profits.Add(12)

		DrawBarGraph("Common Tech Stock Prices", Stocks, _
		  Profits, Response.OutputStream)
	End Sub

	' Thanks to Rob Howard for this Code
	Sub DrawBarGraph(ByVal strTitle As String, _
	  ByVal aX As System.Collections.ArrayList, _
	  ByVal aY As System.Collections.ArrayList, _
	  ByVal Target As Stream)

		Const iColWidth As Integer = 60

		Dim iColSpace As Integer = 25
		Dim iMaxHeight As Integer = 400
		Dim iHeightSpace As Integer = 25
		Dim iXLegendSpace As Integer = 30
		Dim iTitleSpace As Integer = 50
		Dim iMaxWidth As Integer
		Dim iMaxColHeight As Integer = 0
		Dim iTotalHeight As Integer
		Dim iValue As Integer
		Dim iBarX As Integer
		Dim iCurrentHeight As Integer
		Dim iLoop As Integer
		Dim objBitmap As Bitmap
		Dim objGraphics As Graphics
		Dim objBrush As SolidBrush
		Dim fontLegend As Font
		Dim fontValues As Font
		Dim fontTitle As Font


		iTotalHeight = iMaxHeight + iXLegendSpace + iTitleSpace
		iMaxWidth = (iColWidth + iColSpace) * aX.Count + iColSpace

		objBitmap = New Bitmap(iMaxWidth, iTotalHeight)
		objGraphics = Graphics.FromImage(objBitmap)

		objGraphics.FillRectangle(New SolidBrush(Color.White), 0, 0, iMaxWidth, iTotalHeight)
		objGraphics.FillRectangle(New SolidBrush(Color.Ivory), 0, 0, iMaxWidth, iMaxHeight)

		' Find the maximum value
		For Each iValue In aY
			If iValue > iMaxColHeight Then iMaxColHeight = iValue
		Next

		iBarX = iColSpace
		objBrush = New SolidBrush(Color.Navy)
		fontLegend = New Font("Arial", 11)
		fontValues = New Font("Arial", 8)
		fontTitle = New Font("Arial", 18)

		' loop through and draw each bar

		For iLoop = 0 To aX.Count - 1
			iCurrentHeight = Convert.ToInt32((Convert.ToDouble(aY(iLoop)) / Convert.ToDouble(iMaxColHeight)) * Convert.ToDouble(iMaxHeight - iHeightSpace))

			objGraphics.FillRectangle(objBrush, iBarX, iMaxHeight - iCurrentHeight, iColWidth, iCurrentHeight)
			objGraphics.DrawString(aX(iLoop).ToString(), fontLegend, objBrush, iBarX, iMaxHeight)
			objGraphics.DrawString(String.Format("{0:#,###}", aY(iLoop)), fontValues, objBrush, iBarX, iMaxHeight - iCurrentHeight - 15)

			iBarX += (iColSpace + iColWidth)
		Next

		objGraphics.DrawString(strTitle, fontTitle, objBrush, Convert.ToSingle((iMaxWidth / 2) - strTitle.Length * 6), Convert.ToSingle(iMaxHeight + iXLegendSpace))

		'*************************************************
		' Save to Response Stream here
		'*************************************************
		objBitmap.Save(Target, ImageFormat.Gif)
		objGraphics.Dispose()
		objBitmap.Dispose()
	End Sub
End Class
