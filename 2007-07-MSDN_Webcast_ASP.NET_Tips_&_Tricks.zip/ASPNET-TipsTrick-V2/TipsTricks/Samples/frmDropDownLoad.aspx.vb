Imports System.Data.SqlClient

Public Class frmDropDownLoad
	Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

	'This call is required by the Web Form Designer.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

	End Sub
	Protected WithEvents Label1 As System.Web.UI.WebControls.Label
	Protected WithEvents ddlCategories As System.Web.UI.WebControls.DropDownList
	Protected WithEvents ddlProducts As System.Web.UI.WebControls.DropDownList
	Protected WithEvents lblTime As System.Web.UI.WebControls.Label
	Protected WithEvents lblMsg As System.Web.UI.WebControls.Label
	Protected WithEvents Label2 As System.Web.UI.WebControls.Label
	Protected WithEvents Label3 As System.Web.UI.WebControls.Label
	Protected WithEvents lnkHome As System.Web.UI.WebControls.HyperLink

	'NOTE: The following placeholder declaration is required by the Web Form Designer.
	'Do not delete or move it.
	Private designerPlaceholderDeclaration As System.Object

	Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
		'CODEGEN: This method call is required by the Web Form Designer
		'Do not modify it using the code editor.
		InitializeComponent()
	End Sub

#End Region

	Public WebServiceURL As String

	Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		Me.lblTime.Text = Now.ToString()
		WebServiceURL = AppConfig.WebServiceURL

		If Not Page.IsPostBack Then
			CategoryLoad()
		End If
	End Sub

	Sub CategoryLoad()
		Dim ds As New DataSet
		Dim da As SqlDataAdapter
		Dim strSQL As String

		strSQL = "SELECT * FROM Categories "

		da = New SqlDataAdapter(strSQL, AppConfig.ConnectString)
		da.Fill(ds)

		If ds.Tables(0).Rows.Count > 0 Then
			ddlCategories.DataTextField = "CategoryName"
			ddlCategories.DataValueField = "CategoryID"
			ddlCategories.DataSource = ds
			ddlCategories.DataBind()
		Else
			lblMsg.Text = "No Documents in the System"
		End If
	End Sub
End Class
