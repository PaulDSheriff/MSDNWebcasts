Imports System.IO

Public Class frmUploadToFile
	Inherits System.Web.UI.Page

	Protected WithEvents btnUpload As System.Web.UI.WebControls.Button
	Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
	Protected WithEvents Label1 As System.Web.UI.WebControls.Label
	Protected WithEvents lnkHome As System.Web.UI.WebControls.HyperLink
	Protected WithEvents filUpload As System.Web.UI.HtmlControls.HtmlInputFile

#Region " Web Form Designer Generated Code "

	'This call is required by the Web Form Designer.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

	End Sub

	Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
		'CODEGEN: This method call is required by the Web Form Designer
		'Do not modify it using the code editor.
		InitializeComponent()
	End Sub

#End Region

	Private Sub btnUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpload.Click
		UploadFile()
	End Sub

	Private Sub UploadFile()
		Dim strPath As String

		strPath = AppConfig.UploadFolder & _
		  Path.GetFileName(filUpload.PostedFile.FileName)

		filUpload.PostedFile.SaveAs(strPath)

		lblMessage.Text = "Your file was successfully uploaded at: <b>" & strPath & "</b>"
	End Sub
End Class
