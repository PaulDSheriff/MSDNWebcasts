Imports System.Data
Imports System.Data.SqlClient

Public Class frmUploadToTable
	Inherits System.Web.UI.Page

	Protected WithEvents txtDesc As System.Web.UI.WebControls.TextBox
	Protected WithEvents btnUpload As System.Web.UI.WebControls.Button
	Protected WithEvents Label1 As System.Web.UI.WebControls.Label
	Protected WithEvents grdDocs As System.Web.UI.WebControls.DataGrid
	Protected WithEvents lblMsg As System.Web.UI.WebControls.Label
	Protected WithEvents lnkHome As System.Web.UI.WebControls.HyperLink
	Protected WithEvents filUpload As System.Web.UI.HtmlControls.HtmlInputFile

#Region " Web Form Designer Generated Code "

	'This call is required by the Web Form Designer.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

	End Sub

	Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
		'CODEGEN: This method call is required by the Web Form Designer
		'Do not modify it using the code editor.
		InitializeComponent()
	End Sub

#End Region

	Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		If Not Page.IsPostBack Then
			GridLoad()
		End If
	End Sub

	Sub GridLoad()
		Dim ds As New DataSet
		Dim da As SqlDataAdapter
		Dim strSQL As String

		strSQL = "SELECT * FROM tblDocuments "

		da = New SqlDataAdapter(strSQL, AppConfig.ConnectString)
		da.Fill(ds)

		If ds.Tables(0).Rows.Count > 0 Then
			grdDocs.DataSource = ds
			grdDocs.DataBind()
		Else
			lblMsg.Text = "No Documents in the System"
		End If
	End Sub

	Private Sub btnUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpload.Click
		Dim intLength As Integer
		Dim strType As String
		Dim bytContent As Byte()

		intLength = Convert.ToInt32(filUpload.PostedFile.InputStream.Length)
		strType = filUpload.PostedFile.ContentType
		ReDim bytContent(intLength)

		filUpload.PostedFile.InputStream.Read(bytContent, 0, intLength)
		UploadDocument(txtDesc.Text, bytContent, intLength, strType)

		lblMsg.Text = ""
		txtDesc.Text = ""
		GridLoad()
	End Sub

	Sub UploadDocument(ByVal Description As String, _
	 ByVal Content As Byte(), ByVal Size As Integer, _
	 ByVal ContentType As String)
		Dim cnn As SqlConnection
		Dim cmd As SqlCommand
		Dim param As SqlParameter
		Dim strSQL As String

		strSQL = "INSERT INTO tblDocuments(sDesc, binContent, iSize, sType) "
		strSQL &= " VALUES(@sDesc, @binContent, @iSize, @sType)"

		cmd = New SqlCommand(strSQL)
		cnn = New SqlConnection(AppConfig.ConnectString)

		param = New SqlParameter("@sDesc", SqlDbType.NVarChar)
		param.Value = Description
		cmd.Parameters.Add(param)

		param = New SqlParameter("@binContent", SqlDbType.Image)
		param.Value = Content
		cmd.Parameters.Add(param)

		param = New SqlParameter("@iSize", SqlDbType.Int)
		param.Value = Size
		cmd.Parameters.Add(param)

		param = New SqlParameter("@sType", SqlDbType.NVarChar)
		param.Value = ContentType
		cmd.Parameters.Add(param)

		cnn.Open()
		cmd.Connection = cnn
		cmd.ExecuteNonQuery()
		cnn.Close()
	End Sub
End Class
