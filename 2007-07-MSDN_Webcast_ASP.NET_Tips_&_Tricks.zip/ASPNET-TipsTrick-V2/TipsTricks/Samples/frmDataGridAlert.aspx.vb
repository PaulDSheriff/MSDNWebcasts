Imports System.Data.SqlClient

Public Class frmDataGridAlert
	Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

	'This call is required by the Web Form Designer.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

	End Sub
	Protected WithEvents Label1 As System.Web.UI.WebControls.Label
	Protected WithEvents grdDocs As System.Web.UI.WebControls.DataGrid
	Protected WithEvents lblMsg As System.Web.UI.WebControls.Label
	Protected WithEvents lnkHome As System.Web.UI.WebControls.HyperLink

	'NOTE: The following placeholder declaration is required by the Web Form Designer.
	'Do not delete or move it.
	Private designerPlaceholderDeclaration As System.Object

	Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
		'CODEGEN: This method call is required by the Web Form Designer
		'Do not modify it using the code editor.
		InitializeComponent()
	End Sub

#End Region

	Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		If Not Page.IsPostBack Then
			GridLoad()
		End If
	End Sub

	Sub GridLoad()
		Dim ds As New DataSet
		Dim da As SqlDataAdapter
		Dim strSQL As String

		strSQL = "SELECT * FROM tblDocuments "

		da = New SqlDataAdapter(strSQL, AppConfig.ConnectString)
		da.Fill(ds)

		If ds.Tables(0).Rows.Count > 0 Then
			grdDocs.DataSource = ds
			grdDocs.DataBind()
		Else
			lblMsg.Text = "No Documents in the System"
		End If
	End Sub

	Private Sub grdDocs_ItemDataBound(ByVal sender As Object, _
	 ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdDocs.ItemDataBound
		Dim lnk As LinkButton

		If e.Item.ItemType = ListItemType.AlternatingItem Or _
		 e.Item.ItemType = ListItemType.Item Then

			' Get 'Delete' Button
			lnk = DirectCast(e.Item.Cells(0).Controls(1), LinkButton)
			' Add JavaScript to Button
			lnk.Attributes.Add("onClick", _
			  "return confirm('Are you sure you wish to delete this record?')")

		End If
	End Sub

	Private Sub grdDocs_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdDocs.DeleteCommand
		Dim cnn As SqlConnection
		Dim cmd As SqlCommand
		Dim strSQL As String

		strSQL = "DELETE FROM tblDocuments "
		strSQL &= " WHERE iDocID = @iDocID"

		Try
			cnn = New SqlConnection(AppConfig.ConnectString)
			cmd = New SqlCommand(strSQL)

			cmd.Connection = cnn
			cmd.Parameters.Add(New SqlParameter("@iDocID", SqlDbType.Int))
			cmd.Parameters.Item("@iDocID").Value = e.CommandArgument

			cmd.Connection.Open()
			cmd.ExecuteNonQuery()

		Catch ex As Exception
			lblMsg.Text = ex.Message

		Finally
			cmd.Connection.Close()
			cmd.Connection.Dispose()
		End Try

		GridLoad()
	End Sub
End Class
