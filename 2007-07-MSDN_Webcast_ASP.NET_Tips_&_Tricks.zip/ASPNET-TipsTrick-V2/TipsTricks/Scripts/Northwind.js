function InitializeWebService(ServiceName)
{
	debugger;
	NWService.useService(ServiceName, "Products");
}

function CategoryChanged()
{
	var strCategory;
	var strReturn;

	debugger;
	
	/* Get Selected Category */
	strCategory = 
	  document.all.ddlCategories.options( 
	  document.all.ddlCategories.selectedIndex).value
	
	/* Setup call to Web Service */
	objCall = NWService.createCallOptions();
	objCall.async = false;
	objCall.funcName = "GetProducts"

   /* Pass category */	
	objCall.params = new Array();
	objCall.params.CategoryID = strCategory;

	/* Call Web Service */
	strReturn = NWService.Products.callService(objCall);
	
	/* Pass delimited String to function to load Drop Down */
	/* String is in format "|Text:Value" */
	PopulateDropDown(strReturn, "ddlProducts");
	
	document.all.lblMsg.innerText = '';
}

function PopulateDropDown(ReturnString, DDLName)
{
	var i;
	var arrValues
	var arrValue
	
	arrValues = ReturnString.value.split("|");

   /* Clear old values */
	document.all[DDLName].length = 0;
	/* Add blank Option */
	document.all[DDLName].options[0] = new Option("","");

	for(i=0;i <= arrValues.length-1; i++) {
      /* Split String into each Option */	
		arrValue = arrValues[i].split(":");
		
		/* Load Option into Drop Down */
		document.all[DDLName].options[i] = 
		  new Option(arrValue[0], arrValue[1]);
	}
}