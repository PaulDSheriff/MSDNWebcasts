using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.IO;

namespace TipsTricksCS.Samples
{
	/// <summary>
	/// Summary description for frmImageGenOutput.
	/// </summary>
	public class frmImageGenOutput : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			ArrayList Stocks = new ArrayList();
			ArrayList Profits = new ArrayList();

			Stocks.Add("SUNW");
			Stocks.Add("MSFT");
			Stocks.Add("IBM");
			Stocks.Add("INSP");
			Stocks.Add("ORCL");

			Profits.Add(5);
			Profits.Add(140);
			Profits.Add(35);
			Profits.Add(3);
			Profits.Add(12);

			DrawBarGraph("Common Tech Stock Prices", Stocks,
				Profits, Response.OutputStream);
		}

		private void DrawBarGraph(string strTitle, ArrayList aX, ArrayList aY, Stream Target)
		{
			const int iColWidth = 60;

			int iColSpace = 25;
			int iMaxHeight = 400;
			int iHeightSpace = 25;
			int iXLegendSpace = 30;
			int iTitleSpace = 50;
			int iMaxWidth;
			int iMaxColHeight = 0;
			int iTotalHeight;
			int iBarX;
			int iCurrentHeight;
			System.Drawing.Bitmap objBitmap;
			Graphics objGraphics;
			SolidBrush objBrush;
			Font fontLegend;
			Font fontValues;
			Font fontTitle;

			iTotalHeight = iMaxHeight + iXLegendSpace + iTitleSpace;
			iMaxWidth = (iColWidth + iColSpace) * aX.Count + iColSpace;

			objBitmap = new Bitmap(iMaxWidth, iTotalHeight);
			objGraphics = Graphics.FromImage(objBitmap);

			objGraphics.FillRectangle(new SolidBrush(Color.White), 0, 0, iMaxWidth, iTotalHeight);
			objGraphics.FillRectangle(new SolidBrush(Color.Ivory), 0, 0, iMaxWidth, iMaxHeight);

			// Find the maximum value
			foreach(int iValue in aY)
			{
				if( iValue > iMaxColHeight)
					iMaxColHeight = iValue;
			}

			iBarX = iColSpace;
			objBrush = new SolidBrush(Color.Navy);
			fontLegend = new Font("Arial", 11);
			fontValues = new Font("Arial", 8);
			fontTitle = new Font("Arial", 18);

			// loop through and draw each bar
			for(int iLoop = 0; iLoop <= aX.Count - 1; iLoop++)
			{
				iCurrentHeight = Convert.ToInt32((Convert.ToDouble(aY[iLoop]) / Convert.ToDouble(iMaxColHeight)) * Convert.ToDouble(iMaxHeight - iHeightSpace));

				objGraphics.FillRectangle(objBrush, iBarX, iMaxHeight - iCurrentHeight, iColWidth, iCurrentHeight);
				objGraphics.DrawString(aX[iLoop].ToString(), fontLegend, objBrush, iBarX, iMaxHeight);
				objGraphics.DrawString(String.Format("{0:#,###}", aY[iLoop]), fontValues, objBrush, iBarX, iMaxHeight - iCurrentHeight - 15);

				iBarX += (iColSpace + iColWidth);
			}

			objGraphics.DrawString(strTitle, fontTitle, objBrush, Convert.ToSingle((iMaxWidth / 2) - strTitle.Length * 6), Convert.ToSingle(iMaxHeight + iXLegendSpace));

			//*************************************************
			// Save to Response Stream here
			//*************************************************
			objBitmap.Save(Target, ImageFormat.Gif);
			objGraphics.Dispose();
			objBitmap.Dispose();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
