using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using TipsTricksCS.Components;

namespace TipsTricksCS.Samples
{
	/// <summary>
	/// Summary description for frmDataGridAlert.
	/// </summary>
	public class frmDataGridAlert : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.DataGrid grdDocs;
		protected System.Web.UI.WebControls.Label lblMsg;
		protected System.Web.UI.WebControls.HyperLink lnkHome;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!Page.IsPostBack)
			{
				GridLoad();
			}
		}

		private void GridLoad()
		{
			DataSet ds = new DataSet();
			SqlDataAdapter da;
			string strSQL;
			
			strSQL = "SELECT * FROM tblDocuments ";

			da = new SqlDataAdapter(strSQL, AppConfig.ConnectString);
			da.Fill(ds);

			if(ds.Tables[0].Rows.Count > 0)
			{
				grdDocs.DataSource = ds;
				grdDocs.DataBind();
			}
			else
			{
				lblMsg.Text = "No Documents in the System";
			}
		}
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.grdDocs.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.grdDocs_DeleteCommand);
			this.grdDocs.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.grdDocs_ItemDataBound);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void grdDocs_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			LinkButton lnk;

			if(e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item) 
			{
				lnk = (LinkButton) e.Item.Cells[0].Controls[1];
				lnk.Attributes.Add("onClick", 
					"return confirm('Are you sure you wish to delete this record?')");
			}
		
		}

		private void grdDocs_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			SqlConnection cnn;
			SqlCommand cmd = null;
			string strSQL;

			strSQL = "DELETE FROM tblDocuments ";
			strSQL += " WHERE iDocID = @iDocID";

			try
			{
				cnn = new SqlConnection(AppConfig.ConnectString);
				cmd = new SqlCommand(strSQL);

				cmd.Connection = cnn;
				cmd.Parameters.Add(new SqlParameter("@iDocID", SqlDbType.Int));
				cmd.Parameters["@iDocID"].Value = e.CommandArgument;

				cmd.Connection.Open();
				cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				lblMsg.Text = ex.Message;
			}
			finally
			{
				cmd.Connection.Close();
				cmd.Connection.Dispose();
			}

			GridLoad();
		}
	}
}
