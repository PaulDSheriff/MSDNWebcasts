using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using TipsTricksCS.Components;

namespace TipsTricksCS.Samples
{
	/// <summary>
	/// Summary description for frmUploadToTable.
	/// </summary>
	public class frmUploadToTable : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.DataGrid grdDocs;
		protected System.Web.UI.WebControls.Label lblMsg;
		protected System.Web.UI.WebControls.HyperLink lnkHome;
		protected System.Web.UI.WebControls.TextBox txtDesc;
		protected System.Web.UI.WebControls.Button btnUpload;
		protected System.Web.UI.HtmlControls.HtmlInputFile filUpload;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!Page.IsPostBack)
				GridLoad();
		}

		private void GridLoad()
		{
			DataSet ds= new DataSet();
			SqlDataAdapter da;
			string strSQL;

			strSQL = "SELECT * FROM tblDocuments ";

			da = new SqlDataAdapter(strSQL, AppConfig.ConnectString);
			da.Fill(ds);

			if( ds.Tables[0].Rows.Count > 0)
			{
				grdDocs.DataSource = ds;
				grdDocs.DataBind();
			}
			else
				lblMsg.Text = "No Documents in the System";
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnUpload_Click(object sender, System.EventArgs e)
		{
			int intLength;
			string strType;
			byte[] bytContent;

			intLength = Convert.ToInt32(filUpload.PostedFile.InputStream.Length);
			strType = filUpload.PostedFile.ContentType;
			bytContent = new byte[intLength];

			filUpload.PostedFile.InputStream.Read(bytContent, 0, intLength);
			UploadDocument(txtDesc.Text, bytContent, intLength, strType);

			lblMsg.Text = "";
			txtDesc.Text = "";
			GridLoad();
		}

		private void UploadDocument(string Description, byte[] Content, int Size, string ContentType)
		{
			SqlConnection cnn;
			SqlCommand cmd = null;
			SqlParameter param;
			string strSQL;

			strSQL = "INSERT INTO tblDocuments(sDesc, binContent, iSize, sType) ";
			strSQL += " VALUES(@sDesc, @binContent, @iSize, @sType)";

			cmd = new SqlCommand(strSQL);
			cnn = new SqlConnection(AppConfig.ConnectString);

			param = new SqlParameter("@sDesc", SqlDbType.NVarChar);
			param.Value = Description;
			cmd.Parameters.Add(param);

			param = new SqlParameter("@binContent", SqlDbType.Image);
			param.Value = Content;
			cmd.Parameters.Add(param);

			param = new SqlParameter("@iSize", SqlDbType.Int);
			param.Value = Size;
			cmd.Parameters.Add(param);

			param = new SqlParameter("@sType", SqlDbType.NVarChar);
			param.Value = ContentType;
			cmd.Parameters.Add(param);

			cnn.Open();
			cmd.Connection = cnn;
			cmd.ExecuteNonQuery();
			cnn.Close();
		}

	}
}
