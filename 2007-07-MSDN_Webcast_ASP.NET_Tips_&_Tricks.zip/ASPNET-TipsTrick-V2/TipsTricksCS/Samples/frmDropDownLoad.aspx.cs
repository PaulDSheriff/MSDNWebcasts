using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using TipsTricksCS.Components;

namespace TipsTricksCS.Samples
{
	/// <summary>
	/// Summary description for frmDropDownLoad.
	/// </summary>
	public class frmDropDownLoad : System.Web.UI.Page
	{
		public string WebServiceURL;

		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label lblTime;
		protected System.Web.UI.WebControls.DropDownList ddlCategories;
		protected System.Web.UI.WebControls.DropDownList ddlProducts;
		protected System.Web.UI.WebControls.Label lblMsg;
		protected System.Web.UI.WebControls.HyperLink lnkHome;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label2;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			lblTime.Text = DateTime.Now.ToString();
			WebServiceURL = AppConfig.WebServiceURL;

			if(!Page.IsPostBack)
				CategoryLoad();
		}

		private void CategoryLoad()
		{
			DataSet ds = new DataSet();
			SqlDataAdapter da;
			string strSQL;
			
			strSQL = "SELECT * FROM Categories ";

			da = new SqlDataAdapter(strSQL, AppConfig.ConnectString);
			da.Fill(ds);

			if(ds.Tables[0].Rows.Count > 0)
			{
				ddlCategories.DataTextField = "CategoryName";
				ddlCategories.DataValueField = "CategoryID";
				ddlCategories.DataSource = ds;
				ddlCategories.DataBind();
			}
			else
				lblMsg.Text = "No Documents in the System";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
