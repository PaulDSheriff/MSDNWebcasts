using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using TipsTricksCS.Components;

namespace TipsTricksCS.Samples
{
	/// <summary>
	/// Summary description for frmViewState.
	/// </summary>
	public class frmViewState : WebBasePage
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.DataGrid grdDocs;
		protected System.Web.UI.WebControls.Label lblMsg;
		protected System.Web.UI.WebControls.HyperLink lnkHome;
	
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			base.ViewStateOnServer = true;
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				ViewState["Sort"] = "sDesc";
				GridLoad();
			}
		}

		private void GridLoad()
		{
			DataSet ds = new DataSet();
			SqlDataAdapter da;
			string strSQL;

			strSQL = "SELECT * FROM tblDocuments ";
			strSQL += " ORDER BY " + ViewState["Sort"].ToString();

			da = new SqlDataAdapter(strSQL, AppConfig.ConnectString);
			da.Fill(ds);

			if(ds.Tables[0].Rows.Count > 0)
			{
				grdDocs.DataSource = ds;
				grdDocs.DataBind();
			}
			else
				lblMsg.Text = "No Documents in the System";
		}

		private void grdDocs_SortCommand(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e)
		{
			ViewState["Sort"] = e.SortExpression;

			GridLoad();
		}

		#region Web Form Designer generated code
	
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.grdDocs.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.grdDocs_SortCommand);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

	}
}
