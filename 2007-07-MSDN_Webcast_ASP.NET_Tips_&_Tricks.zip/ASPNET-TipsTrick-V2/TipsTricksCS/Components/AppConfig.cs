using System;
using System.Configuration;

namespace TipsTricksCS.Components
{
	/// <summary>
	/// Summary description for AppConfig.
	/// </summary>
	public class AppConfig
	{
		public AppConfig()
		{
		}

		public static string ConnectString
		{
			get { return ConfigurationSettings.AppSettings["ConnectString"]; }
		}

		public static string UploadFolder
		{
			get { return ConfigurationSettings.AppSettings["UploadFolder"]; }
		}

		public static string WebServiceURL
		{
			get { return ConfigurationSettings.AppSettings["WebServiceURL"]; }
		}
	}
}
