using System;
using System.IO;
using System.Web;
using System.Web.UI;

namespace TipsTricksCS.Components
{
	/// <summary>
	/// Summary description for WebBasePage.
	/// </summary>
	public class WebBasePage : System.Web.UI.Page
	{

		public string Styles = "../Styles/Styles.css";
		public bool ViewStateOnServer = false;

		public WebBasePage()
		{
		}

		#region "ViewState Persistence Methods"
		protected override void SavePageStateToPersistenceMedium(object viewState)
		{
			if (ViewStateOnServer)
			{
				ToSession(viewState);
			}
			else
			{
				base.SavePageStateToPersistenceMedium (viewState);
			}
		}

		protected override object LoadPageStateFromPersistenceMedium()
		{
			if (ViewStateOnServer)
			{
				return FromSession();
			}
			else
			{
				return base.LoadPageStateFromPersistenceMedium ();
			}
		}

		public void ToSession(object viewState)
		{
			MemoryStream ms = new MemoryStream();
			LosFormatter lf;
			HttpContext ctx;

			try
			{
				ctx = HttpContext.Current;
				lf = new LosFormatter();
				lf.Serialize(ms, viewState);

				ctx.Session.Add("MyViewState", ms);
			}
			catch (Exception ex)
			{
				throw(ex);
			}


		}

		public object FromSession()
		{
			object ViewState;
			string strView;
			StreamReader sr;
			LosFormatter lf;
			HttpContext ctx;
			MemoryStream ms;

			try
			{
				ctx = HttpContext.Current;
				ms = (MemoryStream) ctx.Session["MyViewState"];
				ms.Position = 0;
				sr = new StreamReader(ms);
				strView = sr.ReadToEnd();
				sr.Close();

				lf = new LosFormatter();
				ViewState = lf.Deserialize(strView);
			}
			catch
			{
				throw new ApplicationException("View State is Invalid");
			}

			return ViewState;
		}


		#endregion
	}
}
