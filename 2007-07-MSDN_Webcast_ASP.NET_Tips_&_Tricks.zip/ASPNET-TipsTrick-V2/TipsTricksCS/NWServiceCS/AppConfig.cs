using System;
using System.Configuration;

namespace NWServiceCS
{
	/// <summary>
	/// Summary description for AppConfig.
	/// </summary>
	public class AppConfig
	{
		public AppConfig()
		{
		}

		public static string ConnectString
		{
			get { return ConfigurationSettings.AppSettings["ConnectString"]; }
		}
	}
}
