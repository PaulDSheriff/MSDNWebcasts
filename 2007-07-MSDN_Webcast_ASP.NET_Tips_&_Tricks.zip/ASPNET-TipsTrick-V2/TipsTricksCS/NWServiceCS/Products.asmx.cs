using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace NWServiceCS
{
	/// <summary>
	/// Summary description for Products.
	/// </summary>
	public class Products : System.Web.Services.WebService
	{
		public Products()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		// WEB SERVICE EXAMPLE
		// The HelloWorld() example service returns the string Hello World
		// To build, uncomment the following lines then save and build the project
		// To test this web service, press F5

		[WebMethod]
		public string GetProducts(int CategoryID)
		{
			SqlDataReader dr;
			SqlConnection cnn;
			SqlCommand cmd;
			string strRet;
			string strSQL;

			strSQL = "SELECT ProductName, ProductID FROM Products ";
			strSQL += " WHERE CategoryID = @CategoryID";

			cnn = new SqlConnection(AppConfig.ConnectString);
			cmd = new SqlCommand(strSQL);
			cmd.Parameters.Add(new SqlParameter("@CategoryID", SqlDbType.Int));
			cmd.Parameters["@CategoryID"].Value = CategoryID;

			cmd.Connection = cnn;
			cmd.Connection.Open();
			dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

			strRet = " : ";
			while (dr.Read())
			{
				strRet += "|" + dr["ProductName"].ToString() +
					":" + dr["ProductID"].ToString();
			}

			dr.Close();

			return strRet;
		}
	}
}
