Public Class WebAppConfig
   Public Shared ReadOnly Property ConnectString() As String
      Get
         Return System.Configuration.ConfigurationSettings.AppSettings("ConnectString")
      End Get
   End Property
End Class
