Public Class _Default
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

   End Sub
   Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
   Protected WithEvents grdProducts As System.Web.UI.WebControls.DataGrid
   Protected WithEvents ddlCategories As System.Web.UI.WebControls.DropDownList
   Protected WithEvents Label1 As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

   Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      If Not Page.IsPostBack Then
         LoadCategories()
         LoadProducts(WebAppConfig.ConnectString)
      End If
   End Sub

   Private Sub LoadCategories()
      Dim strSQL As String
      Dim ds As New DataSet
      Dim da As SqlClient.SqlDataAdapter

      Try
         strSQL = "SELECT CategoryID, CategoryName FROM Categories"

         da = New SqlClient.SqlDataAdapter(strSQL, WebAppConfig.ConnectString)
         da.Fill(ds)

         ddlCategories.DataTextField = "CategoryName"
         ddlCategories.DataValueField = "CategoryID"
         ddlCategories.DataSource = ds.Tables(0)
         ddlCategories.DataBind()

      Catch ex As Exception
         lblMessage.Text = ex.Message
      End Try
   End Sub

   Private Sub ddlCategories_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlCategories.SelectedIndexChanged
      LoadProducts(WebAppConfig.ConnectString)
   End Sub

   Private Sub LoadProducts(ByVal ConnectString As String)
      Dim strSQL As String
      Dim ds As New DataSet
      Dim da As SqlClient.SqlDataAdapter

      Try
         strSQL = "SELECT ProductID, ProductName, UnitPrice, UnitsInStock FROM Products "
         strSQL &= " WHERE CategoryID = " & ddlCategories.SelectedItem.Value

         da = New SqlClient.SqlDataAdapter(strSQL, WebAppConfig.ConnectString)
         da.Fill(ds)

         grdProducts.DataSource = ds
         grdProducts.DataBind()

      Catch ex As Exception
         lblMessage.Text = ex.Message
      End Try
   End Sub

End Class
