'Copyright (C) 2002 Microsoft Corporation
'All rights reserved.
'THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
'EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
'MERCHANTIBILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

'Requires the Trial or Release version of Visual Studio .NET Professional (or greater).

Option Strict On

' Child class for inheritance demo.
Public Class PartTimeEmployee
  Inherits Employee

  Public Sub New(ByVal strName As String, ByVal strEmployeeID As String)
    MyBase.New(strName, strEmployeeID)
  End Sub

  Private dblMinHoursPerWeek As Double

  Public Overrides ReadOnly Property Bonus() As Decimal
    Get
      Return _decSalary * CType(0.005, Decimal)
    End Get
  End Property

  Public Property MinHoursPerWeek() As Double
    Get
      Return dblMinHoursPerWeek
    End Get
    Set(ByVal Value As Double)
      dblMinHoursPerWeek = Value
    End Set
  End Property

  Public Overrides Property Salary() As Decimal
    Get
      Return _decSalary
    End Get
    Set(ByVal Value As Decimal)
      If Value < 10000.0 Or Value > 30000.0 Then
        Throw New ArgumentOutOfRangeException( _
              "Salary", "Part-time employee salary must " & _
              "be between $10,000 and $30,000")
      Else
        _decSalary = Value
      End If
    End Set
  End Property

  Public Shadows Sub Hire(ByVal HireDate As DateTime, _
      ByVal StartingSalary As Decimal, ByVal MinHoursPerWeek As Double)

    MyBase.Hire(HireDate, StartingSalary)
    dblMinHoursPerWeek = MinHoursPerWeek
  End Sub
End Class
