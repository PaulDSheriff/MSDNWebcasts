'Copyright (C) 2002 Microsoft Corporation
'All rights reserved.
'THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
'EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
'MERCHANTIBILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

'Requires the Trial or Release version of Visual Studio .NET Professional (or greater).

Option Strict On
Imports System.IO
Imports System.Text

Public Class frmMain
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

    ' So that we only need to set the title of the application once,
    ' we use the AssemblyInfo class (defined in the AssemblyInfo.vb file)
    ' to read the AssemblyTitle attribute.
    Dim ainfo As New AssemblyInfo()

    Me.Text = ainfo.Title
    Me.mnuAbout.Text = String.Format("&About {0} ...", ainfo.Title)

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.
  'Do not modify it using the code editor.
  Friend WithEvents mnuMain As System.Windows.Forms.MainMenu
  Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
  Friend WithEvents mnuExit As System.Windows.Forms.MenuItem
  Friend WithEvents mnuHelp As System.Windows.Forms.MenuItem
  Friend WithEvents mnuAbout As System.Windows.Forms.MenuItem
  Friend WithEvents sbrStatus As System.Windows.Forms.StatusBar
  Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents pgeInheritance As System.Windows.Forms.TabPage
  Friend WithEvents sbrPanel1 As System.Windows.Forms.StatusBarPanel
  Friend WithEvents sbrPanel2 As System.Windows.Forms.StatusBarPanel
  Friend WithEvents pgeExceptionHandling As System.Windows.Forms.TabPage
  Friend WithEvents btnClear As System.Windows.Forms.Button
  Friend WithEvents txtResults As System.Windows.Forms.TextBox
  Friend WithEvents btnHire As System.Windows.Forms.Button
  Friend WithEvents Label5 As System.Windows.Forms.Label
  Friend WithEvents Label17 As System.Windows.Forms.Label
  Friend WithEvents Label18 As System.Windows.Forms.Label
  Friend WithEvents Label19 As System.Windows.Forms.Label
  Friend WithEvents txtSalary As System.Windows.Forms.TextBox
  Friend WithEvents txtHireDate As System.Windows.Forms.TextBox
  Friend WithEvents txtName As System.Windows.Forms.TextBox
  Friend WithEvents Label20 As System.Windows.Forms.Label
  Friend WithEvents cboEmployeeType As System.Windows.Forms.ComboBox
  Friend WithEvents Label21 As System.Windows.Forms.Label
  Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
  Friend WithEvents pgeForms As System.Windows.Forms.TabPage
  Friend WithEvents Panel1 As System.Windows.Forms.Panel
  Friend WithEvents txtExp As System.Windows.Forms.TextBox
  Friend WithEvents btnCauseError As System.Windows.Forms.Button
  Friend WithEvents txtEmployeeID As System.Windows.Forms.TextBox
  Friend WithEvents Splitter1 As System.Windows.Forms.Splitter
  Friend WithEvents Panel2 As System.Windows.Forms.Panel
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
    Me.mnuMain = New System.Windows.Forms.MainMenu()
    Me.mnuFile = New System.Windows.Forms.MenuItem()
    Me.mnuExit = New System.Windows.Forms.MenuItem()
    Me.mnuHelp = New System.Windows.Forms.MenuItem()
    Me.mnuAbout = New System.Windows.Forms.MenuItem()
    Me.sbrStatus = New System.Windows.Forms.StatusBar()
    Me.sbrPanel1 = New System.Windows.Forms.StatusBarPanel()
    Me.sbrPanel2 = New System.Windows.Forms.StatusBarPanel()
    Me.TabControl1 = New System.Windows.Forms.TabControl()
    Me.pgeForms = New System.Windows.Forms.TabPage()
    Me.Panel1 = New System.Windows.Forms.Panel()
    Me.Panel2 = New System.Windows.Forms.Panel()
    Me.Splitter1 = New System.Windows.Forms.Splitter()
    Me.pgeExceptionHandling = New System.Windows.Forms.TabPage()
    Me.txtExp = New System.Windows.Forms.TextBox()
    Me.btnCauseError = New System.Windows.Forms.Button()
    Me.pgeInheritance = New System.Windows.Forms.TabPage()
    Me.Label21 = New System.Windows.Forms.Label()
    Me.btnClear = New System.Windows.Forms.Button()
    Me.txtResults = New System.Windows.Forms.TextBox()
    Me.btnHire = New System.Windows.Forms.Button()
    Me.Label5 = New System.Windows.Forms.Label()
    Me.Label17 = New System.Windows.Forms.Label()
    Me.Label18 = New System.Windows.Forms.Label()
    Me.Label19 = New System.Windows.Forms.Label()
    Me.txtEmployeeID = New System.Windows.Forms.TextBox()
    Me.txtSalary = New System.Windows.Forms.TextBox()
    Me.txtHireDate = New System.Windows.Forms.TextBox()
    Me.txtName = New System.Windows.Forms.TextBox()
    Me.Label20 = New System.Windows.Forms.Label()
    Me.cboEmployeeType = New System.Windows.Forms.ComboBox()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
    CType(Me.sbrPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.sbrPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.TabControl1.SuspendLayout()
    Me.pgeForms.SuspendLayout()
    Me.Panel1.SuspendLayout()
    Me.pgeExceptionHandling.SuspendLayout()
    Me.pgeInheritance.SuspendLayout()
    Me.SuspendLayout()
    '
    'mnuMain
    '
    Me.mnuMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuHelp})
    '
    'mnuFile
    '
    Me.mnuFile.Index = 0
    Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuExit})
    Me.mnuFile.Text = "&File"
    '
    'mnuExit
    '
    Me.mnuExit.Index = 0
    Me.mnuExit.Text = "E&xit"
    '
    'mnuHelp
    '
    Me.mnuHelp.Index = 1
    Me.mnuHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAbout})
    Me.mnuHelp.Text = "&Help"
    '
    'mnuAbout
    '
    Me.mnuAbout.Index = 0
    Me.mnuAbout.Text = "Text Comes from AssemblyInfo"
    '
    'sbrStatus
    '
    Me.sbrStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.sbrStatus.Location = New System.Drawing.Point(0, 409)
    Me.sbrStatus.Name = "sbrStatus"
    Me.sbrStatus.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.sbrPanel1, Me.sbrPanel2})
    Me.sbrStatus.ShowPanels = True
    Me.sbrStatus.Size = New System.Drawing.Size(640, 24)
    Me.sbrStatus.SizingGrip = False
    Me.sbrStatus.TabIndex = 2
    '
    'sbrPanel1
    '
    Me.sbrPanel1.BorderStyle = System.Windows.Forms.StatusBarPanelBorderStyle.None
    Me.sbrPanel1.Width = 15
    '
    'sbrPanel2
    '
    Me.sbrPanel2.BorderStyle = System.Windows.Forms.StatusBarPanelBorderStyle.None
    Me.sbrPanel2.MinWidth = 10000
    Me.sbrPanel2.Width = 10000
    '
    'TabControl1
    '
    Me.TabControl1.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right)
    Me.TabControl1.Controls.AddRange(New System.Windows.Forms.Control() {Me.pgeForms, Me.pgeExceptionHandling, Me.pgeInheritance})
    Me.TabControl1.Location = New System.Drawing.Point(16, 48)
    Me.TabControl1.Name = "TabControl1"
    Me.TabControl1.SelectedIndex = 0
    Me.TabControl1.Size = New System.Drawing.Size(600, 344)
    Me.TabControl1.TabIndex = 0
    '
    'pgeForms
    '
    Me.pgeForms.Controls.AddRange(New System.Windows.Forms.Control() {Me.Panel1})
    Me.pgeForms.Location = New System.Drawing.Point(4, 22)
    Me.pgeForms.Name = "pgeForms"
    Me.pgeForms.Size = New System.Drawing.Size(592, 318)
    Me.pgeForms.TabIndex = 8
    Me.pgeForms.Text = "Form Layout"
    '
    'Panel1
    '
    Me.Panel1.Controls.AddRange(New System.Windows.Forms.Control() {Me.Panel2, Me.Splitter1})
    Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
    Me.Panel1.Name = "Panel1"
    Me.Panel1.Size = New System.Drawing.Size(592, 318)
    Me.Panel1.TabIndex = 2
    '
    'Panel2
    '
    Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
    Me.Panel2.Location = New System.Drawing.Point(3, 0)
    Me.Panel2.Name = "Panel2"
    Me.Panel2.Size = New System.Drawing.Size(589, 318)
    Me.Panel2.TabIndex = 2
    '
    'Splitter1
    '
    Me.Splitter1.Name = "Splitter1"
    Me.Splitter1.Size = New System.Drawing.Size(3, 318)
    Me.Splitter1.TabIndex = 1
    Me.Splitter1.TabStop = False
    '
    'pgeExceptionHandling
    '
    Me.pgeExceptionHandling.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtExp, Me.btnCauseError})
    Me.pgeExceptionHandling.Location = New System.Drawing.Point(4, 22)
    Me.pgeExceptionHandling.Name = "pgeExceptionHandling"
    Me.pgeExceptionHandling.Size = New System.Drawing.Size(592, 318)
    Me.pgeExceptionHandling.TabIndex = 3
    Me.pgeExceptionHandling.Text = "Exception Handling"
    '
    'txtExp
    '
    Me.txtExp.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right)
    Me.txtExp.Location = New System.Drawing.Point(8, 16)
    Me.txtExp.Multiline = True
    Me.txtExp.Name = "txtExp"
    Me.txtExp.ScrollBars = System.Windows.Forms.ScrollBars.Both
    Me.txtExp.Size = New System.Drawing.Size(576, 216)
    Me.txtExp.TabIndex = 2
    Me.txtExp.Text = ""
    '
    'btnCauseError
    '
    Me.btnCauseError.Location = New System.Drawing.Point(9, 240)
    Me.btnCauseError.Name = "btnCauseError"
    Me.btnCauseError.Size = New System.Drawing.Size(176, 23)
    Me.btnCauseError.TabIndex = 3
    Me.btnCauseError.Text = "&Cause Error"
    '
    'pgeInheritance
    '
    Me.pgeInheritance.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label21, Me.btnClear, Me.txtResults, Me.btnHire, Me.Label5, Me.Label17, Me.Label18, Me.Label19, Me.txtEmployeeID, Me.txtSalary, Me.txtHireDate, Me.txtName, Me.Label20, Me.cboEmployeeType})
    Me.pgeInheritance.Location = New System.Drawing.Point(4, 22)
    Me.pgeInheritance.Name = "pgeInheritance"
    Me.pgeInheritance.Size = New System.Drawing.Size(592, 318)
    Me.pgeInheritance.TabIndex = 4
    Me.pgeInheritance.Text = "Inheritance"
    '
    'Label21
    '
    Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label21.Location = New System.Drawing.Point(51, 24)
    Me.Label21.Name = "Label21"
    Me.Label21.Size = New System.Drawing.Size(264, 23)
    Me.Label21.TabIndex = 32
    Me.Label21.Text = "Employee Management"
    '
    'btnClear
    '
    Me.btnClear.AccessibleDescription = "Clear data"
    Me.btnClear.AccessibleName = "btnClear"
    Me.btnClear.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
    Me.btnClear.Location = New System.Drawing.Point(456, 208)
    Me.btnClear.Name = "btnClear"
    Me.btnClear.Size = New System.Drawing.Size(72, 23)
    Me.btnClear.TabIndex = 30
    Me.btnClear.Text = "&Clear"
    '
    'txtResults
    '
    Me.txtResults.AccessibleDescription = "Results"
    Me.txtResults.AccessibleName = "txtResults"
    Me.txtResults.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right)
    Me.txtResults.BackColor = System.Drawing.SystemColors.Menu
    Me.txtResults.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.txtResults.Location = New System.Drawing.Point(331, 64)
    Me.txtResults.Multiline = True
    Me.txtResults.Name = "txtResults"
    Me.txtResults.ReadOnly = True
    Me.txtResults.Size = New System.Drawing.Size(229, 136)
    Me.txtResults.TabIndex = 31
    Me.txtResults.Text = ""
    '
    'btnHire
    '
    Me.btnHire.AccessibleDescription = "Hire button"
    Me.btnHire.AccessibleName = "btnHire"
    Me.btnHire.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
    Me.btnHire.Enabled = False
    Me.btnHire.Location = New System.Drawing.Point(376, 208)
    Me.btnHire.Name = "btnHire"
    Me.btnHire.Size = New System.Drawing.Size(72, 23)
    Me.btnHire.TabIndex = 28
    Me.btnHire.Text = "H&ire"
    '
    'Label5
    '
    Me.Label5.AutoSize = True
    Me.Label5.Location = New System.Drawing.Point(48, 179)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(69, 13)
    Me.Label5.TabIndex = 24
    Me.Label5.Text = "Employee ID"
    '
    'Label17
    '
    Me.Label17.AutoSize = True
    Me.Label17.Location = New System.Drawing.Point(48, 152)
    Me.Label17.Name = "Label17"
    Me.Label17.Size = New System.Drawing.Size(36, 13)
    Me.Label17.TabIndex = 22
    Me.Label17.Text = "Salary"
    '
    'Label18
    '
    Me.Label18.AutoSize = True
    Me.Label18.Location = New System.Drawing.Point(48, 124)
    Me.Label18.Name = "Label18"
    Me.Label18.Size = New System.Drawing.Size(52, 13)
    Me.Label18.TabIndex = 20
    Me.Label18.Text = "Hire Date"
    '
    'Label19
    '
    Me.Label19.AutoSize = True
    Me.Label19.Location = New System.Drawing.Point(48, 96)
    Me.Label19.Name = "Label19"
    Me.Label19.Size = New System.Drawing.Size(34, 13)
    Me.Label19.TabIndex = 18
    Me.Label19.Text = "Name"
    '
    'txtEmployeeID
    '
    Me.txtEmployeeID.AccessibleDescription = "Social Services ID"
    Me.txtEmployeeID.AccessibleName = "txtSocialSecurityID"
    Me.txtEmployeeID.Enabled = False
    Me.txtEmployeeID.Location = New System.Drawing.Point(163, 175)
    Me.txtEmployeeID.Name = "txtEmployeeID"
    Me.txtEmployeeID.Size = New System.Drawing.Size(160, 20)
    Me.txtEmployeeID.TabIndex = 25
    Me.txtEmployeeID.Text = ""
    '
    'txtSalary
    '
    Me.txtSalary.AccessibleDescription = "Salary"
    Me.txtSalary.AccessibleName = "txtSalary"
    Me.txtSalary.Enabled = False
    Me.txtSalary.Location = New System.Drawing.Point(163, 147)
    Me.txtSalary.Name = "txtSalary"
    Me.txtSalary.Size = New System.Drawing.Size(160, 20)
    Me.txtSalary.TabIndex = 23
    Me.txtSalary.Text = ""
    '
    'txtHireDate
    '
    Me.txtHireDate.AccessibleDescription = "Hire date"
    Me.txtHireDate.AccessibleName = "txtHireDate"
    Me.txtHireDate.Enabled = False
    Me.txtHireDate.Location = New System.Drawing.Point(163, 120)
    Me.txtHireDate.Name = "txtHireDate"
    Me.txtHireDate.Size = New System.Drawing.Size(160, 20)
    Me.txtHireDate.TabIndex = 21
    Me.txtHireDate.Text = ""
    '
    'txtName
    '
    Me.txtName.AccessibleDescription = "Employee name"
    Me.txtName.Enabled = False
    Me.txtName.Location = New System.Drawing.Point(163, 93)
    Me.txtName.Name = "txtName"
    Me.txtName.Size = New System.Drawing.Size(160, 20)
    Me.txtName.TabIndex = 19
    Me.txtName.Text = ""
    '
    'Label20
    '
    Me.Label20.AutoSize = True
    Me.Label20.Location = New System.Drawing.Point(48, 67)
    Me.Label20.Name = "Label20"
    Me.Label20.Size = New System.Drawing.Size(79, 13)
    Me.Label20.TabIndex = 16
    Me.Label20.Text = "Employee &type"
    '
    'cboEmployeeType
    '
    Me.cboEmployeeType.AccessibleDescription = "Employee type combo box"
    Me.cboEmployeeType.AccessibleName = "cboEmployeeType"
    Me.cboEmployeeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cboEmployeeType.Items.AddRange(New Object() {"Full-time", "Part-time"})
    Me.cboEmployeeType.Location = New System.Drawing.Point(163, 64)
    Me.cboEmployeeType.Name = "cboEmployeeType"
    Me.cboEmployeeType.Size = New System.Drawing.Size(160, 21)
    Me.cboEmployeeType.TabIndex = 17
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label1.Location = New System.Drawing.Point(16, 16)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(179, 19)
    Me.Label1.TabIndex = 0
    Me.Label1.Text = "Key VB. NET Changes"
    '
    'frmMain
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.AutoScroll = True
    Me.ClientSize = New System.Drawing.Size(640, 433)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.TabControl1, Me.sbrStatus})
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.MaximizeBox = False
    Me.Menu = Me.mnuMain
    Me.Name = "frmMain"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Title Comes from Assembly Info"
    CType(Me.sbrPanel1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.sbrPanel2, System.ComponentModel.ISupportInitialize).EndInit()
    Me.TabControl1.ResumeLayout(False)
    Me.pgeForms.ResumeLayout(False)
    Me.Panel1.ResumeLayout(False)
    Me.pgeExceptionHandling.ResumeLayout(False)
    Me.pgeInheritance.ResumeLayout(False)
    Me.ResumeLayout(False)

  End Sub

#End Region

#Region " Standard Menu Code "
  ' <System.Diagnostics.DebuggerStepThrough()> has been added to some procedures since they are
  ' not the focus of the demo. Remove them if you wish to debug the procedures.
  ' This code simply shows the About form.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub mnuAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAbout.Click
    ' Open the About form in Dialog Mode
    Dim frm As New frmAbout()
    frm.ShowDialog(Me)
    frm.Dispose()
  End Sub

  ' This code will close the form.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub mnuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuExit.Click
    ' Close the current form
    Me.Close()
  End Sub
#End Region

#Region " Exception Tab "

  ' This routine handles the Click event of the "Cause Error" button.
  Private Sub asdf(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCauseError.Click
    Try
      Dim txt As New TextBox()
      txt.Text = "hello"
      ' Force an error by passing an invalid path when creating a StreamReader.
      Dim sr As New StreamReader("c:\12345678asdf\baddirectory.txt")
    Catch exp As DirectoryNotFoundException
      ' Use StringBuilder instead of traditional string concatenation as it
      ' performs better.
      Dim sb As New StringBuilder()

      With exp
        sb.Append("================== Message ==================")
        sb.Append(vbCrLf)
        sb.Append(vbCrLf)
        sb.Append(.Message)
        sb.Append(vbCrLf)
        sb.Append(vbCrLf)
        sb.Append("================ StackTrace ================")
        sb.Append(vbCrLf)
        sb.Append(vbCrLf)
        sb.Append(.StackTrace)
        sb.Append(vbCrLf)
        sb.Append(vbCrLf)
        sb.Append("================= ToString() =================")
        sb.Append(vbCrLf)
        sb.Append(vbCrLf)
        sb.Append(.ToString)
      End With

      txtExp.Text = sb.ToString
    Catch exp As IOException
      ' Do Nothing.
    Catch exp As Exception
      ' Catch any other kind of error.
      MessageBox.Show(exp.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Try
  End Sub

#End Region

#Region " Inheritance Tab "

  ' Clear the summary textbox.
  Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
    Dim ctl As Control
    cboEmployeeType.SelectedIndex = -1
    For Each ctl In pgeInheritance.Controls
      If TypeOf ctl Is TextBox Then
        ctl.Text = ""
      End If
    Next
  End Sub

  ' Hire an employee.
  Private Sub btnHire_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHire.Click
    If DataIsValid() Then
      If cboEmployeeType.SelectedIndex = 0 Then
        HireFullTimeEmployee()
      Else
        HirePartTimeEmployee()
      End If
    End If
  End Sub

  ' Monitors changes to TextBoxes for UI feedback.
  Private Sub TextBoxes_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtName.TextChanged, txtHireDate.TextChanged, txtSalary.TextChanged, cboEmployeeType.SelectedIndexChanged, txtEmployeeID.TextChanged
    ' Create an instance of the PartTimeEmployee class which is derived from
    ' Employee.
    Select Case cboEmployeeType.SelectedIndex
      Case -1
        txtName.Enabled = False
        txtHireDate.Enabled = False
        txtSalary.Enabled = False
        txtEmployeeID.Enabled = False
      Case Else
        txtName.Enabled = True
        txtHireDate.Enabled = True
        txtSalary.Enabled = True
        txtEmployeeID.Enabled = True
    End Select

    btnHire.Enabled = _
        txtName.Text.Trim.Length <> 0 And _
        txtHireDate.Text.Trim.Length <> 0 And _
        txtSalary.Text.Trim.Length <> 0 And _
        txtEmployeeID.Text.Trim.Length <> 0
  End Sub

  ' Ensures data entered by user is valid.
  Private Function DataIsValid() As Boolean
    ' Called by the Hire event handler.  Simply checks to make sure that 
    ' two values HireDate and SocialSecurityID are in the correct format.
    If Not IsDate(txtHireDate.Text) Then
      MsgBox("You must enter a valid date.", _
          MsgBoxStyle.Exclamation, Me.Text)
      Return False
    End If

    If txtEmployeeID.Text.Length <> 8 Then
      MsgBox("Employee ID must be 8 numeric characters", _
        MsgBoxStyle.Exclamation, Me.Text)
      Return False
    End If

    Return True
  End Function

  ' Simulates hiring a full time employee and displays the results.
  Private Sub HireFullTimeEmployee()
    Try
      Dim emp As New FullTimeEmployee(txtName.Text.Trim, _
          txtEmployeeID.Text.Trim)
      With emp
        .Hire(CType(txtHireDate.Text.Trim, DateTime), _
            CType(txtSalary.Text.Trim, Decimal))

        txtResults.Text = _
            ShowResults(emp) & vbCrLf & _
            "Annual Leave: " & .AnnualLeave & " days"
      End With
    Catch exp As Exception
      MsgBox(exp.Message, MsgBoxStyle.Critical, Me.Text)
    End Try
  End Sub

  ' Simulates hiring a part time employee and displays the results.
  Private Sub HirePartTimeEmployee()
    Try
      Dim emp As New PartTimeEmployee(txtName.Text.Trim, _
          txtEmployeeID.Text.Trim)
      With emp
        .Hire(CType(txtHireDate.Text.Trim, DateTime), _
            CType(txtSalary.Text.Trim, Decimal), 20)
        .EmployeeID = txtEmployeeID.Text.Trim

        txtResults.Text = _
            ShowResults(emp) & vbCrLf & _
            "Min hrs. per week: " & .MinHoursPerWeek
      End With
    Catch exp As Exception
      MsgBox(exp.Message, MsgBoxStyle.Critical, Me.Text)
    End Try
  End Sub

  ' Helper function to display the hiring results.
  Private Function ShowResults(ByVal emp As Employee) As String
    With emp
      txtResults.Clear()
      Return "Name: " & .Name & vbCrLf & _
          "Hire date: " & .HireDate & vbCrLf & _
          "Salary: " & .Salary.ToString("c") & vbCrLf & _
          "Employee ID: " & .EmployeeID & vbCrLf & _
          "Bonus: " & .Bonus.ToString("c")
    End With
  End Function

#End Region

End Class
