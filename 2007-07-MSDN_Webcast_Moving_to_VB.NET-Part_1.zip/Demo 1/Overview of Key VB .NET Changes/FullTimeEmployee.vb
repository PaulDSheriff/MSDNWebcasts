'Copyright (C) 2002 Microsoft Corporation
'All rights reserved.
'THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
'EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
'MERCHANTIBILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

'Requires the Trial or Release version of Visual Studio .NET Professional (or greater).

Option Strict On

' Child class for inheritance demo.
Public Class FullTimeEmployee
  Inherits Employee

  Public Sub New(ByVal strName As String, ByVal strEmployeeID As String)
    MyBase.New(strName, strEmployeeID)
  End Sub

  Public ReadOnly Property AnnualLeave() As Integer
    Get
      Return 42
    End Get
  End Property

  Public Overrides ReadOnly Property Bonus() As Decimal
    Get
      Return _decSalary * CType(0.01, Decimal)
    End Get
  End Property

  Public Overrides Property Salary() As Decimal
    Get
      Return _decSalary
    End Get
    Set(ByVal Value As Decimal)
      If Value < 30000.0 Or Value > 500000.0 Then
        Throw New ArgumentOutOfRangeException( _
              "Salary", _
              "Full-time employee salary must be between " & _
              "$30,000 and $500,000")
      Else
        _decSalary = Value
      End If
    End Set
  End Property
End Class
