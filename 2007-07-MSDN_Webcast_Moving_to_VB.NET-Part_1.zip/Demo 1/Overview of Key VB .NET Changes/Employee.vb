'Copyright (C) 2002 Microsoft Corporation
'All rights reserved.
'THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
'EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
'MERCHANTIBILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

'Requires the Trial or Release version of Visual Studio .NET Professional (or greater).

Option Strict On

' Base class for inheritance demo.
Public MustInherit Class Employee
  Private _datHire As DateTime
  Protected _decSalary As Decimal
  Private _strEmpID As String
  Private _strName As String

  Public Sub New(ByVal strName As String, ByVal strEmployeeID As String)
    _strName = strName
    _strEmpID = strEmployeeID
    _datHire = DateTime.Now.Date
  End Sub

  Public MustOverride ReadOnly Property Bonus() As Decimal

  Public Property EmployeeID() As String
    Get
      Return _strEmpID
    End Get

    Set(ByVal Value As String)
      If IsNumeric(Value) And Len(Value) = 8 Then
        _strEmpID = Value
      Else
        Throw New ArgumentException( _
            "Employee ID must be 8 numeric characters", "Employee ID")
      End If
    End Set
  End Property

  Public Property HireDate() As Date
    Get
      Return _datHire
    End Get
    Set(ByVal Value As Date)
      If Not IsDate(Value) Then
        Throw New ArgumentException( _
            "Invalid date.", "HireDate")
      Else
        If Value <= DateTime.Now.Date Then
          _datHire = Value
        Else
          Throw New ArgumentException( _
              "Hire Date cannot be later than today.", "HireDate")
        End If
      End If
    End Set
  End Property

  Public Property Name() As String
    Get
      Return _strName
    End Get
    Set(ByVal Value As String)
      _strName = Value
    End Set
  End Property

  Public MustOverride Property Salary() As Decimal

  Public Sub Hire(ByVal datHire As DateTime, ByVal decSalary As Decimal)
    HireDate = datHire
    Salary = decSalary
  End Sub
End Class
