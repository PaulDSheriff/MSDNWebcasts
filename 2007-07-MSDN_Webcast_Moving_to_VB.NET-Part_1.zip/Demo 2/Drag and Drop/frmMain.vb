'Copyright (C) 2002 Microsoft Corporation
'All rights reserved.
'THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER 
'EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF 
'MERCHANTIBILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

'Requires the Trial or Release version of Visual Studio .NET Professional (or greater).

Option Strict On

Public Class frmMain
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

    ' So that we only need to set the title of the application once,
    ' we use the AssemblyInfo class (defined in the AssemblyInfo.vb file)
    ' to read the AssemblyTitle attribute.
    Dim ainfo As New AssemblyInfo()

    Me.Text = ainfo.Title
    Me.mnuAbout.Text = String.Format("&About {0} ...", ainfo.Title)

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  Friend WithEvents mnuMain As System.Windows.Forms.MainMenu
  Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
  Friend WithEvents mnuExit As System.Windows.Forms.MenuItem
  Friend WithEvents mnuHelp As System.Windows.Forms.MenuItem
  Friend WithEvents mnuAbout As System.Windows.Forms.MenuItem
  Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
  Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
  Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
  Friend WithEvents tvwLeft As System.Windows.Forms.TreeView
  Friend WithEvents tvwRight As System.Windows.Forms.TreeView
  Friend WithEvents picRight As System.Windows.Forms.PictureBox
  Friend WithEvents picLeft As System.Windows.Forms.PictureBox
  Friend WithEvents txtLeft As System.Windows.Forms.TextBox
  Friend WithEvents txtUpperRight As System.Windows.Forms.TextBox
  Friend WithEvents txtLowerRight As System.Windows.Forms.TextBox
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
    Me.mnuMain = New System.Windows.Forms.MainMenu()
    Me.mnuFile = New System.Windows.Forms.MenuItem()
    Me.mnuExit = New System.Windows.Forms.MenuItem()
    Me.mnuHelp = New System.Windows.Forms.MenuItem()
    Me.mnuAbout = New System.Windows.Forms.MenuItem()
    Me.TabControl1 = New System.Windows.Forms.TabControl()
    Me.TabPage1 = New System.Windows.Forms.TabPage()
    Me.txtLeft = New System.Windows.Forms.TextBox()
    Me.txtUpperRight = New System.Windows.Forms.TextBox()
    Me.txtLowerRight = New System.Windows.Forms.TextBox()
    Me.TabPage2 = New System.Windows.Forms.TabPage()
    Me.tvwLeft = New System.Windows.Forms.TreeView()
    Me.tvwRight = New System.Windows.Forms.TreeView()
    Me.TabPage3 = New System.Windows.Forms.TabPage()
    Me.picRight = New System.Windows.Forms.PictureBox()
    Me.picLeft = New System.Windows.Forms.PictureBox()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.TabControl1.SuspendLayout()
    Me.TabPage1.SuspendLayout()
    Me.TabPage2.SuspendLayout()
    Me.TabPage3.SuspendLayout()
    Me.SuspendLayout()
    '
    'mnuMain
    '
    Me.mnuMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuHelp})
    '
    'mnuFile
    '
    Me.mnuFile.Index = 0
    Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuExit})
    Me.mnuFile.Text = "&File"
    '
    'mnuExit
    '
    Me.mnuExit.Index = 0
    Me.mnuExit.Text = "E&xit"
    '
    'mnuHelp
    '
    Me.mnuHelp.Index = 1
    Me.mnuHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAbout})
    Me.mnuHelp.Text = "&Help"
    '
    'mnuAbout
    '
    Me.mnuAbout.Index = 0
    Me.mnuAbout.Text = "Text Comes from AssemblyInfo"
    '
    'TabControl1
    '
    Me.TabControl1.Controls.AddRange(New System.Windows.Forms.Control() {Me.TabPage1, Me.TabPage2, Me.TabPage3})
    Me.TabControl1.Location = New System.Drawing.Point(21, 56)
    Me.TabControl1.Name = "TabControl1"
    Me.TabControl1.SelectedIndex = 0
    Me.TabControl1.Size = New System.Drawing.Size(504, 240)
    Me.TabControl1.TabIndex = 30
    '
    'TabPage1
    '
    Me.TabPage1.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtLeft, Me.txtUpperRight, Me.txtLowerRight})
    Me.TabPage1.Location = New System.Drawing.Point(4, 22)
    Me.TabPage1.Name = "TabPage1"
    Me.TabPage1.Size = New System.Drawing.Size(496, 214)
    Me.TabPage1.TabIndex = 0
    Me.TabPage1.Text = "TextBox"
    '
    'txtLeft
    '
    Me.txtLeft.AccessibleDescription = "TextBox with ""Source Text"""
    Me.txtLeft.AccessibleName = "Drag Source TextBox"
    Me.txtLeft.AllowDrop = True
    Me.txtLeft.Location = New System.Drawing.Point(24, 81)
    Me.txtLeft.Name = "txtLeft"
    Me.txtLeft.Size = New System.Drawing.Size(192, 20)
    Me.txtLeft.TabIndex = 3
    Me.txtLeft.Text = "Source Text"
    '
    'txtUpperRight
    '
    Me.txtUpperRight.AccessibleDescription = "TextBox with ""AllowDrop = False"""
    Me.txtUpperRight.AccessibleName = "Drag Target TextBox that doesn't allow drop"
    Me.txtUpperRight.Location = New System.Drawing.Point(264, 81)
    Me.txtUpperRight.Name = "txtUpperRight"
    Me.txtUpperRight.Size = New System.Drawing.Size(208, 20)
    Me.txtUpperRight.TabIndex = 4
    Me.txtUpperRight.Text = "AllowDrop = False"
    '
    'txtLowerRight
    '
    Me.txtLowerRight.AccessibleDescription = "TextBox with ""AllowDrop = True"""
    Me.txtLowerRight.AccessibleName = "Drag Target TextBox that allows drop"
    Me.txtLowerRight.AllowDrop = True
    Me.txtLowerRight.Location = New System.Drawing.Point(264, 113)
    Me.txtLowerRight.Name = "txtLowerRight"
    Me.txtLowerRight.Size = New System.Drawing.Size(208, 20)
    Me.txtLowerRight.TabIndex = 5
    Me.txtLowerRight.Text = "AllowDrop = True"
    '
    'TabPage2
    '
    Me.TabPage2.Controls.AddRange(New System.Windows.Forms.Control() {Me.tvwLeft, Me.tvwRight})
    Me.TabPage2.Location = New System.Drawing.Point(4, 22)
    Me.TabPage2.Name = "TabPage2"
    Me.TabPage2.Size = New System.Drawing.Size(496, 214)
    Me.TabPage2.TabIndex = 1
    Me.TabPage2.Text = "TreeView"
    '
    'tvwLeft
    '
    Me.tvwLeft.AccessibleDescription = "Left TreeView control with various foods listed"
    Me.tvwLeft.AccessibleName = "Drag Source TreeView"
    Me.tvwLeft.AllowDrop = True
    Me.tvwLeft.ImageIndex = -1
    Me.tvwLeft.Location = New System.Drawing.Point(20, 39)
    Me.tvwLeft.Name = "tvwLeft"
    Me.tvwLeft.Nodes.AddRange(New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Bowtie pasta"), New System.Windows.Forms.TreeNode("Calamari"), New System.Windows.Forms.TreeNode("Ketchup"), New System.Windows.Forms.TreeNode("Mustard", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Spicy Brown Mustard"), New System.Windows.Forms.TreeNode("Yellow Mustard"), New System.Windows.Forms.TreeNode("Hot Mustard")})})
    Me.tvwLeft.SelectedImageIndex = -1
    Me.tvwLeft.Size = New System.Drawing.Size(216, 136)
    Me.tvwLeft.TabIndex = 7
    '
    'tvwRight
    '
    Me.tvwRight.AccessibleDescription = "Right TreeView control with various foods listed"
    Me.tvwRight.AccessibleName = "Drag Target TreeView"
    Me.tvwRight.AllowDrop = True
    Me.tvwRight.ImageIndex = -1
    Me.tvwRight.Location = New System.Drawing.Point(268, 39)
    Me.tvwRight.Name = "tvwRight"
    Me.tvwRight.Nodes.AddRange(New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Hot Sauce"), New System.Windows.Forms.TreeNode("Seafood", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Fish", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Cod"), New System.Windows.Forms.TreeNode("Salmon"), New System.Windows.Forms.TreeNode("Catfish")}), New System.Windows.Forms.TreeNode("Crab"), New System.Windows.Forms.TreeNode("Lobster")}), New System.Windows.Forms.TreeNode("Pasta", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Spaghetti"), New System.Windows.Forms.TreeNode("Fettuccini")}), New System.Windows.Forms.TreeNode("Garnishes")})
    Me.tvwRight.SelectedImageIndex = -1
    Me.tvwRight.Size = New System.Drawing.Size(208, 136)
    Me.tvwRight.TabIndex = 8
    '
    'TabPage3
    '
    Me.TabPage3.Controls.AddRange(New System.Windows.Forms.Control() {Me.picRight, Me.picLeft})
    Me.TabPage3.Location = New System.Drawing.Point(4, 22)
    Me.TabPage3.Name = "TabPage3"
    Me.TabPage3.Size = New System.Drawing.Size(496, 214)
    Me.TabPage3.TabIndex = 2
    Me.TabPage3.Text = "PictureBox"
    '
    'picRight
    '
    Me.picRight.AccessibleDescription = "Empty PictureBox as drag target"
    Me.picRight.AccessibleName = "Drag Target PictureBox control"
    Me.picRight.BackColor = System.Drawing.SystemColors.Window
    Me.picRight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.picRight.Location = New System.Drawing.Point(336, 79)
    Me.picRight.Name = "picRight"
    Me.picRight.Size = New System.Drawing.Size(64, 56)
    Me.picRight.TabIndex = 31
    Me.picRight.TabStop = False
    '
    'picLeft
    '
    Me.picLeft.AccessibleDescription = "PictureBox with Beany.bmp as drag source"
    Me.picLeft.AccessibleName = "Drag Source PictureBox control"
    Me.picLeft.BackColor = System.Drawing.SystemColors.Window
    Me.picLeft.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.picLeft.Image = CType(resources.GetObject("picLeft.Image"), System.Drawing.Bitmap)
    Me.picLeft.Location = New System.Drawing.Point(96, 79)
    Me.picLeft.Name = "picLeft"
    Me.picLeft.Size = New System.Drawing.Size(64, 56)
    Me.picLeft.TabIndex = 30
    Me.picLeft.TabStop = False
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label1.Location = New System.Drawing.Point(16, 16)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(118, 19)
    Me.Label1.TabIndex = 31
    Me.Label1.Text = "Drag and Drop"
    '
    'frmMain
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(546, 315)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.TabControl1})
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.MaximizeBox = False
    Me.Menu = Me.mnuMain
    Me.Name = "frmMain"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Title Comes from Assembly Info"
    Me.TabControl1.ResumeLayout(False)
    Me.TabPage1.ResumeLayout(False)
    Me.TabPage2.ResumeLayout(False)
    Me.TabPage3.ResumeLayout(False)
    Me.ResumeLayout(False)

  End Sub

#End Region

#Region " Standard Menu Code "
  ' <System.Diagnostics.DebuggerStepThrough()> has been added to some procedures since they are
  ' not the focus of the demo. Remove them if you wish to debug the procedures.
  ' This code simply shows the About form.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub mnuAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAbout.Click
    ' Open the About form in Dialog Mode
    Dim frm As New frmAbout()
    frm.ShowDialog(Me)
    frm.Dispose()
  End Sub

  ' This code will close the form.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub mnuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuExit.Click
    ' Close the current form
    Me.Close()
  End Sub
#End Region

#Region "TextBox Routines"

  ' Handles the MouseDown event for the left TextBox. This event fires when the
  ' mouse is in the control's bounds and the mouse button is clicked.
  Private Sub txtLeft_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txtLeft.MouseDown
    If e.Button = MouseButtons.Left Then
      txtLeft.SelectAll()

      Dim DragDropResult As DragDropEffects
      DragDropResult = DoDragDrop(txtLeft.SelectedText, DragDropEffects.Move Or DragDropEffects.Copy)

      If DragDropResult = DragDropEffects.Move Then
        txtLeft.Text = ""
      End If
    End If
  End Sub

  ' Handles the DragEnter event for the lower right TextBox. DragEnter is the
  ' event that fires when an object is dragged into the control's bounds.
  Private Sub txtLowerRight_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txtLowerRight.DragEnter, txtUpperRight.DragEnter
    If (e.Data.GetDataPresent(DataFormats.Text)) Then
      If CBool(e.KeyState And 8) Then  ' Ctrl Key
        e.Effect = DragDropEffects.Copy
      Else
        e.Effect = DragDropEffects.Move
      End If
    Else
      e.Effect = DragDropEffects.None
    End If
  End Sub

  ' Handles the DragDrop event for the lower right TextBox. This event fires
  ' when the mouse button is released, terminating the drag-and-drop operation.
  Private Sub txtLowerRight_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txtLowerRight.DragDrop
    txtLowerRight.Text = e.Data.GetData(DataFormats.Text).ToString
  End Sub
#End Region

#Region "TreeView Tab"

  ' Handles the ItemDrag event for the left TreeView control. This is an alternate 
  ' way of initiating drag and drop operations.
  Private Sub TreeView_ItemDrag(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ItemDragEventArgs) Handles tvwLeft.ItemDrag
    If e.Button = MouseButtons.Left Then
      ' Invoke the drag and drop operation. You can call either Me.DoDragDrop, as in 
      ' this case, or tvw.DoDragDrop.
      Dim DragDropResult As DragDropEffects
      DragDropResult = DoDragDrop(e.Item, DragDropEffects.Move Or DragDropEffects.Copy)
      ' If this is not a Copy operation (i.e., the Control key was not 
      ' pressed), remove the source text.
      If DragDropResult = DragDropEffects.Move Then
        CType(sender, TreeView).Nodes.Remove(CType(e.Item, TreeNode))
      End If
    End If
  End Sub

  '' Handles the MouseDown event for left TreeView control. This is another way of initiating
  '' drag and drop operations and could replace the ItemDrag event handler.
  'Private Sub TreeView_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tvwLeft.MouseDown
  '    If e.Button = MouseButtons.Left Then
  '        Dim node As TreeNode = CType(sender, TreeView).GetNodeAt(New Point(e.X, e.Y))
  '        If Not node Is Nothing Then
  '            ' Invoke the drag and drop operation. You can call either Me.DoDragDrop, as in 
  '            ' this case, or tvw.DoDragDrop.
  '            Dim DragDropResult As DragDropEffects
  '            DragDropResult = DoDragDrop(node, DragDropEffects.Move Or DragDropEffects.Copy)

  '            ' If this is not a Copy operation (i.e., the Control key was not 
  '            ' pressed), remove the source text.
  '            If DragDropResult = DragDropEffects.Move Then
  '                node.Remove()
  '            End If
  '        End If
  '    End If
  'End Sub

  ' Handles the DragEnter event for both TreeView controls.
  Private Sub TreeView_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles tvwLeft.DragEnter, tvwRight.DragEnter
    ' Check to be sure that the drag content is the correct type for this 
    ' control. If not, reject the drop.
    '
    ' Calling GetDataPresent is a little different for a TreeView than for an
    ' image or text because a TreeNode is not a member of the DataFormats
    ' class. That is, it's not a predefined type. As such, you need to use a
    ' different overload, one that takes the type as a string.
    If (e.Data.GetDataPresent(GetType(TreeNode))) Then
      ' If the Ctrl key was pressed during the drag operation then perform
      ' a Copy. If not, perform a Move.
      If CBool(e.KeyState And 8) Then
        e.Effect = DragDropEffects.Copy
      Else
        e.Effect = DragDropEffects.Move
      End If
    Else
      e.Effect = DragDropEffects.None
    End If
  End Sub

  ' Handles the DragDrop event for the right TreeView control.
  Private Sub TreeView_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles tvwRight.DragDrop
    ' Initialize variable that holds the node dragged by the user.
    Dim nodeSource As TreeNode = CType(e.Data.GetData(GetType(TreeNode)), TreeNode)
    Dim tvw As TreeView = CType(sender, TreeView)
    ' Use PointToClient to compute the location of the mouse over the
    ' destination TreeView.
    Dim pt As Point = tvw.PointToClient(New Point(e.X, e.Y))
    ' Use this Point to get the closest node in the destination TreeView.
    Dim nodeTarget As TreeNode = tvw.GetNodeAt(pt)

    ' The If statement ensures that the user doesn't completely lose the
    ' node if they accidentally release the mouse button over the node they
    ' attempted to drag. Without a check to see if the original node is the
    ' same as the destination node, they could make the node disappear.
    If Not nodeTarget.TreeView Is nodeSource.TreeView Then
      nodeTarget.Nodes.Add(CType(nodeSource.Clone, TreeNode))
      ' Expand the parent node when adding the new node so that the drop
      ' is obvious. Without this, only a + symbol would appear.
      nodeTarget.Expand()
    End If
  End Sub
#End Region

#Region "PictureBox Tab"
  ' Handles the even that fires when the Form first loads.
  Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ' There is currently no way to set the AllowDrop property for a PictureBox
    ' in the Visual Studio designer, so they must be set explicitly in the code.
    picLeft.AllowDrop = True
    picRight.AllowDrop = True
  End Sub

  ' Handles the MouseDown event for the left PictureBox control. This event fires 
  ' when the mouse is in the control's bounds and the mouse button is clicked.
  Private Sub PictureBox_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picLeft.MouseDown
    If e.Button = MouseButtons.Left Then
      Dim pic As PictureBox = CType(sender, PictureBox)
      ' Invoke the drag and drop operation.
      If Not pic.Image Is Nothing Then
        ' Invoke the drag and drop operation. You can call either Me.DoDragDrop, as in 
        ' this case, or pic.DoDragDrop.
        Dim DragDropResult As DragDropEffects
        DragDropResult = DoDragDrop(pic.Image, DragDropEffects.Move Or DragDropEffects.Copy)

        If DragDropResult = DragDropEffects.Move Then
          pic.Image = Nothing
        End If
      End If
    End If
  End Sub

  ' Handles the DragEnter event for the right PictureBox control. DragEnter is the
  ' event that fires when an object is dragged into the control's bounds.
  Private Sub PictureBox_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles picRight.DragEnter
    ' Check to be sure that the drag content is the correct type for this 
    ' control. If not, reject the drop.
    If (e.Data.GetDataPresent(DataFormats.Bitmap)) Then
      ' If the Ctrl key was pressed during the drag operation then perform
      ' a Copy. If not, perform a Move.
      Trace.Write(e.KeyState)
      If CBool(e.KeyState And 8) Then
        e.Effect = DragDropEffects.Copy
      Else
        e.Effect = DragDropEffects.Move
      End If
    Else
      e.Effect = DragDropEffects.None
    End If
  End Sub

  ' Handles the DragDrop event for the right PictureBox control.
  Private Sub PictureBox_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles picRight.DragDrop
    Dim picTarget As PictureBox = CType(sender, PictureBox)
    picTarget.Image = CType(e.Data.GetData(DataFormats.Bitmap), Bitmap)
  End Sub

#End Region

End Class